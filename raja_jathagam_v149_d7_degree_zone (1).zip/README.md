# ராஜ ஜாதகம் - Raja Jathagam (Own Use Astrology Dashboard)

Accurate Vedic astrology dashboard using Swiss Ephemeris (Lahiri Ayanamsa).

## Local test
```
pip install -r requirements.txt --break-system-packages
python3 app.py
```
Open http://localhost:5001 (login: raja / changeme123 — CHANGE THIS in app.py before deploying)

## Deploy on your AWS EC2 (same instance as trading bot)

1. Upload this folder to EC2:
   ```
   scp -r raja_jathagam ubuntu@<your-ec2-ip>:/home/ubuntu/
   ```

2. SSH in and install:
   ```
   ssh ubuntu@<your-ec2-ip>
   cd raja_jathagam
   sudo apt update && sudo apt install -y python3-pip
   pip3 install -r requirements.txt --break-system-packages
   ```

3. IMPORTANT: Edit app.py and change BASIC_AUTH_USER / BASIC_AUTH_PASS to your own secret values.

4. Run with gunicorn (production):
   ```
   gunicorn -w 2 -b 0.0.0.0:5001 app:app
   ```

5. (Recommended) Create a systemd service so it runs permanently & restarts on reboot.
   Create /etc/systemd/system/rajajathagam.service:
   ```
   [Unit]
   Description=Raja Jathagam Astrology Dashboard
   After=network.target

   [Service]
   User=ubuntu
   WorkingDirectory=/home/ubuntu/raja_jathagam
   ExecStart=/usr/local/bin/gunicorn -w 2 -b 0.0.0.0:5001 app:app
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```
   Then:
   ```
   sudo systemctl daemon-reload
   sudo systemctl enable rajajathagam
   sudo systemctl start rajajathagam
   ```

6. Open EC2 Security Group -> add Inbound Rule: Custom TCP, port 5001, Source = My IP only
   (don't open to 0.0.0.0/0 — this is for your own use)

7. Access at: http://<your-ec2-ip>:5001 (browser will ask for the Basic Auth login you set)

## Notes
- Ayanamsa: Lahiri (matches Tamilcube / standard panchangam)
- Geocoding uses free Nominatim (OpenStreetMap) — needs outbound internet on port 443,
  which EC2 has by default.
- All calculation happens server-side in jyotish_engine.py — no external astrology API used.
- Change the Basic Auth password before exposing the port publicly, even to "my IP only".
