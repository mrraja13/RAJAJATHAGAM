"""
Raja Jathagam - Tamil PDF Report Generator
Uses weasyprint (HTML -> PDF) for correct Tamil complex-script rendering
(reportlab does not shape Tamil conjuncts correctly).
"""

from weasyprint import HTML

RASI_TA = ["மேஷம்", "ரிஷபம்", "மிதுனம்", "கடகம்", "சிம்மம்", "கன்னி",
           "துலாம்", "விருச்சிகம்", "தனுசு", "மகரம்", "கும்பம்", "மீனம்"]

GRAHA_ORDER = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu", "Guligan"]


def _graha_rows(chart):
    rows = ""
    for p in GRAHA_ORDER:
        g = chart["grahas"][p]
        rows += f'<tr><td>{g["name_ta"]}</td><td>{g["rasi"]}</td><td>{g["degree"]}</td>' \
                f'<td>{g["nakshatra"]}</td><td>{g["pada"]}</td></tr>'
    return rows


def _dasa_rows(chart):
    rows = ""
    for d in chart["dasa"]["mahadasa_sequence"]:
        rows += f'<tr><td>{d["lord"]}</td><td>{d["start"]}</td><td>{d["end"]}</td><td>{d["years"]}</td></tr>'
    return rows


def _bhava_rows(chart):
    rows = ""
    for h in chart["bhavas"]:
        occ = ", ".join(h["occupants_ta"]) if h["occupants_ta"] else "—"
        tags = ", ".join(h["tags"])
        rows += f'<tr><td>{h["house_num"]}</td><td>{h["rasi"]}</td><td>{h["lord_ta"]}</td>' \
                f'<td>{occ}</td><td>{h["ashtakam"]}</td><td style="font-size:8px;">{tags}</td></tr>'
    return rows


def _sav_table(chart):
    sav = chart["ashtakavarga"]["sarvashtakavarga"]["by_rasi"]
    head = "".join(f'<th>{r[:3]}</th>' for r in RASI_TA)
    vals = "".join(f'<td>{sav[r]}</td>' for r in RASI_TA)
    return f'<table class="sav"><tr>{head}</tr><tr>{vals}</tr></table>'


def _varga_summary(chart):
    """One compact table per varga: planet -> rasi."""
    blocks = ""
    for code in ["D9","D10","D12","D3","D2","D16","D20","D24","D30"]:
        if code not in chart["vargas"]:
            continue
        v = chart["vargas"][code]
        cells = "".join(
            f'<div class="vg-cell"><b>{v["grahas"][ ["சூரியன்","சந்திரன்","செவ்வாய்","புதன்","குரு","சுக்கிரன்","சனி","ராகு","கேது"][i] ]["rasi"] if False else ""}</b></div>'
            for i in range(0)
        )
        rows = "".join(
            f'<span>{name}: {info["rasi"]}</span>'
            for name, info in v["grahas"].items()
        )
        blocks += f'<div class="vg-block"><div class="vg-title">{code} — {v["name_ta"]} (லக்னம்: {v["lagna_rasi"]})</div>' \
                  f'<div class="vg-grahas">{rows}</div></div>'
    return blocks


def _panchanga_rows(chart):
    p = chart["panchanga"]
    rows = [
        ("பிறந்த கிழமை", p["vaaram"]["ta"] + " (அதிபதி: " + p["vaaram"]["lord_ta"] + ")"),
        ("நட்சத்திரம்", chart["grahas"]["Moon"]["nakshatra"] + " - பாதம் " + str(chart["grahas"]["Moon"]["pada"])),
        ("ராசி", chart["grahas"]["Moon"]["rasi"]),
        ("லக்னம்", chart["lagna"]["rasi"] + " " + chart["lagna"]["degree"]),
        ("லக்னாதிபதி", p["lagna_lord_ta"]),
        ("திதி", p["tithi"]["name"] + " (" + p["tithi"]["paksha"] + ", " + str(p["tithi"]["number"]) + ")"),
        ("யோகம் (நித்ய யோகம்)", p["nitya_yoga"]["name"]),
        ("கரணம்", p["karana"]["name"]),
        ("சூரிய உதயம்", p["sunrise"]),
        ("சூரிய அஸ்தமனம்", p["sunset"]),
        ("பிறந்த ஒரை", p["birth_hora"]["lord_ta"] + " (" + str(p["birth_hora"]["number"]) + "-வது ஒரை)"),
        ("யோகி", p["yogi"]["lord_ta"] + " (" + p["yogi"]["nakshatra"] + ")"),
        ("அவயோகி", p["avayogi"]["lord_ta"] + " (" + p["avayogi"]["nakshatra"] + ")"),
        ("ஆத்ம காரகன் (அதிக பாகை)", p["atmakaraka_ta"]),
        ("அமத்திய காரகன்", p["amatyakaraka_ta"]),
        ("குறைந்த பாகை பெற்ற கிரகம்", p["lowest_degree_graha_ta"]),
    ]
    return "".join(f'<tr><td style="text-align:left; font-weight:bold; width:45%;">{lbl}</td><td style="text-align:left;">{val}</td></tr>' for lbl, val in rows)


def _yoga_section(chart):
    y = chart["yogas"]
    parts = []
    if y["parivartana"]:
        parts.append("<b>பரிவர்த்தனை:</b> " + "; ".join(" - ".join(p["pair"]) for p in y["parivartana"]))
    if y["graha_sechkai"]:
        parts.append("<b>கிரக சேர்க்கை:</b> " + "; ".join(f'{c["rasi"]} ({", ".join(c["planets"])})' for c in y["graha_sechkai"]))
    if y["mutual_7th_aspect"]:
        parts.append("<b>ஒன்றையொன்று பார்க்கும் கிரகங்கள்:</b> " + "; ".join(" - ".join(p["pair"]) for p in y["mutual_7th_aspect"]))
    if y["six_eight_twelve"]:
        parts.append("<b>6/8/12 தொடர்பு:</b> " + "; ".join(" - ".join(p["pair"]) for p in y["six_eight_twelve"]))
    if not parts:
        parts.append("குறிப்பிடத்தக்க யோகங்கள் இல்லை.")
    return "<br>".join(parts)


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="ta">
<head>
<meta charset="UTF-8">
<style>
  @page {{ size: A4; margin: 16mm; }}
  body {{ font-family: 'Noto Sans Tamil', 'Noto Sans', sans-serif; color:#2a2a2a; font-size:11px; }}
  h1 {{ color:#d3671f; text-align:center; font-size:24px; margin-bottom:4px; }}
  .meta {{ text-align:center; font-size:11px; color:#555; margin-bottom:14px; }}
  h2 {{ color:#d3671f; font-size:15px; border-bottom:2px solid #d3671f; padding-bottom:4px; margin-top:20px; }}
  table {{ width:100%; border-collapse:collapse; margin-top:6px; }}
  th {{ background:#d3671f; color:#fff; padding:6px 4px; font-size:10px; }}
  td {{ border-bottom:1px solid #eee2bd; padding:5px 4px; text-align:center; font-size:10px; }}
  tr:nth-child(even) td {{ background:#fdf6e3; }}
  table.dasa th {{ background:#0b6b52; }}
  table.dasa tr:nth-child(even) td {{ background:#eafff6; }}
  table.bhava th {{ background:#0e9488; }}
  table.bhava tr:nth-child(even) td {{ background:#eefaf8; }}
  table.sav th, table.sav td {{ background:#5b4fd6; color:#fff; font-size:9px; padding:5px 2px; }}
  table.sav td {{ background:#efeeff; color:#2a2a2a; }}
  .vg-block {{ margin-bottom:8px; padding:8px; background:#fffdf5; border:1px solid #d3671f; border-radius:6px; }}
  .vg-title {{ font-weight:bold; color:#d3671f; margin-bottom:4px; }}
  .vg-grahas span {{ display:inline-block; margin-right:10px; font-size:10px; }}
  .yoga-box {{ background:#f3f1ff; border:1px solid #5b4fd6; border-radius:6px; padding:10px; font-size:10px; line-height:1.8; }}
  .footer {{ text-align:center; color:#a89b6f; font-size:9px; margin-top:20px; }}
</style>
</head>
<body>
  <h1>ராஜ ஜாதகம்</h1>
  <div class="meta">
    பிறந்த தேதி: {date} &nbsp;&nbsp;|&nbsp;&nbsp; நேரம்: {time} &nbsp;&nbsp;|&nbsp;&nbsp; இடம்: {place}<br>
    லக்னம்: {lagna_rasi} {lagna_deg} ({lagna_nak} - பாதம் {lagna_pada})
  </div>

  <h2>பஞ்சாங்க விவரங்கள்</h2>
  <table>
    {panchanga_rows}
  </table>

  <h2>கிரக நிலைகள்</h2>
  <table>
    <tr><th>கிரகம்</th><th>ராசி</th><th>Degree</th><th>நட்சத்திரம்</th><th>பாதம்</th></tr>
    {graha_rows}
  </table>

  <h2>விம்சோத்தரி மகாதசா காலங்கள்</h2>
  <table class="dasa">
    <tr><th>தசை</th><th>தொடக்கம்</th><th>முடிவு</th><th>ஆண்டுகள்</th></tr>
    {dasa_rows}
  </table>
  <p style="margin-top:6px;">நடப்பு தசா — புக்தி: <b>{cur_maha} → {cur_antar}</b> ({cur_period})</p>

  <h2>பாவ விவரம் (12 வீடுகள்)</h2>
  <table class="bhava">
    <tr><th>வீடு</th><th>ராசி</th><th>அதிபதி</th><th>கிரகங்கள்</th><th>அஷ்டகம்</th><th>வகை</th></tr>
    {bhava_rows}
  </table>

  <h2>சர்வாஷ்டகவர்க்கம் — மொத்தம்: {sav_total}</h2>
  {sav_table}

  <h2>வர்க்க சக்கரங்கள் (Divisional Charts)</h2>
  {varga_blocks}

  <h2>யோகங்கள் & கிரக தொடர்புகள்</h2>
  <div class="yoga-box">{yoga_text}</div>

  <div class="footer">RAJA JATHAGAM — Own Use Report — Lahiri Ayanamsa, Swiss Ephemeris</div>
</body>
</html>
"""


def generate_pdf(chart, output_path):
    html_str = HTML_TEMPLATE.format(
        date=chart["birth"]["date"],
        time=chart["birth"]["time"],
        place=chart["birth"]["place"],
        lagna_rasi=chart["lagna"]["rasi"],
        lagna_deg=chart["lagna"]["degree"],
        lagna_nak=chart["lagna"]["nakshatra"],
        lagna_pada=chart["lagna"]["pada"],
        panchanga_rows=_panchanga_rows(chart),
        graha_rows=_graha_rows(chart),
        dasa_rows=_dasa_rows(chart),
        cur_maha=chart["dasa"]["current_mahadasa"],
        cur_antar=chart["dasa"]["current_antardasa"],
        cur_period=chart["dasa"]["current_period"],
        bhava_rows=_bhava_rows(chart),
        sav_total=chart["ashtakavarga"]["sarvashtakavarga"]["total"],
        sav_table=_sav_table(chart),
        varga_blocks=_varga_summary(chart),
        yoga_text=_yoga_section(chart),
    )
    HTML(string=html_str).write_pdf(output_path)
    return output_path
