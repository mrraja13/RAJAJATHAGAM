"""
Raja Jathagam - Flask backend
Serves the dashboard and exposes /api/calculate for chart generation.
Own-use only - protect with HTTP Basic Auth in production (see deploy notes).
"""

from flask import Flask, render_template, request, jsonify, send_file
from functools import wraps
import requests as http_requests
import tempfile, os, json, re

from datetime import datetime
from jyotish_engine import calculate_chart, build_antardasa, PLANET_TA, RASI_LORD, graha_drishti, verify_child_chart_match
from pdf_report import generate_pdf

app = Flask(__name__)

# ---------------------------------------------------------------
# Saved-chart storage (server-side, on EC2 disk) - one JSON file per
# person name, holding their birth details + any manual graha edits
# (overrides). Persists across browser refreshes and devices.
# ---------------------------------------------------------------
SAVED_CHARTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_charts")
os.makedirs(SAVED_CHARTS_DIR, exist_ok=True)


def _safe_chart_filename(name):
    slug = re.sub(r"[^a-zA-Z0-9அ-ஹா-ௌ்_-]", "_", name.strip())
    return os.path.join(SAVED_CHARTS_DIR, f"{slug}.json")

# ---------------------------------------------------------------
# Simple HTTP Basic Auth (own-use protection)
# CHANGE THESE before deploying to EC2.
# ---------------------------------------------------------------
BASIC_AUTH_USER = "raja"
BASIC_AUTH_PASS = "changeme123"  # <-- CHANGE THIS

# ---------------------------------------------------------------
# Google Gemini API key for AI-generated Rasi Chakra Palan (FREE tier).
# Get a free key from https://aistudio.google.com/apikey and paste it here.
# Leave as-is (empty) to keep the "பலன் பார்க்க" button disabled server-side.
# ---------------------------------------------------------------
GEMINI_API_KEY = ""  # <-- PASTE YOUR KEY HERE

def check_auth(username, password):
    return username == BASIC_AUTH_USER and password == BASIC_AUTH_PASS

def authenticate():
    return ("Authentication required", 401,
            {"WWW-Authenticate": 'Basic realm="Raja Jathagam"'})

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------
# Geocoding (place name -> lat/lon) using free Nominatim (OSM)
# ---------------------------------------------------------------
def geocode_place(place_name):
    try:
        resp = http_requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": place_name, "format": "json", "limit": 1},
            headers={"User-Agent": "RajaJathagam/1.0"},
            timeout=6
        )
        data = resp.json()
        if data:
            return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception:
        pass
    return None, None


def get_timezone_offset(lat, lon, birth_date=None):
    """Auto-detect the UTC offset (hours) for a lat/lon, using the actual
    birth date so historical DST rules are respected. Falls back to IST
    (+5.5) if the lookup fails for any reason."""
    try:
        from timezonefinder import TimezoneFinder
        from zoneinfo import ZoneInfo
        tf = TimezoneFinder()
        tz_name = tf.timezone_at(lat=lat, lng=lon)
        if not tz_name:
            return 5.5
        if birth_date:
            y, m, d = map(int, birth_date.split("-"))
            dt = datetime(y, m, d, 12, 0)
        else:
            dt = datetime.now()
        offset = ZoneInfo(tz_name).utcoffset(dt)
        return round(offset.total_seconds() / 3600, 2)
    except Exception:
        return 5.5


# ---------------------------------------------------------------
# Routes
# ---------------------------------------------------------------
@app.route("/")
@requires_auth
def index():
    return render_template("dashboard.html")


@app.route("/api/geocode")
@requires_auth
def api_geocode():
    place = request.args.get("place", "")
    birth_date = request.args.get("date")
    lat, lon = geocode_place(place)
    if lat is None:
        return jsonify({"error": "Place not found"}), 404
    tz = get_timezone_offset(lat, lon, birth_date)
    return jsonify({"lat": lat, "lon": lon, "tz": tz})


@app.route("/api/place_suggestions")
@requires_auth
def api_place_suggestions():
    """Live autocomplete for the birth-place field: returns up to 6
    matching place names (with city/state/country) as the user types."""
    query = request.args.get("q", "").strip()
    if len(query) < 3:
        return jsonify({"suggestions": []})
    try:
        resp = http_requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": query, "format": "json", "limit": 6, "addressdetails": 1},
            headers={"User-Agent": "RajaJathagam/1.0"},
            timeout=6
        )
        results = resp.json()
        suggestions = []
        for r in results:
            suggestions.append({
                "display_name": r.get("display_name", ""),
                "lat": float(r["lat"]),
                "lon": float(r["lon"]),
            })
        return jsonify({"suggestions": suggestions})
    except Exception as e:
        return jsonify({"suggestions": [], "error": str(e)})


@app.route("/api/calculate", methods=["POST"])
@requires_auth
def api_calculate():
    data = request.get_json(force=True)

    birth_date = data.get("date")        # 'YYYY-MM-DD'
    birth_time = data.get("time")        # 'HH:MM'
    tz_offset = float(data.get("tz", 5.5))
    place_name = data.get("place", "")
    lat = data.get("lat")
    lon = data.get("lon")

    if not birth_date or not birth_time:
        return jsonify({"error": "date and time are required"}), 400

    # If lat/lon not given directly, geocode the place name
    if lat is None or lon is None:
        if not place_name:
            return jsonify({"error": "place or lat/lon required"}), 400
        lat, lon = geocode_place(place_name)
        if lat is None:
            return jsonify({"error": f"Could not find location: {place_name}"}), 404

    overrides = data.get("overrides")  # optional {"Sun": longitude_degrees, ...}
    gender = data.get("gender") or None  # optional "male"/"female"

    try:
        chart = calculate_chart(
            birth_date=birth_date,
            birth_time=birth_time,
            tz_offset=tz_offset,
            lat=float(lat),
            lon=float(lon),
            place_name=place_name,
            overrides=overrides,
            gender=gender
        )
        return jsonify(chart)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/verify_child_chart", methods=["POST"])
@requires_auth
def api_verify_child_chart():
    """Given both parent and child birth details, checks whether the
    child's D1/D7 Lagna or Moon falls in the 5th house from the
    parent's D7 Lagna (classical chart-matching check). Facts only."""
    data = request.get_json(force=True)
    parent_data = data.get("parent") or {}
    child_data = data.get("child") or {}

    def resolve_latlon(d):
        lat, lon = d.get("lat"), d.get("lon")
        place_name = d.get("place", "")
        if lat is None or lon is None:
            if not place_name:
                return None, None, f"place or lat/lon required"
            lat, lon = geocode_place(place_name)
            if lat is None:
                return None, None, f"Could not find location: {place_name}"
        return float(lat), float(lon), None

    try:
        p_lat, p_lon, err = resolve_latlon(parent_data)
        if err:
            return jsonify({"error": "Parent: " + err}), 400
        c_lat, c_lon, err = resolve_latlon(child_data)
        if err:
            return jsonify({"error": "Child: " + err}), 400

        parent_chart = calculate_chart(
            birth_date=parent_data.get("date"), birth_time=parent_data.get("time"),
            tz_offset=float(parent_data.get("tz", 5.5)), lat=p_lat, lon=p_lon,
            place_name=parent_data.get("place", "")
        )
        child_chart = calculate_chart(
            birth_date=child_data.get("date"), birth_time=child_data.get("time"),
            tz_offset=float(child_data.get("tz", 5.5)), lat=c_lat, lon=c_lon,
            place_name=child_data.get("place", "")
        )
        result = verify_child_chart_match(parent_chart, child_chart)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/save_chart", methods=["POST"])
@requires_auth
def api_save_chart():
    """Save/update a named chart's birth details and manual graha overrides
    to a JSON file on the server, so edits persist across devices/browsers."""
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "பெயர் தேவை"}), 400
    record = {
        "name": name,
        "date": data.get("date"),
        "time": data.get("time"),
        "tz": data.get("tz"),
        "place": data.get("place"),
        "lat": data.get("lat"),
        "lon": data.get("lon"),
        "gender": data.get("gender") or "",
        "overrides": data.get("overrides") or {},
    }
    try:
        with open(_safe_chart_filename(name), "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/load_chart", methods=["GET"])
@requires_auth
def api_load_chart():
    """Load a previously saved chart (birth details + overrides) by name."""
    name = (request.args.get("name") or "").strip()
    if not name:
        return jsonify({"error": "பெயர் தேவை"}), 400
    path = _safe_chart_filename(name)
    if not os.path.exists(path):
        return jsonify({"found": False})
    try:
        with open(path, "r", encoding="utf-8") as f:
            record = json.load(f)
        record["found"] = True
        return jsonify(record)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/list_charts", methods=["GET"])
@requires_auth
def api_list_charts():
    """List all saved chart names (for a quick picker in the UI)."""
    try:
        names = [
            f[:-5] for f in os.listdir(SAVED_CHARTS_DIR)
            if f.endswith(".json")
        ]
        return jsonify({"names": sorted(names)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/delete_chart", methods=["POST"])
@requires_auth
def api_delete_chart():
    """Delete a saved chart's file by name."""
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "பெயர் தேவை"}), 400
    path = _safe_chart_filename(name)
    try:
        if os.path.exists(path):
            os.remove(path)
            return jsonify({"ok": True, "deleted": True})
        return jsonify({"ok": True, "deleted": False})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/subperiods", methods=["POST"])
@requires_auth
def api_subperiods():
    """Given a lord + start date + duration (years), return its 9 sub-periods.
    Used for on-demand expansion of Sookshma/Prana dasa levels."""
    data = request.get_json(force=True)
    lord_en = data.get("lord_en")
    start_str = data.get("start")
    years = data.get("years")
    if not lord_en or not start_str or years is None:
        return jsonify({"error": "lord_en, start, years are required"}), 400
    try:
        start_dt = datetime.strptime(start_str, "%d-%m-%Y")
        seq = build_antardasa(lord_en, start_dt, float(years))
        result = [
            {"lord_en": s["lord"], "lord_ta": PLANET_TA[s["lord"]],
             "start": s["start"].strftime("%d-%m-%Y"),
             "end": s["end"].strftime("%d-%m-%Y"),
             "years": round(s["years"], 4)}
            for s in seq
        ]
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _build_palan_prompt(chart):
    """Compact, explicit facts pulled from the already-computed chart so the
    AI doesn't have to re-derive anything - just phrase it, point by point."""
    lagna = chart["lagna"]
    lagna_rasi_idx = lagna["rasi_index"]
    lagna_lord_ta = chart["panchanga"]["lagna_lord_ta"]
    lagna_lord_en = RASI_LORD[lagna_rasi_idx]
    lagna_lord_house = None
    for bhava in chart["bhavas"]:
        if lagna_lord_ta in bhava.get("occupants_ta", []):
            lagna_lord_house = bhava.get("house_num")
    atmakaraka = chart["panchanga"]["atmakaraka_ta"]
    amatyakaraka = chart["panchanga"]["amatyakaraka_ta"]
    parivartanas = ", ".join(
        f'{p["pair"][0]}-{p["pair"][1]}' for p in chart["yogas"].get("parivartana", [])
    ) or "இல்லை"
    maha = chart["dasa"]["current_mahadasa"]
    antar = chart["dasa"]["current_antardasa"]

    grahas = chart["grahas"]
    ALL_PLANETS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]

    def house_of(rasi_idx):
        return (rasi_idx - lagna_rasi_idx) % 12 + 1

    # Who aspects the Lagna? Who aspects the Lagna Lord's own position?
    lagna_lord_rasi_idx = grahas[lagna_lord_en]["rasi_index"]
    aspecting_lagna, aspecting_lagna_lord = [], []
    for p in ALL_PLANETS:
        if p not in grahas:
            continue
        aspected_rasis = graha_drishti(p, grahas[p]["rasi_index"])
        if lagna_rasi_idx in aspected_rasis:
            aspecting_lagna.append(PLANET_TA[p])
        if lagna_lord_rasi_idx in aspected_rasis:
            aspecting_lagna_lord.append(PLANET_TA[p])
    lagna_aspect_text = ", ".join(aspecting_lagna) if aspecting_lagna else "எந்த கிரகமும் இல்லை (பார்வை இல்லாதவர்)"
    lagna_lord_aspect_text = ", ".join(aspecting_lagna_lord) if aspecting_lagna_lord else "எந்த கிரகமும் இல்லை (பார்வை இல்லாதவர்)"

    # For each house's own lord: which houses (by number, from lagna) does that lord aspect?
    # Flags self-aspect (lord aspecting its own house) and notable 2-way connections.
    house_lord_aspect_lines = []
    for b in chart["bhavas"]:
        h_num = b["house_num"]
        lord_ta = b["lord_ta"]
        lord_en = next((p for p in ALL_PLANETS if PLANET_TA.get(p) == lord_ta), None)
        if lord_en is None or lord_en not in grahas:
            continue
        aspected_rasis = graha_drishti(lord_en, grahas[lord_en]["rasi_index"])
        aspected_houses = sorted(house_of(r) for r in aspected_rasis)
        self_note = " (சொந்த வீட்டையே பார்க்கிறார்)" if h_num in aspected_houses else ""
        house_lord_aspect_lines.append(
            f'{h_num}-ம் வீட்டு அதிபதி {lord_ta} → {"/".join(str(x) for x in aspected_houses)}-ம் வீடுகளை பார்க்கிறார்{self_note}'
        )
    house_lord_aspect_block = "\n".join(house_lord_aspect_lines)

    # 12 bhava (house) summary - lord, occupants, ashtakavarga points
    bhava_lines = []
    for b in chart["bhavas"]:
        occ = ", ".join(b.get("occupants_ta", [])) or "கிரகம் இல்லை"
        bhava_lines.append(
            f'{b["house_num"]}-ம் வீடு ({b["rasi"]}, அதிபதி {b["lord_ta"]}): {occ} — அஷ்டகம் {b["ashtakam"]}'
        )
    bhava_block = "\n".join(bhava_lines)

    # Conjunctions (graha sechkai)
    conjunctions = "; ".join(
        f'{g["rasi"]}-ல் {", ".join(g["planets"])}'
        for g in chart["yogas"].get("graha_sechkai", [])
    ) or "இல்லை"

    # Mutual 7th aspects
    aspects = ", ".join(
        f'{a["pair"][0]}-{a["pair"][1]}'
        for a in chart["yogas"].get("mutual_7th_aspect", [])
    ) or "இல்லை"

    facts = f"""
லக்னம்: {lagna['rasi']}
லக்னத்தை பார்க்கும் கிரகங்கள்: {lagna_aspect_text}
லக்னாதிபதி: {lagna_lord_ta} ({lagna_lord_house}-ம் வீட்டில் அமர்ந்துள்ளார்)
லக்னாதிபதியை பார்க்கும் கிரகங்கள்: {lagna_lord_aspect_text}
ஆத்ம காரகன்: {atmakaraka}
அமத்திய காரகன்: {amatyakaraka}
பரிவர்த்தனை யோகங்கள்: {parivartanas}
கிரக சேர்க்கைகள் (conjunctions): {conjunctions}
பரஸ்பர 7ம் வீட்டு பார்வைகள் (aspects): {aspects}
தற்போதைய தசா-புக்தி: {maha} - {antar}

12 பாவங்களின் விவரம்:
{bhava_block}

ஒவ்வொரு வீட்டு அதிபதியும் எந்தெந்த வீடுகளை பார்க்கிறார் (classical graha drishti):
{house_lord_aspect_block}
"""
    prompt = f"""கீழே கொடுக்கப்பட்ட ஜாதக தகவல்களை வைத்து, தமிழில் ஒரு சுருக்கமான, Point-point பலன் விளக்கம் எழுது.

நிபந்தனைகள்:
- ரொம்ப நீளமான பாராகிராஃப் வேண்டாம். ஒவ்வொரு point-உம் ஒரு வரி/ரெண்டு வரி மட்டும்.
- **லக்னம் பற்றி முதலில் எழுது:** "லக்னத்தை/லக்னாதிபதியை பார்க்கும் கிரகங்கள்" facts வைத்து — யாரும் பார்க்கலைன்னா "லக்னத்தை/லக்னாதிபதியை யாரும் பார்க்கவில்லை, ஜாதகர் தான் விரும்புவதை தானே செய்பவர், யாருடைய உதவியும் இல்லாமல் சொந்த முயற்சியால் வெல்பவர்" போன்ற பாணியில் எழுது. யாராவது பார்த்தால் அந்த கிரகத்தின் குணம் கலந்திருக்கும் என எழுது.
- **12 பாவங்களுக்கும்** தலா ஒரு short point எழுது (அந்த வீட்டு அதிபதி/கிரகங்கள் வைத்து அந்த வீட்டு பொருளுக்கான (உடல் ஆரோக்யம், பணம், சகோதரர், வீடு, குழந்தை, கடன்/நோய், துணை, ஆயுள், அதிர்ஷ்டம், தொழில், லாபம், செலவு) சுருக்கமான பலன்). "ஒவ்வொரு வீட்டு அதிபதியும் எந்தெந்த வீடுகளை பார்க்கிறார்" facts-ஐ வைத்து, ஒரு வீட்டு அதிபதி தன் சொந்த வீட்டையே பார்த்தால் அந்த வீட்டு விஷயத்தில் பலம்/தனம் உண்டு என்று எழுது.
- **வீடு-வீடு தொடர்பு (எ.கா 2-10, 5-9, 3-11):** ஒரு வீட்டு அதிபதி வேறொரு முக்கிய வீட்டை பார்த்தால் அல்லது அந்த வீட்டில் அமர்ந்திருந்தால், அந்த இரண்டு வீட்டு பொருள்களும் இணைந்த பலனாக விளக்கு (உதா: 2-ம் வீட்டு அதிபதி 10-ம் வீட்டை பார்த்தால் "பேச்சு/எழுத்து சம்பந்தமான தொழில் மூலம் சம்பாதிப்பார்" என்பது போல).
- கிரக சேர்க்கை மற்றும் பரஸ்பர பார்வைகளுக்கும் தலா ஒரு short point எழுது.
- ஆத்ம காரகன், தசா-புக்தி பற்றியும் short points எழுது.
- ஒவ்வொரு point-உம் "•" குறியீட்டில் தொடங்கட்டும், ஒரு வரிக்கு மேல் போகக்கூடாது.
- Headings/sub-headings பயன்படுத்து (உதா: "**லக்னம்:**", "**வீடுகள்:**", "**கிரக யோகங்கள்:**", "**தசா:**") ஒவ்வொரு பிரிவுக்கு முன்.
- கொடுக்கப்பட்ட facts-ஐ மட்டும் வைத்து எழுது, புதிதாக எதுவும் கற்பனை பண்ணாதே.
- லக்னாதிபதி எந்த வீட்டில் இருக்காரோ அதை பெயர் குறிப்பிட்டு (எ.கா "4-ம் வீட்டில்") விளக்கு.

ஜாதக தகவல்கள்:
{facts}
"""
    return prompt


@app.route("/api/rasi_palan", methods=["POST"])
@requires_auth
def api_rasi_palan():
    if not GEMINI_API_KEY:
        return jsonify({"error": "GEMINI_API_KEY இன்னும் app.py-ல் set ஆகல."}), 503
    data = request.get_json(force=True)
    birth_date = data.get("date")
    birth_time = data.get("time")
    tz_offset = float(data.get("tz", 5.5))
    place_name = data.get("place", "")
    lat = data.get("lat")
    lon = data.get("lon")
    if lat is None or lon is None:
        lat, lon = geocode_place(place_name)
        if lat is None:
            return jsonify({"error": f"Could not find location: {place_name}"}), 404
    try:
        chart = calculate_chart(
            birth_date=birth_date, birth_time=birth_time, tz_offset=tz_offset,
            lat=float(lat), lon=float(lon), place_name=place_name
        )
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        prompt = _build_palan_prompt(chart)
        resp = client.models.generate_content(
            model="gemini-3.6-flash",
            contents=prompt
        )
        return jsonify({"palan": resp.text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/pdf", methods=["POST"])
@requires_auth
def api_pdf():
    data = request.get_json(force=True)
    birth_date = data.get("date")
    birth_time = data.get("time")
    tz_offset = float(data.get("tz", 5.5))
    place_name = data.get("place", "")
    lat = data.get("lat")
    lon = data.get("lon")

    if lat is None or lon is None:
        lat, lon = geocode_place(place_name)
        if lat is None:
            return jsonify({"error": f"Could not find location: {place_name}"}), 404

    try:
        chart = calculate_chart(
            birth_date=birth_date, birth_time=birth_time, tz_offset=tz_offset,
            lat=float(lat), lon=float(lon), place_name=place_name
        )
        tmp_path = os.path.join(tempfile.gettempdir(), "raja_jathagam_report.pdf")
        generate_pdf(chart, tmp_path)
        return send_file(tmp_path, as_attachment=True, download_name="raja_jathagam.pdf")
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    # For local testing only. On EC2, run via gunicorn + systemd (see deploy notes).
    app.run(host="0.0.0.0", port=5001, debug=False)
