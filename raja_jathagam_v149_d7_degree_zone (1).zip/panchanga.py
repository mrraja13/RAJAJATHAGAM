"""
Raja Jathagam - Panchanga & Karaka Module
Adds: Vaaram, Tithi, Nitya Yoga, Karana, Sunrise/Sunset, Birth Hora,
Yogi/Avayogi, Lagna Lord, Atmakaraka/Amatyakaraka (highest/lowest degree graha).

All longitudes passed in must be SIDEREAL (Lahiri) degrees, 0-360,
consistent with jyotish_engine.get_sidereal_positions().
"""

import swisseph as swe
from datetime import datetime, timedelta

# ---------------------------------------------------------------
# STATIC TABLES
# ---------------------------------------------------------------
WEEKDAY_TA = {
    "Monday": "திங்கள்", "Tuesday": "செவ்வாய்", "Wednesday": "புதன்",
    "Thursday": "வியாழன்", "Friday": "வெள்ளி", "Saturday": "சனி", "Sunday": "ஞாயிறு"
}

# Day-lord for each weekday (English key, matches datetime.strftime('%A'))
WEEKDAY_LORD = {
    "Sunday": "Sun", "Monday": "Moon", "Tuesday": "Mars", "Wednesday": "Mercury",
    "Thursday": "Jupiter", "Friday": "Venus", "Saturday": "Saturn"
}

TITHI_NAMES = [
    "பிரதமை", "துவிதியை", "திருதியை", "சதுர்த்தி", "பஞ்சமி", "சஷ்டி",
    "சப்தமி", "அஷ்டமி", "நவமி", "தசமி", "ஏகாதசி", "துவாதசி",
    "திரயோதசி", "சதுர்தசி", "பூர்ணை"
]

MOVABLE_KARANA = ["பவ", "பாலவ", "கௌலவ", "தைதுல", "கரஜ", "வணிஜ", "விஷ்டி (பத்ரை)"]
FIXED_KARANA = {1: "கிம்ஸ்துக்னம்", 58: "சகுனி", 59: "சதுஷ்பாதம்", 60: "நாகவான்"}

NITYA_YOGA_NAMES = [
    "விஷ்கம்பம்", "பிரீதி", "ஆயுஷ்மான்", "சௌபாக்யம்", "சோபனம்", "அதிகண்டம்",
    "சுகர்மா", "திருதி", "சூலம்", "கண்டம்", "விருத்தி", "துருவம்",
    "வியாகாதம்", "ஹர்ஷணம்", "வஜ்ரம்", "சித்தி", "வியதீபாதம்", "வரீயான்",
    "பரிகம்", "சிவம்", "சித்தம்", "சாத்யம்", "சுபம்", "சுக்லம்",
    "பிரம்மம்", "ஐந்திரம்", "வைதிருதி"
]

# Nakshatra-lord cycle (9 lords repeating), same order used in jyotish_engine.NAK_LORDS
KARAKA_LORD_CYCLE = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"] * 3

# Chaldean order used for Hora sequencing (descending planetary speed order)
CHALDEAN_ORDER = ["Saturn", "Jupiter", "Mars", "Sun", "Venus", "Mercury", "Moon"]

RASI_LORD = {
    0: "Mars", 1: "Venus", 2: "Mercury", 3: "Moon", 4: "Sun", 5: "Mercury",
    6: "Venus", 7: "Mars", 8: "Jupiter", 9: "Saturn", 10: "Saturn", 11: "Jupiter"
}

YOGI_OFFSET = 93 + 20 / 60  # 93°20'
KARAKA_PLANETS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
KARAKA_NAMES_TA = ["ஆத்மகாரகன்", "அமத்திய காரகன்", "பாதுரு காரகன்", "மாதுரு காரகன்",
                    "புத்திர காரகன்", "ஞாதி காரகன்", "தார காரகன்"]


# ---------------------------------------------------------------
# VAARAM (weekday)
# ---------------------------------------------------------------
def vaaram(dt_local):
    day_en = dt_local.strftime("%A")
    return {"en": day_en, "ta": WEEKDAY_TA[day_en], "lord": WEEKDAY_LORD[day_en]}


# ---------------------------------------------------------------
# TITHI
# ---------------------------------------------------------------
def tithi_info(sun_lon, moon_lon):
    diff = (moon_lon - sun_lon) % 360
    tithi_num = int(diff // 12) + 1  # 1-30
    paksha = "சுக்ல பக்ஷம்" if tithi_num <= 15 else "கிருஷ்ண பக்ஷம்"
    if tithi_num == 15:
        name = "பௌர்ணமி"
    elif tithi_num == 30:
        name = "அமாவாசை"
    else:
        idx = (tithi_num - 1) % 15
        name = TITHI_NAMES[idx]
    pct_complete = round(((diff % 12) / 12) * 100, 1)
    return {
        "number": tithi_num, "name": name, "paksha": paksha,
        "percent_complete": pct_complete
    }


# ---------------------------------------------------------------
# KARANA (half-tithi)
# ---------------------------------------------------------------
def karana_info(sun_lon, moon_lon):
    diff = (moon_lon - sun_lon) % 360
    half_num = int(diff // 6) + 1  # 1-60
    if half_num in FIXED_KARANA:
        name = FIXED_KARANA[half_num]
    else:
        idx = (half_num - 2) % 7
        name = MOVABLE_KARANA[idx]
    return {"number": half_num, "name": name}


# ---------------------------------------------------------------
# NITYA YOGA (27 yogas from Sun+Moon)
# ---------------------------------------------------------------
def nitya_yoga_info(sun_lon, moon_lon):
    total = (sun_lon + moon_lon) % 360
    span = 360 / 27
    idx = int(total // span)
    return {"index": idx + 1, "name": NITYA_YOGA_NAMES[idx]}


# ---------------------------------------------------------------
# SUNRISE / SUNSET (upper-limb, i.e. default swe.rise_trans without
# BIT_DISC_CENTER - matches Astro Vision convention)
# ---------------------------------------------------------------
def sunrise_sunset(jd_ut_midnight, lat, lon):
    geopos = (lon, lat, 0)
    _, tret_rise = swe.rise_trans(jd_ut_midnight, swe.SUN, swe.CALC_RISE, geopos)
    _, tret_set = swe.rise_trans(jd_ut_midnight, swe.SUN, swe.CALC_SET, geopos)
    return tret_rise[0], tret_set[0]


def jd_to_local_str(jd_ut, tz_offset):
    y, m, d, h = swe.revjul(jd_ut)
    dt_ut = datetime(y, m, d) + timedelta(hours=h)
    dt_local = dt_ut + timedelta(hours=tz_offset)
    return dt_local.strftime("%H:%M:%S"), dt_local


# ---------------------------------------------------------------
# BIRTH HORA (planetary hour)
# ---------------------------------------------------------------
def birth_hora(birth_dt_local, sunrise_dt, sunset_dt, prev_sunset_dt, next_sunrise_dt):
    """
    birth_dt_local, sunrise_dt, sunset_dt, prev_sunset_dt, next_sunrise_dt:
    all naive local datetimes (same tz).
    Returns dict with hora lord (en/ta) and hora index (1-12).
    """
    if sunrise_dt <= birth_dt_local < sunset_dt:
        # Day hora
        day_len = (sunset_dt - sunrise_dt).total_seconds()
        hora_len = day_len / 12
        idx = int((birth_dt_local - sunrise_dt).total_seconds() // hora_len)
        weekday_en = sunrise_dt.strftime("%A")
    else:
        # Night hora
        if birth_dt_local >= sunset_dt:
            night_start = sunset_dt
            night_end = next_sunrise_dt
            weekday_en = sunrise_dt.strftime("%A")
        else:
            night_start = prev_sunset_dt
            night_end = sunrise_dt
            weekday_en = (sunrise_dt - timedelta(days=1)).strftime("%A")
        night_len = (night_end - night_start).total_seconds()
        hora_len = night_len / 12
        idx = int((birth_dt_local - night_start).total_seconds() // hora_len) + 12

    idx = max(0, min(23, idx))
    day_lord = WEEKDAY_LORD[weekday_en]
    start_pos = CHALDEAN_ORDER.index(day_lord)
    hora_lord_en = CHALDEAN_ORDER[(start_pos + idx) % 7]
    return {"hora_number": idx + 1, "lord_en": hora_lord_en}


# ---------------------------------------------------------------
# YOGI / AVAYOGI
# ---------------------------------------------------------------
def yogi_avayogi(sun_lon, moon_lon):
    yogi_point = (sun_lon + moon_lon + YOGI_OFFSET) % 360
    span = 360 / 27
    yogi_nak_idx = int(yogi_point // span)
    avayogi_nak_idx = (yogi_nak_idx - 4) % 27  # 4th nakshatra counted backward from Yogi
    yogi_lord_en = KARAKA_LORD_CYCLE[yogi_nak_idx]
    avayogi_lord_en = KARAKA_LORD_CYCLE[avayogi_nak_idx]
    return {
        "yogi_nakshatra_index": yogi_nak_idx,
        "yogi_lord_en": yogi_lord_en,
        "avayogi_nakshatra_index": avayogi_nak_idx,
        "avayogi_lord_en": avayogi_lord_en,
    }


# ---------------------------------------------------------------
# LAGNA LORD
# ---------------------------------------------------------------
def lagna_lord_en(lagna_rasi_idx):
    return RASI_LORD[lagna_rasi_idx]


# ---------------------------------------------------------------
# JAIMINI KARAKAS (Atmakaraka ... Darakaraka by degree-in-sign)
# ---------------------------------------------------------------
def jaimini_karakas(grahas_sidereal_longitudes):
    """
    grahas_sidereal_longitudes: dict {planet_name: longitude} for the 7
    classical karaka planets (Sun..Saturn, excludes Rahu/Ketu).
    Returns list sorted highest-degree-in-sign first, each item:
    {"planet_en":.., "karaka_ta":.., "degree_in_sign": float}
    """
    degs = []
    for p in KARAKA_PLANETS:
        deg_in_sign = grahas_sidereal_longitudes[p] % 30
        degs.append((p, deg_in_sign))
    degs.sort(key=lambda x: x[1], reverse=True)
    result = []
    for i, (p, d) in enumerate(degs):
        result.append({
            "planet_en": p,
            "karaka_ta": KARAKA_NAMES_TA[i],
            "degree_in_sign": round(d, 4)
        })
    return result


# ---------------------------------------------------------------
# MAIN ENTRY POINT - called from jyotish_engine.calculate_chart()
# ---------------------------------------------------------------
def calculate_panchanga(dt_local, jd_ut, tz_offset, lat, lon,
                         sun_lon, moon_lon, lagna_rasi_idx,
                         grahas_sidereal_longitudes, planet_ta_map, rasi_ta_list, nakshatra_ta_list):
    v = vaaram(dt_local)
    t = tithi_info(sun_lon, moon_lon)
    k = karana_info(sun_lon, moon_lon)
    ny = nitya_yoga_info(sun_lon, moon_lon)

    # Sunrise / sunset for birth day (local midnight -> UT JD)
    jd_midnight_ut = swe.julday(dt_local.year, dt_local.month, dt_local.day, 0.0) - tz_offset / 24
    sr_jd, ss_jd = sunrise_sunset(jd_midnight_ut, lat, lon)
    sunrise_str, sunrise_dt = jd_to_local_str(sr_jd, tz_offset)
    sunset_str, sunset_dt = jd_to_local_str(ss_jd, tz_offset)

    # previous day's sunset & next day's sunrise (for night-hora edge cases)
    jd_prev_midnight_ut = jd_midnight_ut - 1
    _, ps_jd = sunrise_sunset(jd_prev_midnight_ut, lat, lon)
    _, prev_sunset_dt = jd_to_local_str(ps_jd, tz_offset)

    jd_next_midnight_ut = jd_midnight_ut + 1
    ns_jd, _ = sunrise_sunset(jd_next_midnight_ut, lat, lon)
    _, next_sunrise_dt = jd_to_local_str(ns_jd, tz_offset)

    hora = birth_hora(dt_local, sunrise_dt, sunset_dt, prev_sunset_dt, next_sunrise_dt)
    is_day_birth = sunrise_dt <= dt_local < sunset_dt

    yv = yogi_avayogi(sun_lon, moon_lon)
    ll = lagna_lord_en(lagna_rasi_idx)
    karakas = jaimini_karakas(grahas_sidereal_longitudes)

    return {
        "is_day_birth": is_day_birth,
        "vaaram": {"ta": v["ta"], "lord_ta": planet_ta_map[v["lord"]]},
        "tithi": t,
        "karana": k,
        "nitya_yoga": ny,
        "sunrise": sunrise_str,
        "sunset": sunset_str,
        "birth_hora": {"number": hora["hora_number"], "lord_ta": planet_ta_map[hora["lord_en"]]},
        "yogi": {
            "nakshatra": nakshatra_ta_list[yv["yogi_nakshatra_index"]],
            "lord_ta": planet_ta_map[yv["yogi_lord_en"]]
        },
        "avayogi": {
            "nakshatra": nakshatra_ta_list[yv["avayogi_nakshatra_index"]],
            "lord_ta": planet_ta_map[yv["avayogi_lord_en"]]
        },
        "lagna_lord_ta": planet_ta_map[ll],
        "karakas": [
            {"karaka_ta": kk["karaka_ta"], "planet_ta": planet_ta_map[kk["planet_en"]],
             "planet_en": kk["planet_en"], "degree_in_sign": kk["degree_in_sign"]}
            for kk in karakas
        ],
        "atmakaraka_ta": planet_ta_map[karakas[0]["planet_en"]],       # அதிக பாகை பெற்ற கிரகம்
        "amatyakaraka_ta": planet_ta_map[karakas[1]["planet_en"]],
        "lowest_degree_graha_ta": planet_ta_map[karakas[-1]["planet_en"]],  # குறைந்த பாகை பெற்ற கிரகம்
    }
