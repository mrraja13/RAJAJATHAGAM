"""
Raja Jathagam - Core Jyotish Calculation Engine
Uses Swiss Ephemeris (pyswisseph) for accurate planetary positions.
Ayanamsa: Lahiri (Chitrapaksha) - standard for Tamil/Vedic astrology.
"""

import swisseph as swe
from datetime import datetime, timedelta
import panchanga

# ---------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------
swe.set_sid_mode(swe.SIDM_LAHIRI)  # Lahiri Ayanamsa - matches Tamilcube/standard panchangam

RASI_TA = ["மேஷம்", "ரிஷபம்", "மிதுனம்", "கடகம்", "சிம்மம்", "கன்னி",
           "துலாம்", "விருச்சிகம்", "தனுசு", "மகரம்", "கும்பம்", "மீனம்"]

NAKSHATRA_TA = [
    "அஸ்வினி","பரணி","கார்த்திகை","ரோகிணி","மிருகசீரிடம்","திருவாதிரை",
    "புனர்பூசம்","பூசம்","ஆயில்யம்","மகம்","பூரம்","உத்திரம்",
    "ஹஸ்தம்","சித்திரை","சுவாதி","விசாகம்","அனுஷம்","கேட்டை",
    "மூலம்","பூராடம்","உத்திராடம்","திருவோணம்","அவிட்டம்","சதயம்",
    "பூரட்டாதி","உத்திரட்டாதி","ரேவதி"
]

PLANET_TA = {
    "Sun": "சூரியன்", "Moon": "சந்திரன்", "Mars": "செவ்வாய்", "Mercury": "புதன்",
    "Jupiter": "வியாழன்", "Venus": "சுக்கிரன்", "Saturn": "சனி",
    "Rahu": "ராகு", "Ketu": "கேது", "Guligan": "குளிகன்"
}

PLANET_IDS = {
    "Sun": swe.SUN, "Moon": swe.MOON, "Mars": swe.MARS, "Mercury": swe.MERCURY,
    "Jupiter": swe.JUPITER, "Venus": swe.VENUS, "Saturn": swe.SATURN,
    "Rahu": swe.MEAN_NODE  # Ketu = Rahu + 180
}

# Vimshottari Dasa order & years
DASA_ORDER = ["Ketu", "Venus", "Sun", "Moon", "Mars", "Rahu", "Jupiter", "Saturn", "Mercury"]
DASA_YEARS = {"Ketu": 7, "Venus": 20, "Sun": 6, "Moon": 10, "Mars": 7,
              "Rahu": 18, "Jupiter": 16, "Saturn": 19, "Mercury": 17}
TOTAL_DASA_YEARS = 120

# Nakshatra lord cycle (same order as DASA_ORDER, repeating every 9 nakshatras)
NAK_LORDS = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"] * 3


def julian_day_ut(dt_local, tz_offset_hours):
    """Convert local datetime to Julian Day (UT)."""
    dt_ut = dt_local - timedelta(hours=tz_offset_hours)
    jd = swe.julday(dt_ut.year, dt_ut.month, dt_ut.day,
                     dt_ut.hour + dt_ut.minute/60 + dt_ut.second/3600)
    return jd


def get_sidereal_positions(jd_ut):
    """Return sidereal longitude (Lahiri) for all 9 grahas, plus a
    parallel dict of retrograde flags (speed < 0)."""
    flag = swe.FLG_SIDEREAL
    positions = {}
    retrograde = {}
    for name, pid in PLANET_IDS.items():
        lon, lat, dist, speed = swe.calc_ut(jd_ut, pid, flag)[0][:4]
        positions[name] = lon % 360
        retrograde[name] = speed < 0
    # Ketu = Rahu + 180 (always treated as retrograde-equivalent, like Rahu)
    positions["Ketu"] = (positions["Rahu"] + 180) % 360
    retrograde["Ketu"] = retrograde.get("Rahu", True)
    return positions, retrograde


def get_lagna(jd_ut, lat, lon):
    """Sidereal Ascendant (Lagna) longitude."""
    cusps, ascmc = swe.houses_ex(jd_ut, lat, lon, b'P', flags=swe.FLG_SIDEREAL)
    return ascmc[0] % 360


# ---------------------------------------------------------------
# GULIKA / MANDI - calibrated against Astro Vision's main graha
# table (validated 3/3 across test charts of different weekdays and
# day/night births): Sun's sidereal longitude + a weekday-based
# constant. Day-birth and night-birth use different weekday cycles.
# ---------------------------------------------------------------
GULIKA_DAY_CONST = {
    "Saturday": 12, "Friday": 36, "Thursday": 60, "Wednesday": 84,
    "Tuesday": 108, "Monday": 132, "Sunday": 156,
}
GULIKA_NIGHT_CONST = {
    "Tuesday": 192, "Monday": 216, "Sunday": 240, "Saturday": 264,
    "Friday": 288, "Thursday": 312, "Wednesday": 336,
}


def get_gulika_longitude(sun_lon, dt_local, is_day_birth):
    """Returns Gulika's sidereal longitude using the Sun + weekday-constant
    method (matches Astro Vision's main graha table)."""
    weekday_en = dt_local.strftime("%A")
    const_table = GULIKA_DAY_CONST if is_day_birth else GULIKA_NIGHT_CONST
    const = const_table[weekday_en]
    return (sun_lon + const) % 360


def rasi_of(longitude):
    """0-11 rasi index from sidereal longitude."""
    return int(longitude // 30)


def rasi_name(longitude):
    return RASI_TA[rasi_of(longitude)]


def degree_in_rasi(longitude):
    """Degree, minute, second within the rasi (0-30)."""
    d = longitude % 30
    deg = int(d)
    minute_full = (d - deg) * 60
    minute = int(minute_full)
    second = round((minute_full - minute) * 60)
    return deg, minute, second


def nakshatra_of(longitude):
    """Return (index 0-26, pada 1-4) from sidereal longitude."""
    nak_span = 360 / 27  # 13°20'
    pada_span = nak_span / 4  # 3°20'
    idx = int(longitude // nak_span)
    pada = int((longitude % nak_span) // pada_span) + 1
    return idx, pada


def format_dms(deg, minute, second):
    return f"{deg}°{minute}'{second}\""


# ---------------------------------------------------------------
# VIMSHOTTARI DASA
# ---------------------------------------------------------------
def moon_nakshatra_balance(moon_longitude):
    """Return (starting_lord, balance_years_at_birth) based on Moon's nakshatra."""
    nak_span = 360 / 27
    nak_idx = int(moon_longitude // nak_span)
    pos_in_nak = moon_longitude % nak_span
    fraction_left = 1 - (pos_in_nak / nak_span)  # fraction of nakshatra remaining
    lord = NAK_LORDS[nak_idx]
    total_years = DASA_YEARS[lord]
    balance = total_years * fraction_left
    return lord, balance


def build_mahadasa_sequence(birth_dt, moon_longitude):
    """Generate full Mahadasa sequence (120 years) starting from birth."""
    start_lord, balance_years = moon_nakshatra_balance(moon_longitude)
    start_idx = DASA_ORDER.index(start_lord)

    sequence = []
    current_date = birth_dt
    # first (partial) dasa
    end_date = current_date + timedelta(days=balance_years * 365.2425)
    sequence.append({"lord": start_lord, "start": current_date, "end": end_date,
                      "years": round(balance_years, 2)})
    current_date = end_date

    idx = start_idx
    for _ in range(8):  # remaining 8 mahadasas to complete the 120-year cycle
        idx = (idx + 1) % 9
        lord = DASA_ORDER[idx]
        years = DASA_YEARS[lord]
        end_date = current_date + timedelta(days=years * 365.2425)
        sequence.append({"lord": lord, "start": current_date, "end": end_date, "years": years})
        current_date = end_date

    return sequence


def build_antardasa(maha_lord, maha_start, maha_years):
    """Antardasa (bhukti) sequence within one mahadasa."""
    start_idx = DASA_ORDER.index(maha_lord)
    result = []
    current = maha_start
    for i in range(9):
        idx = (start_idx + i) % 9
        lord = DASA_ORDER[idx]
        # antardasa duration = (maha_years * antar_lord_years) / 120
        duration_years = (maha_years * DASA_YEARS[lord]) / TOTAL_DASA_YEARS
        end = current + timedelta(days=duration_years * 365.2425)
        result.append({"lord": lord, "start": current, "end": end,
                        "years": round(duration_years, 3)})
        current = end
    return result


def concealment_text_for(grahas, from_planet, to_planet):
    """"மறைவு" check: if to_planet's natal rasi falls 3rd/6th/8th/12th from
    from_planet's natal rasi, to_planet is said to run its dasa period
    hidden by from_planet. grahas: the chart's grahas dict (rasi_index per planet)."""
    if from_planet not in grahas or to_planet not in grahas:
        return ""
    from_idx = grahas[from_planet]["rasi_index"]
    to_idx = grahas[to_planet]["rasi_index"]
    dist = (to_idx - from_idx) % 12 + 1
    if dist in (3, 6, 8, 12):
        return f"{PLANET_TA[to_planet]} {PLANET_TA[from_planet]}-க்கு {dist}-ல் மறைந்து"
    return ""


def find_current_dasa(sequence, ref_date):
    for d in sequence:
        if d["start"] <= ref_date < d["end"]:
            return d
    return sequence[-1]


# ---------------------------------------------------------------
# MAIN CALCULATION
# ---------------------------------------------------------------
def calculate_chart(birth_date, birth_time, tz_offset, lat, lon, place_name="", overrides=None, gender=None):
    """
    birth_date: 'YYYY-MM-DD'
    birth_time: 'HH:MM' (24hr)
    tz_offset: e.g. 5.5 for IST
    lat, lon: decimal degrees
    overrides: optional dict {"Sun": longitude_degrees, ...} to manually
    correct a graha's sidereal longitude (e.g. matching Astro Vision exactly)
    instead of using the swisseph-computed value. Any planet not present
    in overrides keeps its computed value.
    """
    y, m, d = map(int, birth_date.split("-"))
    hh, mm = map(int, birth_time.split(":"))
    dt_local = datetime(y, m, d, hh, mm)

    jd_ut = julian_day_ut(dt_local, tz_offset)

    positions, retrograde_flags = get_sidereal_positions(jd_ut)
    lagna_lon = get_lagna(jd_ut, lat, lon)
    ayanamsa = swe.get_ayanamsa_ut(jd_ut)

    # Guligan (Mandi) - Sun + weekday constant, day/night birth aware.
    jd_midnight_ut_g = swe.julday(dt_local.year, dt_local.month, dt_local.day, 0.0) - tz_offset / 24
    sr_jd_g, ss_jd_g = panchanga.sunrise_sunset(jd_midnight_ut_g, lat, lon)
    _, sunrise_dt_g = panchanga.jd_to_local_str(sr_jd_g, tz_offset)
    _, sunset_dt_g = panchanga.jd_to_local_str(ss_jd_g, tz_offset)
    is_day_birth_g = sunrise_dt_g <= dt_local < sunset_dt_g
    positions["Guligan"] = get_gulika_longitude(positions["Sun"], dt_local, is_day_birth_g)

    if overrides:
        for planet, lon_override in overrides.items():
            if planet == "Lagna":
                lagna_lon = float(lon_override) % 360
            elif planet in positions:
                positions[planet] = float(lon_override) % 360

    grahas = {}
    for name, lon_val in positions.items():
        deg, minu, sec = degree_in_rasi(lon_val)
        nak_idx, pada = nakshatra_of(lon_val)
        grahas[name] = {
            "name_ta": PLANET_TA[name],
            "longitude": round(lon_val, 4),
            "rasi": rasi_name(lon_val),
            "rasi_index": rasi_of(lon_val),
            "degree": format_dms(deg, minu, sec),
            "nakshatra": NAKSHATRA_TA[nak_idx],
            "pada": pada,
            "retrograde": retrograde_flags.get(name, False),
        }

    lagna_deg, lagna_min, lagna_sec = degree_in_rasi(lagna_lon)
    lagna_nak_idx, lagna_pada = nakshatra_of(lagna_lon)
    lagna = {
        "rasi": rasi_name(lagna_lon),
        "rasi_index": rasi_of(lagna_lon),
        "degree": format_dms(lagna_deg, lagna_min, lagna_sec),
        "nakshatra": NAKSHATRA_TA[lagna_nak_idx],
        "pada": lagna_pada,
        "longitude": round(lagna_lon, 4)
    }

    # Vimshottari Dasa
    moon_lon = positions["Moon"]
    maha_sequence = build_mahadasa_sequence(dt_local, moon_lon)
    now = datetime.now()
    current_maha = find_current_dasa(maha_sequence, now)
    antar_sequence = build_antardasa(current_maha["lord"], current_maha["start"], current_maha["years"])
    current_antar = find_current_dasa(antar_sequence, now)
    pratyantar_sequence = build_antardasa(current_antar["lord"], current_antar["start"], current_antar["years"])
    current_pratyantar = find_current_dasa(pratyantar_sequence, now)
    sookshma_sequence = build_antardasa(current_pratyantar["lord"], current_pratyantar["start"], current_pratyantar["years"])
    current_sookshma = find_current_dasa(sookshma_sequence, now)
    prana_sequence = build_antardasa(current_sookshma["lord"], current_sookshma["start"], current_sookshma["years"])
    current_prana = find_current_dasa(prana_sequence, now)

    ashtakavarga = calculate_ashtakavarga(grahas, lagna["rasi_index"])

    # Bhava (house) details
    sav_by_rasi_index = [ashtakavarga["sarvashtakavarga"]["by_rasi"][RASI_TA[i]] for i in range(12)]
    bhavas = calculate_bhavas(grahas, lagna["rasi_index"], sav_by_rasi_index)

    # Yogas
    yogas = calculate_yogas(grahas)

    # Graha Summary - per-planet: house lordships, dignity (உச்சம்/நீசம்/சுயக்ஷேத்திரம்),
    # parivartana partner, ashtakavarga bindu total. Used to annotate every
    # occurrence of that planet as a dasa lord in the full dasa tree.
    RASI_LORD_REV = {}
    for idx, p in RASI_LORD.items():
        RASI_LORD_REV.setdefault(p, []).append(idx)
    EXALT_RASI = {"Sun": 0, "Moon": 1, "Mars": 9, "Mercury": 5, "Jupiter": 3, "Venus": 11, "Saturn": 6}
    DEBIL_RASI = {"Sun": 6, "Moon": 7, "Mars": 3, "Mercury": 11, "Jupiter": 9, "Venus": 5, "Saturn": 0}
    TA_TO_EN = {v: k for k, v in PLANET_TA.items()}
    parivartana_partner_en = {}
    for pair in yogas.get("parivartana", []):
        p1_ta, p2_ta = pair["pair"]
        p1_en, p2_en = TA_TO_EN.get(p1_ta), TA_TO_EN.get(p2_ta)
        if p1_en and p2_en:
            parivartana_partner_en[p1_en] = p2_en
            parivartana_partner_en[p2_en] = p1_en

    graha_summary = {}
    ashtakavarga_own_rasi_bindu = {}
    for planet in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
        parts = []
        if planet in RASI_LORD_REV:
            houses = sorted([(idx - lagna["rasi_index"]) % 12 + 1 for idx in RASI_LORD_REV[planet]])
            parts.append(",".join(str(h) for h in houses) + " அதிபதி")
        cur_rasi_idx = grahas[planet]["rasi_index"] if planet in grahas else None
        if cur_rasi_idx is not None and planet in EXALT_RASI:
            own_rasis = RASI_LORD_REV.get(planet, [])
            if cur_rasi_idx == EXALT_RASI[planet]:
                parts.append("உச்சம் பெற்று")
            elif cur_rasi_idx == DEBIL_RASI[planet]:
                parts.append("நீசமாகி")
            elif cur_rasi_idx in own_rasis:
                parts.append("சுயக்ஷேத்திரத்தில்")
        if planet in parivartana_partner_en:
            parts.append(f"{PLANET_TA[parivartana_partner_en[planet]]} உடன் பரிவர்த்தனை பெற்று")
        ta_name = PLANET_TA[planet]
        av_entry = ashtakavarga["bhinnashtakavarga"].get(ta_name)
        if av_entry and planet in grahas:
            cur_rasi_ta = grahas[planet]["rasi"]
            bindu = av_entry["by_rasi"].get(cur_rasi_ta)
            if bindu is not None:
                parts.append(f"அஷ்டகவர்க்க பலம் {bindu}")
                ashtakavarga_own_rasi_bindu[planet] = bindu
        graha_summary[planet] = " ".join(parts) + " தசா நடத்துகிறார்." if parts else ""

    # "மறைவு" (concealment) check between consecutive dasa-level lords:
    # if the later lord's natal rasi falls 3rd/6th/8th/12th from the earlier
    # lord's natal rasi (counting the earlier lord's own sign as 1st house),
    # the later lord is said to run its period "hidden" by the earlier one.
    def concealment_text(from_planet, to_planet):
        return concealment_text_for(grahas, from_planet, to_planet)

    # Concealment chain for the CURRENT running period (shown behind a
    # "மறைவு விளக்கம்" toggle button in the dashboard's current-dasa card).
    current_conceal_antar = concealment_text(current_maha["lord"], current_antar["lord"])
    current_conceal_pratyantar = concealment_text(current_antar["lord"], current_pratyantar["lord"])
    current_conceal_sookshma = concealment_text(current_pratyantar["lord"], current_sookshma["lord"])
    current_conceal_prana = concealment_text(current_sookshma["lord"], current_prana["lord"])

    # Panchanga + Karakas (Vaaram, Tithi, Yoga, Karana, Sunrise/Sunset,
    # Birth Hora, Yogi/Avayogi, Lagna Lord, Atmakaraka/Amatyakaraka)
    panchanga_data = panchanga.calculate_panchanga(
        dt_local=dt_local, jd_ut=jd_ut, tz_offset=tz_offset, lat=lat, lon=lon,
        sun_lon=positions["Sun"], moon_lon=positions["Moon"],
        lagna_rasi_idx=lagna["rasi_index"],
        grahas_sidereal_longitudes=positions,
        planet_ta_map=PLANET_TA, rasi_ta_list=RASI_TA, nakshatra_ta_list=NAKSHATRA_TA
    )

    # Karako Bhavesha Nashaya (Jaimini) - if a karaka planet is placed in
    # its own sign (i.e. it is lord of the very rasi it occupies), its
    # karakatva (significations as that karaka) is said to be "நாசம்"
    # (nullified/weakened) for that specific relationship.
    karako_bhavesha_nashaya = []
    for kk in panchanga_data["karakas"]:
        p_en = kk["planet_en"]
        if p_en in grahas and p_en in RASI_LORD_REV:
            if grahas[p_en]["rasi_index"] in RASI_LORD_REV[p_en]:
                karako_bhavesha_nashaya.append({
                    "karaka_ta": kk["karaka_ta"], "planet_ta": kk["planet_ta"],
                    "planet_en": p_en, "rasi": grahas[p_en]["rasi"]
                })

    # Varga (divisional) charts
    vargas = {}
    for code in VARGA_DEFS:
        v = calculate_varga_chart(positions, lagna_lon, code)
        vargas[code] = {
            "name_ta": VARGA_NAMES_TA[code],
            "lagna_rasi": RASI_TA[v["lagna_rasi_index"]],
            "lagna_rasi_index": v["lagna_rasi_index"],
            "grahas": {PLANET_TA[p]: {"rasi": RASI_TA[v["grahas"][p]], "rasi_index": v["grahas"][p]}
                       for p in v["grahas"]}
        }

    # Karako Nashaya (varga-specific): certain planets, when placed in
    # their own Lagna in a specific varga chart, are said to lose their
    # karakatva (significations) for that chart's purpose.
    KARAKO_NASHAYA_VARGA_RULES = {
        "D3": ["Jupiter", "Mars"],
        "D4": ["Mars"],
        "D7": ["Jupiter"],
        "D9": ["Venus"],
        "D24": ["Mercury"],
        "D12": ["Sun", "Moon"],
    }
    karako_nashaya_varga = []
    for varga_code, planet_list in KARAKO_NASHAYA_VARGA_RULES.items():
        if varga_code not in vargas:
            continue
        v = vargas[varga_code]
        for planet in planet_list:
            ta_name = PLANET_TA[planet]
            if ta_name in v["grahas"] and v["grahas"][ta_name]["rasi_index"] == v["lagna_rasi_index"]:
                karako_nashaya_varga.append({
                    "planet_ta": ta_name, "varga": varga_code,
                    "varga_name_ta": VARGA_NAMES_TA[varga_code]
                })

    # Full Antardasa + Pratyantardasa for ALL mahadasas (complete 120-year timeline)
    full_dasa_tree = []
    for maha in maha_sequence:
        antars = build_antardasa(maha["lord"], maha["start"], maha["years"])
        antar_list = []
        for antar in antars:
            pratyantars = build_antardasa(antar["lord"], antar["start"], antar["years"])
            antar_list.append({
                "lord": PLANET_TA[antar["lord"]],
                "lord_en": antar["lord"],
                "start": antar["start"].strftime("%d-%m-%Y"),
                "end": antar["end"].strftime("%d-%m-%Y"),
                "conceal": concealment_text(maha["lord"], antar["lord"]),
                "pratyantardasa": [
                    {"lord": PLANET_TA[pa["lord"]],
                     "lord_en": pa["lord"],
                     "start": pa["start"].strftime("%d-%m-%Y"),
                     "end": pa["end"].strftime("%d-%m-%Y"),
                     "years": round(pa["years"], 4),
                     "conceal": concealment_text(antar["lord"], pa["lord"])}
                    for pa in pratyantars
                ]
            })
        full_dasa_tree.append({
            "lord": PLANET_TA[maha["lord"]],
            "lord_en": maha["lord"],
            "start": maha["start"].strftime("%d-%m-%Y"),
            "end": maha["end"].strftime("%d-%m-%Y"),
            "years": maha["years"],
            "antardasa": antar_list
        })

    _vm = varga_markers(vargas, grahas, combustion_report(grahas), graha_yuddha_report(grahas), PLANET_TA)
    _vakram_vgm_pari_neecha = vakram_vargottama_parivartana_neechabhanga(
        vargas, grahas, _vm, lagna["rasi_index"], PLANET_TA
    )
    _d1_varga_comparison = varga_vs_d1_comparison(
        vargas, grahas, combustion_report(grahas), grahana_report(grahas), graha_yuddha_report(grahas), PLANET_TA
    )
    _hora_chakras = calculate_all_hora_chakras(grahas, lagna_lon)
    _dasa_chain_deities = dasa_chain_deities(grahas, {
        "current_maha_lord_en": current_maha["lord"],
        "current_antar_lord_en": current_antar["lord"],
        "current_pratyantar_lord_en": current_pratyantar["lord"],
        "current_sookshma_lord_en": current_sookshma["lord"],
        "current_prana_lord_en": current_prana["lord"],
    }, PLANET_TA)

    result = {
        "birth": {"date": birth_date, "time": birth_time, "place": place_name,
                  "lat": lat, "lon": lon, "tz": tz_offset},
        "ayanamsa": round(ayanamsa, 4),
        "lagna": lagna,
        "grahas": grahas,
        "combustion": combustion_report(grahas),
        "graha_yuddha": graha_yuddha_report(grahas),
        "grahana": grahana_report(grahas),
        "mks": mks_report(grahas, lagna["rasi_index"]),
        "mks_all_vargas": mks_report_all_vargas(vargas, PLANET_TA),
        "karako_bhavesha_nashaya": karako_bhavesha_nashaya,
        "ashtakavarga_own_rasi_bindu": ashtakavarga_own_rasi_bindu,
        "karako_nashaya_varga": karako_nashaya_varga,
        "pushkara_navamsa": pushkara_navamsa_report(grahas),
        "ashtakavarga": ashtakavarga,
        "bhavas": bhavas,
        "yogas": yogas,
        "panchanga": panchanga_data,
        "vargas": vargas,
        "varga_markers": _vm,
        "vakram_vargottama_parivartana_neechabhanga": _vakram_vgm_pari_neecha,
        "d1_varga_comparison": _d1_varga_comparison,
        "hora_chakras": _hora_chakras,
        "d3_chakras": calculate_all_d3_chakras(grahas, lagna_lon),
        "d16_chakras": calculate_all_d16_chakras(grahas, lagna_lon),
        "d24_education_facts": d24_education_facts(vargas["D24"], panchanga_data, grahas, PLANET_TA, lagna_lon),
        "d24_narrative_palan": d24_narrative_palan(vargas, PLANET_TA, _vm),
        "education_dasa_periods": _filter_periods_by_education_age(
            education_dasa_periods(full_dasa_tree, vargas, grahas, PLANET_TA, mks_report(grahas, lagna["rasi_index"])),
            birth_date
        ),
        "dasa_subject_interest": (lambda _d: {
            "always_liked": _d["always_liked"],
            "periods": _filter_periods_by_education_age(_d["periods"], birth_date)
        })(dasa_subject_interest(full_dasa_tree, PLANET_TA, panchanga_data, vargas)),
        "bhava_education_affliction_dasa": [
            {**item, "periods": _filter_periods_by_education_age(item["periods"], birth_date)}
            for item in bhava_education_affliction_dasa(vargas, _vm, full_dasa_tree, PLANET_TA)
            if _filter_periods_by_education_age(item["periods"], birth_date)
        ],
        "dasa_age_education_stage": dasa_age_education_stage(
            full_dasa_tree, birth_date, _vm, vargas,
            mks_report(grahas, lagna["rasi_index"]), PLANET_TA, only_afflicted=True,
            grahas=grahas, vargottama_list=_vakram_vgm_pari_neecha.get("vargottama")
        ),
        "d24_special_dasa_periods": (lambda _d: {
            **_d,
            "competitive_exam": _filter_periods_by_education_age(_d["competitive_exam"], birth_date),
            "award_scholarship": _filter_periods_by_education_age(_d["award_scholarship"], birth_date),
            "debt_period": _filter_periods_by_education_age(_d["debt_period"], birth_date),
            "hostel_period": _filter_periods_by_education_age(_d["hostel_period"], birth_date),
        })(d24_special_dasa_periods(vargas, full_dasa_tree, PLANET_TA, _hora_chakras)),
        "d24_teacher_school_facts": d24_teacher_school_facts(vargas, PLANET_TA),
        "varga_knowledge_and_competition": varga_knowledge_and_competition(vargas, PLANET_TA, panchanga_data),
        "moon_rasi_name_letters": moon_rasi_name_letters(grahas),
        "dasa_chain_deities": _dasa_chain_deities,
        "deity_significance_table": DEITY_SIGNIFICANCE,
        "d7_rasa_and_children": d7_rasa_and_children_report(grahas, gender),
        "d7_house_lord_rasa": d7_house_lord_rasa(vargas, grahas, PLANET_TA, lagna_lon),
        "d7_female_facts": d7_female_facts(vargas, grahas, gender, PLANET_TA, panchanga_data),
        "d7_children_count_and_rules": d7_children_count_and_rules(vargas, grahas, gender, lagna_lon, PLANET_TA),
        "d7_bhaga_lagna": d7_bhaga_lagna(vargas, gender, PLANET_TA),
        "d7_birth_and_conception_timing": d7_birth_and_conception_timing(vargas, full_dasa_tree, PLANET_TA),
        "d7_lord_connection_timing": (lambda _d: (
            {**_d,
             "periods_8_12": _filter_periods_by_education_age(_d["periods_8_12"], birth_date, max_age=45),
             "periods_8_12_2": _filter_periods_by_education_age(_d["periods_8_12_2"], birth_date, max_age=45)}
            if _d else None
        ))(d7_lord_connection_timing(vargas, grahas, full_dasa_tree, PLANET_TA)),
        "d7_manthi_position": d7_manthi_position(vargas, PLANET_TA),
        "d7_house_lord_dignity": d7_house_lord_dignity(vargas, PLANET_TA),
        "d7_fifth_lord_degree_zone": d7_fifth_lord_degree_zone_check(vargas, grahas, PLANET_TA),
        "full_life_dasa_deities": full_life_dasa_deities(full_dasa_tree, grahas, PLANET_TA),
        "d2_hora_facts": d2_hora_facts(vargas["D2"], grahas, bhavas, PLANET_TA),
        "dik_bala": dik_bala_report(grahas, lagna_lon, PLANET_TA),
        "dasa": {
            "mahadasa_sequence": [
                {"lord": PLANET_TA[x["lord"]], "start": x["start"].strftime("%d-%m-%Y"),
                 "end": x["end"].strftime("%d-%m-%Y"), "years": x["years"]}
                for x in maha_sequence
            ],
            "current_mahadasa": PLANET_TA[current_maha["lord"]],
            "current_antardasa": PLANET_TA[current_antar["lord"]],
            "current_pratyantardasa": PLANET_TA[current_pratyantar["lord"]],
            "current_sookshma": PLANET_TA[current_sookshma["lord"]],
            "current_prana": PLANET_TA[current_prana["lord"]],
            "current_maha_lord_en": current_maha["lord"],
            "current_antar_lord_en": current_antar["lord"],
            "current_pratyantar_lord_en": current_pratyantar["lord"],
            "current_sookshma_lord_en": current_sookshma["lord"],
            "current_prana_lord_en": current_prana["lord"],
            "current_period": f'{current_antar["start"].strftime("%d-%m-%Y")} – {current_antar["end"].strftime("%d-%m-%Y")}',
            "current_pratyantar_period": f'{current_pratyantar["start"].strftime("%d-%m-%Y")} – {current_pratyantar["end"].strftime("%d-%m-%Y")}',
            "current_sookshma_period": f'{current_sookshma["start"].strftime("%d-%m-%Y")} – {current_sookshma["end"].strftime("%d-%m-%Y")}',
            "current_prana_period": f'{current_prana["start"].strftime("%d-%m-%Y %H:%M")} – {current_prana["end"].strftime("%d-%m-%Y %H:%M")}',
            "current_conceal_antar": current_conceal_antar,
            "current_conceal_pratyantar": current_conceal_pratyantar,
            "current_conceal_sookshma": current_conceal_sookshma,
            "current_conceal_prana": current_conceal_prana,
            "full_tree": full_dasa_tree,
            "graha_summary": graha_summary,
        }
    }
    return result


# ---------------------------------------------------------------
# ASHTAKAVARGA (Bhinnashtakavarga + Sarvashtakavarga)
# Classical Parashari rules: for each planet, from itself, from
# the other 6 planets (excluding Rahu/Ketu), and from Lagna,
# certain rasi-offsets (1-12 counted from that reference) get a
# "bindu" (point). Standard tables below (Sun..Saturn, Lagna).
# ---------------------------------------------------------------

# Each entry: list of rasi-offsets (1-12) that receive a bindu,
# counted from the reference graha's own rasi position.
# Source: classical BAV tables (Sun's contribution to itself,
# to Moon, Mars, Mercury, Jupiter, Venus, Saturn, and Lagna) etc.

BAV_RULES = {
    "Sun": {
        "Sun":     [1,2,4,7,8,9,10,11],
        "Moon":    [3,6,10,11],
        "Mars":    [1,2,4,7,8,9,10,11],
        "Mercury": [3,5,6,9,10,11,12],
        "Jupiter": [5,6,9,11],
        "Venus":   [6,7,12],
        "Saturn":  [1,2,4,7,8,9,10,11],
        "Lagna":   [3,4,6,10,11,12],
    },
    "Moon": {
        "Sun":     [3,6,7,8,10,11],
        "Moon":    [1,3,6,7,9,10,11],
        "Mars":    [2,3,5,6,9,10,11],
        "Mercury": [1,3,4,5,7,8,10,11],
        "Jupiter": [1,4,7,8,10,11,12],
        "Venus":   [3,4,5,7,9,10,11],
        "Saturn":  [3,5,6,11],
        "Lagna":   [3,6,10,11],
    },
    "Mars": {
        "Sun":     [3,5,6,10,11],
        "Moon":    [3,6,11],
        "Mars":    [1,2,4,7,8,10,11],
        "Mercury": [3,5,6,11],
        "Jupiter": [6,10,11,12],
        "Venus":   [6,8,11,12],
        "Saturn":  [1,4,7,8,9,10,11],
        "Lagna":   [1,3,6,10,11],
    },
    "Mercury": {
        "Sun":     [5,6,9,11,12],
        "Moon":    [2,4,6,8,10,11],
        "Mars":    [1,2,4,7,8,9,10,11],
        "Mercury": [1,3,5,6,9,10,11,12],
        "Jupiter": [6,8,11,12],
        "Venus":   [1,2,3,4,5,8,9,11],
        "Saturn":  [1,2,4,7,8,9,10,11],
        "Lagna":   [1,2,4,6,8,10,11],
    },
    "Jupiter": {
        "Sun":     [1,2,3,4,7,8,9,10,11],
        "Moon":    [2,5,7,9,11],
        "Mars":    [1,2,4,7,8,10,11],
        "Mercury": [1,2,4,5,6,9,10,11],
        "Jupiter": [1,2,3,4,7,8,10,11],
        "Venus":   [2,5,6,9,10,11],
        "Saturn":  [3,5,6,12],
        "Lagna":   [1,2,4,5,6,7,9,10,11],
    },
    "Venus": {
        "Sun":     [8,11,12],
        "Moon":    [1,2,3,4,5,8,9,11,12],
        "Mars":    [3,4,6,9,11,12],
        "Mercury": [3,5,6,9,11],
        "Jupiter": [5,8,9,10,11],
        "Venus":   [1,2,3,4,5,8,9,10,11],
        "Saturn":  [3,4,5,8,9,10,11],
        "Lagna":   [1,2,3,4,5,8,9,11],
    },
    "Saturn": {
        "Sun":     [1,2,4,7,8,10,11],
        "Moon":    [3,6,11],
        "Mars":    [3,5,6,10,11,12],
        "Mercury": [6,8,9,10,11,12],
        "Jupiter": [5,6,11,12],
        "Venus":   [6,11,12],
        "Saturn":  [3,5,6,11],
        "Lagna":   [1,3,4,6,10,11],
    },
}


def bindus_for_offsets(ref_rasi_idx, offsets):
    """Given a reference rasi index (0-11) and list of offsets (1-12),
    return the set of rasi indices that get a bindu."""
    result = set()
    for off in offsets:
        target = (ref_rasi_idx + off - 1) % 12
        result.add(target)
    return result


def calculate_ashtakavarga(grahas, lagna_rasi_idx):
    """
    grahas: dict of {planet_name: {"rasi_index": int, ...}} (from calculate_chart)
    lagna_rasi_idx: int 0-11
    Returns Bhinnashtakavarga (BAV) per planet (12 rasi bindus each)
    and Sarvashtakavarga (SAV) totals per rasi.
    """
    ref_positions = {p: grahas[p]["rasi_index"] for p in
                      ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"]}
    ref_positions["Lagna"] = lagna_rasi_idx

    bav = {}  # bav[planet][rasi_idx] = bindu count (0 or 1 summed across 8 references)
    for planet in ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"]:
        counts = [0]*12
        rules = BAV_RULES[planet]
        for ref_name, offsets in rules.items():
            ref_idx = ref_positions[ref_name]
            hit_rasis = bindus_for_offsets(ref_idx, offsets)
            for r in hit_rasis:
                counts[r] += 1
        bav[planet] = {
            "by_rasi": {RASI_TA[i]: counts[i] for i in range(12)},
            "total": sum(counts)
        }

    sav_counts = [0]*12
    for planet in bav:
        for i in range(12):
            sav_counts[i] += bav[planet]["by_rasi"][RASI_TA[i]]

    sav = {RASI_TA[i]: sav_counts[i] for i in range(12)}
    sav_total = sum(sav_counts)

    return {
        "bhinnashtakavarga": {PLANET_TA[p]: bav[p] for p in bav},
        "sarvashtakavarga": {"by_rasi": sav, "total": sav_total}
    }


# ---------------------------------------------------------------
# VARGA (DIVISIONAL) CHARTS — D1 to D30
# ---------------------------------------------------------------
VARGA_DEFS = {
    "D1": 1, "D2": 2, "D3": 3, "D4": 4, "D5": 5, "D6": 6, "D7": 7,
    "D8": 8, "D9": 9, "D10": 10, "D12": 12, "D16": 16, "D20": 20,
    "D24": 24, "D27": 27, "D30": 30, "D40": 40, "D45": 45, "D60": 60
}
VARGA_NAMES_TA = {
    "D1": "ராசி", "D2": "ஹோரா", "D3": "திரேக்காணம்", "D4": "சதுர்த்தாம்சம்",
    "D5": "பஞ்சாம்சம்", "D6": "ரோகாம்சம்", "D7": "சப்தமாம்சம்",
    "D8": "அஷ்டாம்சம்", "D9": "நவாம்சம்", "D10": "தசாம்சம்",
    "D12": "துவாதசாம்சம்", "D16": "சோடசாம்சம்", "D20": "விம்சாம்சம்",
    "D24": "சித்ராம்சம்", "D27": "நட்சத்திராம்சம்", "D30": "திரிம்சாம்சம்",
    "D40": "காந்தாந்தாம்சம்", "D45": "அக்ஷவேதாம்சம்", "D60": "ஷஷ்டியாம்சம்"
}


def varga_rasi_index(longitude, n):
    """
    General Parashari varga formula (equal division method):
    Each rasi (30°) is divided into n equal parts. The varga sign is
    determined by which of the n divisions the planet falls in,
    counted from a starting sign that depends on parity/element
    of the birth rasi. For simplicity & wide compatibility we use
    the standard 'sign * n + division_index' modulo 12 rule used by
    most software for D2-D60 (equal-division / Parasara method),
    with special-cased classical starting points for D9, D10, D12, D30.
    """
    rasi = int(longitude // 30)
    frac = (longitude % 30) / 30.0  # 0..1 position within the rasi
    part = min(int(frac * n), n - 1)  # which division (0..n-1)

    if n == 1:
        return rasi

    if n == 2:  # Hora - classical Parashari rule (NOT equal division):
        # Odd signs (Aries, Gemini, Leo, Libra, Sagittarius, Aquarius):
        #   0-15° -> Leo Hora (Sun), 15-30° -> Cancer Hora (Moon)
        # Even signs (Taurus, Cancer, Virgo, Scorpio, Capricorn, Pisces):
        #   0-15° -> Cancer Hora (Moon), 15-30° -> Leo Hora (Sun)
        is_odd_sign = (rasi % 2 == 0)  # rasi index 0,2,4.. = odd-numbered signs (Aries=1st)
        deg_in_sign = longitude % 30
        first_half = deg_in_sign < 15
        if is_odd_sign:
            return 4 if first_half else 3   # Leo(4) then Cancer(3)
        else:
            return 3 if first_half else 4   # Cancer(3) then Leo(4)

    if n == 9:  # Navamsa: starts from same rasi if movable, etc. Standard rule:
        start = {0:0,3:0,6:0,9:0,  # movable -> start same sign (Aries group handled generically)
                 }
        # classical rule: starting sign = (rasi's element group) * 9 offset
        # movable(0,3,6,9)->start same sign; fixed(1,4,7,10)->start 9th from it; dual(2,5,8,11)->start 5th
        if rasi % 3 == 0:      # movable signs (Ar,Ca,Li,Cp)
            start_sign = rasi
        elif rasi % 3 == 1:    # fixed signs (Ta,Le,Sc,Aq)
            start_sign = (rasi + 8) % 12
        else:                  # dual signs (Ge,Vi,Sg,Pi)
            start_sign = (rasi + 4) % 12
        return (start_sign + part) % 12

    if n == 10:  # Dasamsa
        if rasi % 2 == 0:  # odd rasi (1st,3rd..) i.e. index even = odd sign
            start_sign = rasi
        else:
            start_sign = (rasi + 8) % 12
        return (start_sign + part) % 12

    if n == 12:  # Dwadasamsa - starts from same sign always
        return (rasi + part) % 12

    if n == 3:  # Drekkana - classical: 1st part=same sign, 2nd=5th, 3rd=9th
        offsets = [0, 4, 8]
        return (rasi + offsets[part]) % 12

    if n == 4:  # Chaturthamsa - classical: 4 parts map to the rasi's own
        # Kendra (quadrant) signs: same sign, 4th, 7th, 10th from it.
        offsets = [0, 3, 6, 9]
        return (rasi + offsets[part]) % 12

    if n == 30:  # Trimsamsa - classical UNEQUAL division: 5 planetary-owned
        # portions per sign, with different degree spans for odd vs even signs.
        deg_in_sign = longitude % 30
        is_odd_sign = (rasi % 2 == 0)  # rasi idx 0,2,4.. = odd-numbered signs (Aries=1st)
        if is_odd_sign:
            # Mars(0-5)->Aries, Saturn(5-10)->Aquarius, Jupiter(10-18)->Sagittarius,
            # Mercury(18-25)->Gemini, Venus(25-30)->Libra
            if deg_in_sign < 5: return 0
            elif deg_in_sign < 10: return 10
            elif deg_in_sign < 18: return 8
            elif deg_in_sign < 25: return 2
            else: return 6
        else:
            # Venus(0-5)->Taurus, Mercury(5-12)->Virgo, Jupiter(12-20)->Pisces,
            # Saturn(20-25)->Capricorn, Mars(25-30)->Scorpio
            if deg_in_sign < 5: return 1
            elif deg_in_sign < 12: return 5
            elif deg_in_sign < 20: return 11
            elif deg_in_sign < 25: return 9
            else: return 7

    if n == 24:  # Chaturvimsamsa (Siddhamsa) - classical: for odd signs,
        # count starts from Leo (Simha); for even signs, from Cancer (Kataka).
        # 24 parts cycle through the 12 signs twice from that starting point.
        is_odd_sign = (rasi % 2 == 0)  # rasi idx 0,2,4.. = odd-numbered signs (Aries=1st)
        start_sign = 4 if is_odd_sign else 3  # Leo(4) or Cancer(3)
        return (start_sign + part) % 12

    if n == 40:  # Khavedamsa - classical: for odd signs, count starts from
        # Aries (Mesha); for even signs, from Libra (Thulam).
        is_odd_sign = (rasi % 2 == 0)  # rasi idx 0,2,4.. = odd-numbered signs (Aries=1st)
        start_sign = 0 if is_odd_sign else 6  # Aries(0) or Libra(6)
        return (start_sign + part) % 12

    if n == 45:  # Akshavedamsa - classical: starting sign depends on
        # modality (chara/sthira/dwiswabhava), same pattern as Navamsa.
        if rasi % 3 == 0:      # movable signs (Ar,Ca,Li,Cp) -> start Aries
            start_sign = 0
        elif rasi % 3 == 1:    # fixed signs (Ta,Le,Sc,Aq) -> start Leo
            start_sign = 4
        else:                  # dual signs (Ge,Vi,Sg,Pi) -> start Sagittarius
            start_sign = 8
        return (start_sign + part) % 12

    if n == 60:  # Shashtiamsa - classical: the 60 parts progress starting
        # from the planet's own natal rasi (NOT rasi*60 - verified 3/3
        # against Astro Vision: Lagna Scorpio->Cancer, Sun Kanni->Simmam,
        # Mars Kadagam->Simmam).
        return (rasi + part) % 12

    # generic equal-division fallback for D7,D16,D20,D27
    return (rasi * n + part) % 12


def calculate_varga_chart(grahas_sidereal_longitudes, lagna_longitude, varga_code):
    """
    grahas_sidereal_longitudes: dict {planet_name: longitude}
    Returns dict {planet_name: rasi_index} plus lagna rasi_index for that varga.
    """
    n = VARGA_DEFS[varga_code]
    result = {}
    for name, lon in grahas_sidereal_longitudes.items():
        result[name] = varga_rasi_index(lon, n)
    lagna_rasi = varga_rasi_index(lagna_longitude, n)
    return {"grahas": result, "lagna_rasi_index": lagna_rasi}


# ---------------------------------------------------------------
# BHAVA (HOUSE) DETAILS
# ---------------------------------------------------------------
RASI_LORD = {
    0:"Mars",1:"Venus",2:"Mercury",3:"Moon",4:"Sun",5:"Mercury",
    6:"Venus",7:"Mars",8:"Jupiter",9:"Saturn",10:"Saturn",11:"Jupiter"
}
RASI_LORD_REV_MAIN = {}
for _rasi_idx, _lord in RASI_LORD.items():
    RASI_LORD_REV_MAIN.setdefault(_lord, []).append(_rasi_idx)
KENDRA_HOUSES = {1,4,7,10}
TRIKONA_HOUSES = {1,5,9}
DUSTHANA_HOUSES = {6,8,12}
MARAKA_HOUSES = {2,7}
UPACHAYA_HOUSES = {3,6,10,11}


def calculate_bhavas(grahas, lagna_rasi_idx, sav_by_rasi_index):
    """
    House-by-house (bhava) breakdown using whole-sign (rasi) houses
    from Lagna. Returns list of 12 house dicts.
    """
    houses = []
    for house_num in range(1, 13):
        rasi_idx = (lagna_rasi_idx + house_num - 1) % 12
        lord_en = RASI_LORD[rasi_idx]
        occupants = [p for p in grahas if grahas[p]["rasi_index"] == rasi_idx]
        tags = []
        if house_num in KENDRA_HOUSES: tags.append("கேந்திரஸ்தானம்")
        if house_num in TRIKONA_HOUSES: tags.append("திரிகோணஸ்தானம்")
        if house_num in DUSTHANA_HOUSES: tags.append("துஸ்தானம்")
        if house_num in MARAKA_HOUSES: tags.append("மாரகஸ்தானம்")
        if house_num in UPACHAYA_HOUSES: tags.append("உபசயஸ்தானம்")
        houses.append({
            "house_num": house_num,
            "rasi": RASI_TA[rasi_idx],
            "rasi_index": rasi_idx,
            "lord_ta": PLANET_TA[lord_en],
            "occupants_ta": [PLANET_TA[p] for p in occupants],
            "ashtakam": sav_by_rasi_index[rasi_idx],
            "tags": tags
        })
    return houses


# ---------------------------------------------------------------
# YOGAS: Parivartana, Graha combination (conjunction), mutual aspect
# ---------------------------------------------------------------
MAIN_PLANETS = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"]


def find_parivartana(grahas):
    """Sign-exchange: planet A sits in planet B's sign and vice versa."""
    result = []
    checked = set()
    for p1 in MAIN_PLANETS:
        r1 = grahas[p1]["rasi_index"]
        lord1 = RASI_LORD[r1]
        if lord1 in MAIN_PLANETS and lord1 != p1:
            r2 = grahas[lord1]["rasi_index"]
            lord2 = RASI_LORD[r2]
            if lord2 == p1:
                pair = tuple(sorted([p1, lord1]))
                if pair not in checked:
                    checked.add(pair)
                    result.append({"pair": [PLANET_TA[pair[0]], PLANET_TA[pair[1]]]})
    return result


def find_conjunctions(grahas):
    """Two or more planets in the same rasi."""
    by_rasi = {}
    for p in MAIN_PLANETS + ["Rahu","Ketu"]:
        r = grahas[p]["rasi_index"]
        by_rasi.setdefault(r, []).append(p)
    result = []
    for r, plist in by_rasi.items():
        if len(plist) >= 2:
            result.append({"rasi": RASI_TA[r], "planets": [PLANET_TA[p] for p in plist]})
    return result


SPECIAL_ASPECTS = {
    "Mars": [3, 7],       # additional to 6 (7th): 4th(idx+3) and 8th(idx+7)
    "Jupiter": [4, 8],    # additional: 5th(idx+4) and 9th(idx+8)
    "Saturn": [2, 9],     # additional: 3rd(idx+2) and 10th(idx+9)
}


# ---------------------------------------------------------------
# ASTANGATA (Combustion) - a planet too close to the Sun loses its
# strength. Classical orb (degrees) within which a planet is considered
# combust (இந்த தூரத்துக்குள் இருந்தால் அஸ்தங்கமாகும்):
# ---------------------------------------------------------------
COMBUST_ORB = {
    "Moon": 10.0, "Mars": 10.0, "Mercury": 10.0,
    "Jupiter": 10.0, "Venus": 10.0, "Saturn": 10.0,
}


def combustion_report(grahas):
    """Returns {planet: {"distance": float, "combust": bool, "direction": str}}
    for the 6 planets that can be combust (Sun/Rahu/Ketu excluded). Uses
    each planet's sidereal longitude vs Sun's, shortest angular distance,
    plus whether it is approaching the Sun (behind) or has crossed past it
    (ahead), within ±10° either side."""
    if "Sun" not in grahas:
        return {}
    sun_lon = grahas["Sun"]["longitude"]
    report = {}
    for planet, orb in COMBUST_ORB.items():
        if planet not in grahas:
            continue
        diff = abs(grahas[planet]["longitude"] - sun_lon) % 360
        distance = min(diff, 360 - diff)
        # signed difference in range (-180, 180]: negative = planet is
        # behind the Sun (approaching), positive = planet is ahead (has passed)
        signed = ((grahas[planet]["longitude"] - sun_lon + 180) % 360) - 180
        if signed < 0:
            direction = "நெருங்குகிறது"
        elif signed > 0:
            direction = "கடந்துவிட்டது"
        else:
            direction = "சரியாக இணைந்துள்ளது"
        report[planet] = {
            "distance": round(distance, 2),
            "combust": distance <= orb,
            "orb_used": orb,
            "direction": direction,
        }
    return report


# ---------------------------------------------------------------
# GRAHA YUDDHA (Planetary War) - when two of the 5 "star" planets
# (Mars, Mercury, Jupiter, Venus, Saturn - Sun/Moon/Rahu/Ketu excluded)
# come within 1° of longitude of each other, they are said to be in
# war. The one with the lower longitude (further west/behind) within
# the pair is classically held to win (varies by tradition; some use
# southern latitude - we use the simpler, more commonly cited degree rule).
# ---------------------------------------------------------------
YUDDHA_PLANETS = ["Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
YUDDHA_ORB = 1.0


def graha_yuddha_report(grahas):
    """Returns a list of {"pair": [p1, p2], "winner": p, "distance": float}
    for any pair of the 5 yuddha-eligible planets within 1° of each other."""
    result = []
    for i, p1 in enumerate(YUDDHA_PLANETS):
        for p2 in YUDDHA_PLANETS[i + 1:]:
            if p1 not in grahas or p2 not in grahas:
                continue
            diff = abs(grahas[p1]["longitude"] - grahas[p2]["longitude"]) % 360
            distance = min(diff, 360 - diff)
            if distance <= YUDDHA_ORB:
                winner = p1 if grahas[p1]["longitude"] < grahas[p2]["longitude"] else p2
                result.append({
                    "pair": [p1, p2], "winner": winner, "distance": round(distance, 3)
                })
    return result


# ---------------------------------------------------------------
# GRAHANA YOGA/DOSHA (Eclipse combination) - Sun or Moon conjunct
# Rahu or Ketu in the same rasi (classical basic check).
# ---------------------------------------------------------------
GRAHANA_PAIRS_BASE = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]


GRAHANA_ORB = 10.0


def grahana_report(grahas):
    """Returns a list of {"pair": [p1, p2], "rasi": str, "distance": float}
    for any planet + Rahu/Ketu pair within 10° of each other."""
    result = []
    for p1 in GRAHANA_PAIRS_BASE:
        for p2 in ("Rahu", "Ketu"):
            if p1 not in grahas or p2 not in grahas:
                continue
            diff = abs(grahas[p1]["longitude"] - grahas[p2]["longitude"]) % 360
            distance = min(diff, 360 - diff)
            if distance <= GRAHANA_ORB:
                result.append({
                    "pair": [p1, p2], "rasi": grahas[p1]["rasi"], "distance": round(distance, 2)
                })
    return result


# ---------------------------------------------------------------
# MARANA KARAKA STHANA (MKS) - classical house position at which
# each planet is said to become a "death-inflicting" significator
# (its dasa/bhukti periods are considered especially challenging).
# ---------------------------------------------------------------
MKS_HOUSE = {
    "Sun": [12], "Moon": [8], "Mars": [7], "Mercury": [4, 7],
    "Jupiter": [3], "Venus": [6], "Saturn": [1], "Rahu": [9], "Ketu": [4],
}


def mks_report(grahas, lagna_rasi_idx):
    """Returns a list of {"planet": p, "house": n} for every planet
    currently placed in one of its own Marana Karaka Sthana houses.
    (D1/Rasi chart only - see mks_report_all_vargas for all D-charts.)"""
    result = []
    for planet, mks_houses in MKS_HOUSE.items():
        if planet not in grahas:
            continue
        house = (grahas[planet]["rasi_index"] - lagna_rasi_idx) % 12 + 1
        if house in mks_houses:
            result.append({"planet": planet, "house": house})
    return result


def mks_report_all_vargas(vargas, planet_ta_map):
    """Checks MKS across every varga (D1-D60): for each varga chart,
    uses that chart's OWN lagna and planet positions to determine each
    planet's house, and flags it if that house matches its MKS list.
    Returns a list of {"planet": p, "planet_ta": str, "varga": code,
    "varga_name_ta": str, "house": n}."""
    result = []
    for varga_code, vdata in vargas.items():
        lagna_r = vdata["lagna_rasi_index"]
        for planet, mks_houses in MKS_HOUSE.items():
            ta_name = planet_ta_map.get(planet)
            if not ta_name or ta_name not in vdata["grahas"]:
                continue
            planet_rasi = vdata["grahas"][ta_name]["rasi_index"]
            house = (planet_rasi - lagna_r) % 12 + 1
            if house in mks_houses:
                result.append({
                    "planet": planet, "planet_ta": ta_name,
                    "varga": varga_code, "varga_name_ta": VARGA_NAMES_TA.get(varga_code, varga_code),
                    "house": house
                })
    return result


# ---------------------------------------------------------------
# PUSHKARA NAVAMSA (unverified against Astro Vision - flagged for
# calibration, similar to how Mandi/Gulika needed test-chart tuning).
# Best-available classical rule: within each rasi's own navamsa
# (D9) subdivision (9 padas of 3°20' each), specific padas are
# "Pushkara" (auspicious) depending on the rasi's modality:
#   Chara (movable)   rasis -> padas 3, 5
#   Sthira (fixed)    rasis -> padas 5, 7
#   Dwiswabhava (dual) rasis -> padas 1, 3
# ---------------------------------------------------------------
CHARA_RASI = {0, 3, 6, 9}       # Mesha, Kataka, Thulam, Makaram
STHIRA_RASI = {1, 4, 7, 10}     # Rishabam, Simmam, Viruchikam, Kumbam
DWISWABHAVA_RASI = {2, 5, 8, 11}  # Mithunam, Kanni, Dhanusu, Meenam

PUSHKARA_PADA = {
    "chara": [3, 5],
    "sthira": [5, 7],
    "dwiswabhava": [1, 3],
}


def pushkara_navamsa_report(grahas):
    """Returns a list of {"planet": p, "pada": n, "rasi": str} for every
    planet whose navamsa (D9) pada falls in the Pushkara pada list for
    its current rasi's modality. NOT YET VERIFIED against Astro Vision -
    treat as provisional, same caution as the Mandi calibration."""
    result = []
    real_planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]
    for planet in real_planets:
        if planet not in grahas:
            continue
        g = grahas[planet]
        rasi_idx = g["rasi_index"]
        deg_in_sign = g["longitude"] % 30
        pada = int(deg_in_sign // (30 / 9)) + 1  # 1-9
        if rasi_idx in CHARA_RASI:
            modality = "chara"
        elif rasi_idx in STHIRA_RASI:
            modality = "sthira"
        else:
            modality = "dwiswabhava"
        if pada in PUSHKARA_PADA[modality]:
            result.append({"planet": planet, "pada": pada, "rasi": g["rasi"]})
    return result


# ---------------------------------------------------------------
# Exaltation/Debilitation table (module-level, reused by graha_summary
# and by varga_markers below).
# ---------------------------------------------------------------
EXALT_RASI_TABLE = {"Sun": 0, "Moon": 1, "Mars": 9, "Mercury": 5, "Jupiter": 3, "Venus": 11, "Saturn": 6}
DEBIL_RASI_TABLE = {"Sun": 6, "Moon": 7, "Mars": 3, "Mercury": 11, "Jupiter": 9, "Venus": 5, "Saturn": 0}


VARGA_KARAKA_TABLE = {
    "D3": "Mars", "D4": "Mars", "D7": "Jupiter",
}  # Confirmed by user: D3=Mars, D4=Mars, D7=Jupiter. Other vargas'
   # karakas remain unset until confirmed - unverified guesses were
   # showing incorrect info.

VARGA_NUMBER_HOUSE = {"D2": 2, "D3": 3, "D4": 4, "D7": 7, "D9": 9, "D10": 10, "D12": 12}
# only these vargas have a varga-number <= 12 that maps directly onto a house number


def varga_vs_d1_comparison(vargas, grahas, combustion, grahana, graha_yuddha, planet_ta_map):
    """Six-rule cross-check between D1 and every varga chart:
    1. Varga Lagna should not fall in 3/6/8/12 (house) from D1 Lagna.
    2. Astangam/Grahanam/Graha-Yuddha planets should not occupy that
       varga's own Lagna.
    3. That varga's own Lagna-lord should not be in 3/6/8/12 from that
       varga's own Lagna.
    4. Natural malefics (Saturn, Rahu, Ketu, Mars, Sun) should not
       occupy that varga's own Lagna.
    5. That varga's designated significator (Varga Karaka) should not
       be afflicted (combust / debilitated in that varga / in 3,6,8,12
       from that varga's Lagna / in graha yuddha). Table mostly UNVERIFIED
       beyond D3=Mars, D7=Jupiter which the user confirmed.
    6. For vargas D2-D12 (where varga-number maps directly to a house
       number), that SAME-numbered house's lord (in that varga) should
       not be afflicted, same affliction definition as rule 5.
    """
    combust_planets = {p for p, d in combustion.items() if d.get("combust")}
    grahana_planets = set()
    for item in grahana:
        grahana_planets.update(item["pair"])
    yuddha_planets = set()
    for item in graha_yuddha:
        yuddha_planets.update(item["pair"])
    afflicting_planets = combust_planets | grahana_planets | yuddha_planets
    natural_malefics = {"Saturn", "Rahu", "Ketu", "Mars", "Sun"}

    d1_lagna_idx = vargas["D1"]["lagna_rasi_index"]

    def is_afflicted(planet_en, varga_data):
        """Rule 5/6 affliction check for a given planet within a varga."""
        if planet_en in afflicting_planets:
            return True, "அஸ்தங்கம்/கிரகணம்/கிரகயுத்தம்"
        ta = planet_ta_map.get(planet_en)
        ginfo = varga_data["grahas"].get(ta) if ta else None
        if not ginfo:
            return False, ""
        if DEBIL_RASI_TABLE.get(planet_en) == ginfo["rasi_index"]:
            return True, "நீசம்"
        house = (ginfo["rasi_index"] - varga_data["lagna_rasi_index"]) % 12 + 1
        if house in (3, 6, 8, 12):
            return True, f"{house}-ம் வீட்டில் (3/6/8/12)"
        return False, ""

    results = {"rule1": [], "rule2": [], "rule3": [], "rule4": [], "rule5": [], "rule6": [], "rule7": [], "rule8": []}

    for varga_code, vdata in vargas.items():
        if varga_code == "D1":
            continue
        v_lagna = vdata["lagna_rasi_index"]
        varga_name_ta = VARGA_NAMES_TA.get(varga_code, varga_code)

        # Rule 1
        house_from_d1 = (v_lagna - d1_lagna_idx) % 12 + 1
        if house_from_d1 in (3, 6, 8, 12):
            results["rule1"].append({
                "varga": varga_code, "varga_name_ta": varga_name_ta,
                "text": f"{varga_name_ta} ({varga_code}) லக்னம், D1 லக்னத்திலிருந்து {house_from_d1}-ம் வீட்டில் (3/6/8/12)"
            })

        # Rule 2
        for planet_en in afflicting_planets:
            ta = planet_ta_map.get(planet_en)
            ginfo = vdata["grahas"].get(ta) if ta else None
            if ginfo and ginfo["rasi_index"] == v_lagna:
                results["rule2"].append({
                    "varga": varga_code, "varga_name_ta": varga_name_ta,
                    "text": f"{varga_name_ta} ({varga_code}) லக்னத்தில் {ta} (பாதிக்கப்பட்ட கிரகம்) அமர்ந்துள்ளார்"
                })

        # Rule 3
        v_lagna_lord = RASI_LORD.get(v_lagna)
        if v_lagna_lord:
            lord_ta = planet_ta_map[v_lagna_lord]
            lord_info = vdata["grahas"].get(lord_ta)
            if lord_info:
                lord_house = (lord_info["rasi_index"] - v_lagna) % 12 + 1
                if lord_house in (3, 6, 8, 12):
                    results["rule3"].append({
                        "varga": varga_code, "varga_name_ta": varga_name_ta,
                        "text": f"{varga_name_ta} ({varga_code}) லக்னாதிபதி {lord_ta}, {lord_house}-ம் வீட்டில் (3/6/8/12)"
                    })

        # Rule 4 - combine all malefics found in this varga's Lagna into one line
        malefics_here = []
        for planet_en in natural_malefics:
            ta = planet_ta_map.get(planet_en)
            ginfo = vdata["grahas"].get(ta) if ta else None
            if ginfo and ginfo["rasi_index"] == v_lagna:
                malefics_here.append(ta)
        if malefics_here:
            results["rule4"].append({
                "varga": varga_code, "varga_name_ta": varga_name_ta,
                "text": f"{varga_code} லக்னத்தில் {', '.join(malefics_here)}"
            })

        # Rule 5
        karaka_en = VARGA_KARAKA_TABLE.get(varga_code)
        if karaka_en:
            afflicted, reason = is_afflicted(karaka_en, vdata)
            if afflicted:
                results["rule5"].append({
                    "varga": varga_code, "varga_name_ta": varga_name_ta,
                    "text": f"{varga_name_ta} ({varga_code})-ன் வர்க்க காரகர் {planet_ta_map[karaka_en]}, {reason}"
                })

        # Rule 6
        house_num = VARGA_NUMBER_HOUSE.get(varga_code)
        if house_num:
            house_rasi = (v_lagna + house_num - 1) % 12
            house_lord_en = RASI_LORD.get(house_rasi)
            if house_lord_en:
                afflicted, reason = is_afflicted(house_lord_en, vdata)
                if afflicted:
                    results["rule6"].append({
                        "varga": varga_code, "varga_name_ta": varga_name_ta,
                        "text": f"{varga_name_ta} ({varga_code})-ன் {house_num}-ம் பாவ காரகர் {planet_ta_map[house_lord_en]}, {reason}"
                    })

        # Rule 7: Karako Bhava Nasti - this varga's own designated Karaka
        # sitting right in its own Lagna (the very house it signifies)
        karaka_en_r7 = VARGA_KARAKA_TABLE.get(varga_code)
        if karaka_en_r7:
            karaka_ta_r7 = planet_ta_map[karaka_en_r7]
            karaka_rasi_r7 = vdata["grahas"].get(karaka_ta_r7, {}).get("rasi_index")
            if karaka_rasi_r7 == v_lagna:
                results["rule7"].append({
                    "varga": varga_code, "varga_name_ta": varga_name_ta,
                    "text": f"{varga_name_ta} ({varga_code})-ன் காரகர் {karaka_ta_r7}, லக்னத்திலேயே அமர்ந்துள்ளதால் காரகோ பாவநாசாய்"
                })

        # Rule 8: Asubha Kartari - natural malefics in BOTH the 2nd and
        # 12th houses (from that varga's own Lagna), "sandwiching" the Lagna
        second_rasi = (v_lagna + 1) % 12
        twelfth_rasi = (v_lagna - 1) % 12
        second_malefics = [planet_ta_map[p] for p in natural_malefics
                            if vdata["grahas"].get(planet_ta_map[p], {}).get("rasi_index") == second_rasi]
        twelfth_malefics = [planet_ta_map[p] for p in natural_malefics
                             if vdata["grahas"].get(planet_ta_map[p], {}).get("rasi_index") == twelfth_rasi]
        if second_malefics and twelfth_malefics:
            results["rule8"].append({
                "varga": varga_code, "varga_name_ta": varga_name_ta,
                "text": f"{varga_name_ta} ({varga_code}) லக்னத்திற்கு அசுபகத்தரி — 2-ம் வீட்டில் {', '.join(second_malefics)}, 12-ம் வீட்டில் {', '.join(twelfth_malefics)}"
            })

    return results


def vakram_vargottama_parivartana_neechabhanga(vargas, grahas, varga_markers_data, lagna_rasi_idx, planet_ta_map):
    """Consolidated cross-varga summary for the D1 button:
    - vakram: which of the 7 classical planets are retrograde (natural
      property, same in every chart, so listed once).
    - vargottama: planets whose D1 rasi == D9 (Navamsa) rasi.
    - parivartana: which planets show 'ப' (parivartana) marker, and in
      which vargas.
    - neecha_bhanga: for a debilitated ('நீ') planet in a varga, checks
      the most commonly cited condition - the lord of its debilitation
      sign is in a Kendra (1,4,7,10) from either the Lagna or the Moon
      (of THAT SAME varga). Other classical sub-rules exist too; this
      covers the most frequently used one - flagged as provisional.
    """
    classical_7 = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]

    vakram = [planet_ta_map[p] for p in classical_7 if grahas.get(p, {}).get("retrograde")]

    vargottama = []
    if "D1" in vargas and "D9" in vargas:
        for p in classical_7 + ["Rahu", "Ketu"]:
            ta = planet_ta_map[p]
            d1_r = vargas["D1"]["grahas"].get(ta, {}).get("rasi_index")
            d9_r = vargas["D9"]["grahas"].get(ta, {}).get("rasi_index")
            if d1_r is not None and d1_r == d9_r:
                vargottama.append(ta)

    parivartana_by_varga = {}
    for varga_code, marks in varga_markers_data.items():
        planets_with_p = [planet_ta_map[p] for p, m in marks.items() if "ப" in m]
        if planets_with_p:
            parivartana_by_varga[varga_code] = planets_with_p

    neecha_bhanga = []
    for varga_code, marks in varga_markers_data.items():
        if varga_code not in vargas:
            continue
        v = vargas[varga_code]
        moon_ta = planet_ta_map["Moon"]
        moon_rasi = v["grahas"].get(moon_ta, {}).get("rasi_index")
        v_lagna = v["lagna_rasi_index"]
        for planet_en, m in marks.items():
            if "நீ" not in m or planet_en not in DEBIL_RASI_TABLE:
                continue
            debil_rasi = DEBIL_RASI_TABLE[planet_en]
            debil_lord = RASI_LORD.get(debil_rasi)
            if not debil_lord:
                continue
            lord_ta = planet_ta_map[debil_lord]
            lord_rasi = v["grahas"].get(lord_ta, {}).get("rasi_index")
            if lord_rasi is None:
                continue
            house_from_lagna = (lord_rasi - v_lagna) % 12 + 1
            house_from_moon = (lord_rasi - moon_rasi) % 12 + 1 if moon_rasi is not None else None
            lagna_ok = house_from_lagna in KENDRA_HOUSES
            moon_ok = (house_from_moon in KENDRA_HOUSES) if house_from_moon else False
            if lagna_ok or moon_ok:
                debil_rasi_ta = RASI_TA[debil_rasi]
                reasons = []
                if lagna_ok:
                    reasons.append(f"லக்னத்திலிருந்து {house_from_lagna}-ம் வீடு (கேந்திரம்)")
                if moon_ok:
                    reasons.append(f"சந்திரனிலிருந்து {house_from_moon}-ம் வீடு (கேந்திரம்)")
                explanation = (
                    f"{planet_ta_map[planet_en]} {debil_rasi_ta}-ல் நீசமடைந்துள்ளார். "
                    f"ஆனால் {debil_rasi_ta}-ன் அதிபதி {lord_ta}, {' மற்றும் '.join(reasons)} இருப்பதால், "
                    f"இந்த நீச தோஷம் நீசபங்கமாக மாறுகிறது."
                )
                neecha_bhanga.append({
                    "planet_ta": planet_ta_map[planet_en], "varga": varga_code,
                    "varga_name_ta": VARGA_NAMES_TA.get(varga_code, varga_code),
                    "explanation": explanation
                })

    return {
        "vakram": vakram,
        "vargottama": vargottama,
        "parivartana_by_varga": parivartana_by_varga,
        "neecha_bhanga": neecha_bhanga,
    }


def varga_markers(vargas, grahas, combustion, graha_yuddha, planet_ta_map):
    """Returns {varga_code: {planet_en: "marker_string"}} where marker
    letters are concatenated per planet, per varga:
      நீ = debilitated in that varga's rasi
      உ  = exalted in that varga's rasi
      வ  = naturally retrograde (same across all vargas)
      அஸ் = combust (Sun-proximity, same across all vargas)
      யு = in graha yuddha (planetary war, same across all vargas)
      கீ = conjunct Rahu/Ketu in that SAME varga's rasi
      ப  = parivartana (sign exchange) with that varga's rasi lord
    """
    combust_planets = {p for p, d in combustion.items() if d.get("combust")}
    yuddha_planets = set()
    for item in graha_yuddha:
        yuddha_planets.update(item["pair"])

    result = {}
    for varga_code, vdata in vargas.items():
        vmarks = {}
        rahu_rasi = vdata["grahas"].get("ராகு", {}).get("rasi_index")
        ketu_rasi = vdata["grahas"].get("கேது", {}).get("rasi_index")
        # Build english-keyed rasi map for this varga, for parivartana check
        varga_rasi_en = {}
        for p_ta, ginfo in vdata["grahas"].items():
            p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
            if p_en:
                varga_rasi_en[p_en] = ginfo["rasi_index"]
        for planet_ta, ginfo in vdata["grahas"].items():
            planet_en = next((k for k, v in planet_ta_map.items() if v == planet_ta), None)
            if not planet_en:
                continue
            marks = []
            if EXALT_RASI_TABLE.get(planet_en) == ginfo["rasi_index"]:
                marks.append("உ")
            if DEBIL_RASI_TABLE.get(planet_en) == ginfo["rasi_index"]:
                marks.append("நீ")
            if grahas.get(planet_en, {}).get("retrograde"):
                marks.append("வ")
            if planet_en in combust_planets:
                marks.append("அஸ்")
            if planet_en in yuddha_planets:
                marks.append("யு")
            if planet_en not in ("Rahu", "Ketu") and ginfo["rasi_index"] in (rahu_rasi, ketu_rasi):
                marks.append("கீ")
            # Parivartana: this planet's rasi-lord (in this varga) is a
            # classical planet that, in turn, sits in THIS planet's own rasi.
            if planet_en in RASI_LORD_REV_MAIN:  # only classical 7 have sign lordship
                lord_of_current_rasi = RASI_LORD.get(ginfo["rasi_index"])
                if lord_of_current_rasi and lord_of_current_rasi != planet_en and lord_of_current_rasi in varga_rasi_en:
                    lord_own_rasi = varga_rasi_en[lord_of_current_rasi]
                    if lord_own_rasi in RASI_LORD_REV_MAIN.get(planet_en, []):
                        marks.append("ப")
            if marks:
                vmarks[planet_en] = "".join(marks)
        result[varga_code] = vmarks
    return result


def graha_drishti(planet, rasi_idx):
    """Classical graha drishti: every planet aspects the 7th house from its
    own position; Mars/Jupiter/Saturn have additional special aspects.
    Returns a set of rasi indices (0-11) aspected by this planet."""
    aspected = {(rasi_idx + 6) % 12}  # 7th aspect, all planets
    for offset in SPECIAL_ASPECTS.get(planet, []):
        aspected.add((rasi_idx + offset) % 12)
    return aspected


def find_mutual_aspect_7th(grahas):
    """Planets exactly opposite (7th from each other) — simple mutual aspect check."""
    result = []
    checked = set()
    for p1 in MAIN_PLANETS:
        for p2 in MAIN_PLANETS:
            if p1 >= p2:
                continue
            r1 = grahas[p1]["rasi_index"]
            r2 = grahas[p2]["rasi_index"]
            if (r2 - r1) % 12 == 6:
                pair = tuple(sorted([p1, p2]))
                if pair not in checked:
                    checked.add(pair)
                    result.append({"pair": [PLANET_TA[pair[0]], PLANET_TA[pair[1]]]})
    return result


def find_6_8_12_relation(grahas):
    """Planet pairs in 6/8/12 relationship from each other (considered afflictive)."""
    result = []
    checked = set()
    for p1 in MAIN_PLANETS:
        for p2 in MAIN_PLANETS:
            if p1 >= p2:
                continue
            r1 = grahas[p1]["rasi_index"]
            r2 = grahas[p2]["rasi_index"]
            diff = (r2 - r1) % 12
            if diff in (5, 7, 11):  # 6th(5), 8th(7), 12th(11) offsets
                pair = tuple(sorted([p1, p2]))
                if pair not in checked:
                    checked.add(pair)
                    result.append({"pair": [PLANET_TA[pair[0]], PLANET_TA[pair[1]]]})
    return result


D24_TWELFTH_HOUSE_NOTES = {
    "Sun": "ஈகோ, தந்தை பெருமை பேசுதல்",
    "Moon": "உதவி செய்தல், மருத்துவமனை செல்லுதல், தேநீர்/காபி/தண்ணீர் வாங்கித் தருதல்",
    "Mars": "சுறுசுறுப்பு, நேரத்தை சரியாகப் பின்பற்றுதல்",
    "Mercury": "எப்போதும் கணக்கு பார்த்து செயல்படுதல்",
    "Jupiter": "ஆசிரியருடன் அதிக தொடர்பு, அதிக அறிவுரை வழங்குதல்",
    "Venus": "பெண்கள் அருகில் அமருதல், வாசனைத் திரவியங்கள்/சுத்தமான ஆடை",
    "Saturn": "சோம்பல், கடைசி ஆளாக வருதல், வகுப்பில் தூங்குதல்",
    "Rahu": "அதிக பேச்சு/வளவளப்பு (பலமானால்)",
    "Ketu": "அமைதி/அடக்கி வாசித்தல் (பலமானால்)",
}


# ---------------------------------------------------------------
# 11 named "Hora Chakra" lookup tables (from VCJV varga chakra
# jyotish reference). Each maps (rasi_index 0-11, half 0/1) -> the
# resulting Hora rasi (0-11), read off the printed table columns
# மே,ரிஷ,மிது,கட,சிம்,கன்,துலா,விருச்,தனு,மகர,கும்,மீன (Aries..Pisces)
# and rows 0-15°/15-30°. Values transcribed as 1-12 in the source,
# converted to 0-11 here.
# ---------------------------------------------------------------
def _tbl(row0_15, row15_30):
    return {"first_half": [v - 1 for v in row0_15], "second_half": [v - 1 for v in row15_30]}


HORA_CHAKRAS = {
    "பராசர ஹோரா சக்கரம்": _tbl(
        [5, 4, 5, 4, 5, 4, 5, 4, 5, 4, 5, 4],
        [4, 5, 4, 5, 4, 5, 4, 5, 4, 5, 4, 5]),
    "காசிநாத் ஹோரா சக்கரம்": _tbl(
        [8, 2, 6, 4, 5, 3, 7, 1, 12, 10, 11, 9],
        [1, 7, 3, 5, 4, 6, 2, 8, 9, 11, 10, 12]),
    "பரி விருத்தித்வய ஹோரா சக்கரம்": _tbl(
        [1, 3, 5, 7, 9, 11, 1, 3, 5, 7, 9, 11],
        [2, 4, 6, 8, 10, 12, 2, 4, 6, 8, 10, 12]),
    "லாப மன்டூக ஹோரா சக்கரம்": _tbl(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        [11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
    "ஜகநாத் ஹோரா சக்கரம்": _tbl(
        [7, 2, 9, 4, 5, 12, 7, 2, 9, 4, 5, 12],
        [1, 8, 3, 10, 11, 6, 1, 8, 3, 10, 11, 6]),
    "சமஸப்தக ஹோரா சக்கரம்": _tbl(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        [7, 8, 9, 10, 11, 12, 1, 2, 3, 4, 5, 6]),
    "ராமன் ஹோரா சக்கரம்": _tbl(
        [8, 2, 6, 4, 5, 3, 7, 1, 12, 10, 11, 9],
        [10, 12, 1, 7, 3, 4, 5, 6, 2, 8, 9, 11]),
    "மன்டூக ஹோரா சக்கரம்": _tbl(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2]),
    "நிரஞ்சன் ஹோரா சக்கரம்": _tbl(
        [6, 3, 5, 5, 7, 2, 12, 9, 11, 10, 8, 1],
        [1, 8, 10, 11, 9, 12, 2, 7, 4, 4, 3, 6]),
    "உமா சாம்பு ஹோரா சக்கரம்": _tbl(
        [1, 4, 5, 8, 9, 12, 1, 4, 5, 8, 9, 12],
        [2, 3, 6, 7, 10, 11, 2, 3, 6, 7, 10, 11]),
    "பூர்வ பராசரி ஹோரா சக்கரம்": _tbl(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1]),
}


def hora_chakra_rasi(chakra_name, longitude):
    rasi = int(longitude // 30)
    deg_in_sign = longitude % 30
    tbl = HORA_CHAKRAS[chakra_name]
    return tbl["first_half"][rasi] if deg_in_sign < 15 else tbl["second_half"][rasi]


def calculate_all_hora_chakras(grahas, lagna_lon):
    """Returns {chakra_name: {"lagna_rasi_index": n, "grahas": {name_ta: {"rasi","rasi_index"}}}}
    for all 11 named Hora Chakra systems."""
    result = {}
    for name in HORA_CHAKRAS:
        lagna_r = hora_chakra_rasi(name, lagna_lon)
        g_out = {}
        for p, g in grahas.items():
            r = hora_chakra_rasi(name, g["longitude"])
            g_out[g["name_ta"]] = {"rasi": RASI_TA[r], "rasi_index": r}
        result[name] = {"lagna_rasi_index": lagna_r, "lagna_rasi": RASI_TA[lagna_r], "grahas": g_out}
    return result


# ---------------------------------------------------------------
# Named D3 (Drekkana) Chakra lookup tables (VCJV reference), 3 parts
# of 10° each per rasi (0-10 / 10-20 / 20-30).
# ---------------------------------------------------------------
def _tbl3(row1, row2, row3):
    return {"p0": [v - 1 for v in row1], "p1": [v - 1 for v in row2], "p2": [v - 1 for v in row3]}


D3_CHAKRAS = {
    "பராசர திரேகாணம் (PD3)": _tbl3(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        [5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3, 4],
        [9, 10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8]),
    "ஜெகன்நாத் திரேகாணம் (JD3)": _tbl3(
        [1, 10, 7, 4, 1, 10, 7, 4, 1, 10, 7, 4],
        [5, 2, 11, 8, 5, 2, 11, 8, 5, 2, 11, 8],
        [9, 6, 3, 12, 9, 6, 3, 12, 9, 6, 3, 12]),
    "சோம்நாத் திரேகாணம் (SD3)": _tbl3(
        [1, 12, 4, 9, 7, 6, 10, 3, 1, 12, 4, 9],
        [2, 11, 5, 8, 8, 5, 11, 2, 2, 11, 5, 8],
        [3, 10, 6, 7, 9, 4, 12, 1, 3, 10, 6, 7]),
    "பரிவிருத்தி த்வய திரேகாணம் (வாரணாசி)": _tbl3(
        [1, 4, 7, 10, 1, 4, 7, 10, 1, 4, 7, 10],
        [2, 5, 8, 11, 2, 5, 8, 11, 2, 5, 8, 11],
        [3, 6, 9, 12, 3, 6, 9, 12, 3, 6, 9, 12]),
}


def d3_chakra_rasi(chakra_name, longitude):
    rasi = int(longitude // 30)
    deg_in_sign = longitude % 30
    tbl = D3_CHAKRAS[chakra_name]
    if deg_in_sign < 10:
        return tbl["p0"][rasi]
    elif deg_in_sign < 20:
        return tbl["p1"][rasi]
    else:
        return tbl["p2"][rasi]


def calculate_all_d3_chakras(grahas, lagna_lon):
    """Returns {chakra_name: {"lagna_rasi_index","lagna_rasi","grahas": {...}}}
    for all named D3 (Drekkana) chakra systems."""
    result = {}
    for name in D3_CHAKRAS:
        lagna_r = d3_chakra_rasi(name, lagna_lon)
        g_out = {}
        for p, g in grahas.items():
            r = d3_chakra_rasi(name, g["longitude"])
            g_out[g["name_ta"]] = {"rasi": RASI_TA[r], "rasi_index": r}
        result[name] = {"lagna_rasi_index": lagna_r, "lagna_rasi": RASI_TA[lagna_r], "grahas": g_out}
    return result


# ---------------------------------------------------------------
# Named D16 (Shodashamsa) Chakra lookup tables (VCJV reference),
# 12 rows of 2.5° each per rasi (as printed - 0-2.5, 2.5-5, ... 27.5-30).
# ---------------------------------------------------------------
def _tblN(*rows):
    return [[v - 1 for v in row] for row in rows]


D16_CHAKRAS = {
    "பராசர ஹோடசாம்சம் (D16)": _tblN(
        [1, 5, 9, 1, 5, 9, 1, 5, 9, 1, 5, 9],
        [2, 6, 10, 2, 6, 10, 2, 6, 10, 2, 6, 10],
        [3, 7, 11, 3, 7, 11, 3, 7, 11, 3, 7, 11],
        [4, 8, 12, 4, 8, 12, 4, 8, 12, 4, 8, 12],
        [5, 9, 1, 5, 9, 1, 5, 9, 1, 5, 9, 1],
        [6, 10, 2, 6, 10, 2, 6, 10, 2, 6, 10, 2],
        [7, 11, 3, 7, 11, 3, 7, 11, 3, 7, 11, 3],
        [8, 12, 4, 8, 12, 4, 8, 12, 4, 8, 12, 4],
        [9, 1, 5, 9, 1, 5, 9, 1, 5, 9, 1, 5],
        [10, 2, 6, 10, 2, 6, 10, 2, 6, 10, 2, 6],
        [11, 3, 7, 11, 3, 7, 11, 3, 7, 11, 3, 7],
        [12, 4, 8, 12, 4, 8, 12, 4, 8, 12, 4, 8]),
    "மந்திரேஷ்வரர் ஹோடசாம்சம் (H.R.Sesathri Iyer)": _tblN(
        [1, 5, 3, 7, 5, 9, 7, 11, 9, 1, 11, 3],
        [2, 4, 4, 6, 6, 8, 8, 10, 10, 12, 12, 2],
        [3, 3, 5, 5, 7, 7, 9, 9, 11, 11, 1, 1],
        [4, 2, 6, 4, 8, 6, 10, 8, 12, 10, 2, 12],
        [5, 1, 7, 3, 9, 5, 11, 7, 1, 9, 3, 11],
        [6, 12, 8, 2, 10, 4, 12, 6, 2, 8, 4, 10],
        [7, 11, 9, 1, 11, 3, 1, 5, 3, 7, 5, 9],
        [8, 10, 10, 12, 12, 2, 2, 4, 4, 6, 6, 8],
        [9, 9, 11, 11, 1, 1, 3, 3, 5, 5, 7, 7],
        [10, 8, 12, 10, 2, 12, 4, 2, 6, 4, 8, 6],
        [11, 7, 1, 9, 3, 11, 5, 1, 7, 3, 9, 5],
        [12, 6, 2, 8, 4, 10, 6, 12, 8, 2, 10, 4]),
}


def d16_chakra_rasi(chakra_name, longitude):
    rasi = int(longitude // 30)
    deg_in_sign = longitude % 30
    row_idx = min(int(deg_in_sign // 2.5), 11)
    return D16_CHAKRAS[chakra_name][row_idx][rasi]


def calculate_all_d16_chakras(grahas, lagna_lon):
    """Returns {chakra_name: {"lagna_rasi_index","lagna_rasi","grahas": {...}}}
    for all named D16 (Shodashamsa) chakra systems."""
    result = {}
    for name in D16_CHAKRAS:
        lagna_r = d16_chakra_rasi(name, lagna_lon)
        g_out = {}
        for p, g in grahas.items():
            r = d16_chakra_rasi(name, g["longitude"])
            g_out[g["name_ta"]] = {"rasi": RASI_TA[r], "rasi_index": r}
        result[name] = {"lagna_rasi_index": lagna_r, "lagna_rasi": RASI_TA[lagna_r], "grahas": g_out}
    return result


# ---------------------------------------------------------------
# DIK BALA (Directional Strength) - based on which 7°30' zone the
# LAGNA's own degree-in-sign falls into:
#   0°-7°30'   -> Jupiter & Mercury get Dik Bala if placed in house 1 (Lagna)
#   7°30'-15°  -> Moon & Venus get Dik Bala if placed in house 4
#   15°-22°30' -> Saturn gets Dik Bala if placed in house 7
#   22°30'-30° -> Mars & Sun get Dik Bala if placed in house 10
# ---------------------------------------------------------------
DIK_BALA_ZONES = [
    (0, 7.5, {"Jupiter": 1, "Mercury": 1}),
    (7.5, 15, {"Moon": 4, "Venus": 4}),
    (15, 22.5, {"Saturn": 7}),
    (22.5, 30, {"Mars": 10, "Sun": 10}),
]


def dik_bala_report(grahas, lagna_lon, planet_ta_map):
    """Returns {planet_en: {"planet_ta": str, "house": int, "has_dik_bala": bool}}
    for the 7 classical planets, using the LAGNA-degree zone rule above."""
    lagna_deg_in_sign = lagna_lon % 30
    lagna_rasi_idx = int(lagna_lon // 30)
    active_zone_planets = {}
    for lo, hi, planet_house_map in DIK_BALA_ZONES:
        if lo <= lagna_deg_in_sign < hi:
            active_zone_planets = planet_house_map
            break

    all_planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]
    result = {}
    for planet in all_planets:
        if planet not in grahas:
            continue
        house = (grahas[planet]["rasi_index"] - lagna_rasi_idx) % 12 + 1
        required_house = active_zone_planets.get(planet)
        has_dik_bala = (required_house is not None and house == required_house)
        result[planet] = {
            "planet_ta": planet_ta_map[planet],
            "house": house,
            "has_dik_bala": has_dik_bala,
        }
    return result


def d2_hora_facts(vargas_d2, grahas, bhavas, planet_ta_map):
    """Rule-based (template) D2 (Hora) wealth-pattern reading, based on
    classical Parashari Hora principles. Sun Hora = Simha(Leo), Moon Hora
    = Kataka(Cancer). Returns a list of Tamil sentences - no AI call."""
    d2_lagna_idx = vargas_d2["lagna_rasi_index"]
    d2_grahas = vargas_d2["grahas"]  # Tamil name -> {"rasi","rasi_index"}
    CANCER, LEO = 3, 4  # rasi indices

    def hora_of(rasi_idx):
        return "சூரிய ஹோரா" if rasi_idx == LEO else ("சந்திர ஹோரா" if rasi_idx == CANCER else None)

    def lord_ta_of_house(house_num):
        b = next((x for x in bhavas if x["house_num"] == house_num), None)
        return b["lord_ta"] if b else None

    def lord_d2_hora(house_num):
        lord_ta = lord_ta_of_house(house_num)
        if not lord_ta or lord_ta not in d2_grahas:
            return lord_ta, None
        return lord_ta, hora_of(d2_grahas[lord_ta]["rasi_index"])

    lines = []

    # Lagna & Lagna lord Hora
    lagna_hora = hora_of(d2_lagna_idx)
    lines.append(f"D2 லக்னம்: {'சூரிய ஹோரா' if lagna_hora=='சூரிய ஹோரா' else ('சந்திர ஹோரா' if lagna_hora=='சந்திர ஹோரா' else 'மற்ற ராசி')}")
    lagna_lord_ta, lagna_lord_hora = lord_d2_hora(1)
    if lagna_lord_hora:
        lines.append(f"லக்னாதிபதி ({lagna_lord_ta}) D2-ல் {lagna_lord_hora}-ல் — 50/50 கலவை பலன்")

    # 1,5,9 lords - effort vs ease
    for h in (1, 5, 9):
        lt, hora = lord_d2_hora(h)
        if hora == "சூரிய ஹோரா":
            lines.append(f"{h}-ம் அதிபதி ({lt}) சூரிய ஹோராவில் — பெரிய முயற்சி/உழைப்பு மூலம் செல்வம்")
        elif hora == "சந்திர ஹோரா":
            lines.append(f"{h}-ம் அதிபதி ({lt}) சந்திர ஹோராவில் — சிரமமில்லாமல், எளிதாக செல்வம்")

    # 2nd lord Hora + "hiding" check (2nd lord's D2 rasi is the D2 12th house)
    lt2, hora2 = lord_d2_hora(2)
    if hora2 == "சூரிய ஹோரா":
        lines.append(f"2-ம் அதிபதி ({lt2}) சூரிய ஹோராவில் — கடின உழைப்பு மூலம் தனம்")
    elif hora2 == "சந்திர ஹோரா":
        lines.append(f"2-ம் அதிபதி ({lt2}) சந்திர ஹோராவில் — எளிதாக தனம் வரும்")
    if lt2 and lt2 in d2_grahas:
        d2_12th_rasi = (d2_lagna_idx + 11) % 12
        if d2_grahas[lt2]["rasi_index"] == d2_12th_rasi:
            lines.append(f"⚠️ D1-ன் 2-ம் அதிபதி ({lt2}) D2-ல் 12-ம் வீட்டில் மறைந்துள்ளார் — இதனால் தனம் முழுமையாக உதவாமல் போகலாம்")

    # 3rd, 4th lords Hora
    for h in (3, 4):
        lt, hora = lord_d2_hora(h)
        if hora == "சூரிய ஹோரா":
            lines.append(f"{h}-ம் அதிபதி ({lt}) சூரிய ஹோராவில் — அந்த காரகத்துவம் மூலம் கடின உழைப்பு தேவை")
        elif hora == "சந்திர ஹோரா":
            lines.append(f"{h}-ம் அதிபதி ({lt}) சந்திர ஹோராவில் — அந்த காரகத்துவம் மூலம் எளிதாக வருமானம்")

    # Rahu/Ketu placement in D2 (lagna / 2nd / 12th)
    d2_2nd_rasi = (d2_lagna_idx + 1) % 12
    d2_12th_rasi = (d2_lagna_idx + 11) % 12
    for node in ("ராகு", "கேது"):
        if node in d2_grahas:
            r = d2_grahas[node]["rasi_index"]
            if r == d2_lagna_idx:
                lines.append(f"D2 லக்னத்தில் {node} — சொந்த உறவினர்களால் தன விஷயத்தில் பாதிப்பு ஏற்படலாம்")
            elif r in (d2_2nd_rasi, d2_12th_rasi):
                lines.append(f"{node} D2-ல் 2/12-ம் வீட்டில் — வெளியாட்களால் தன விஷயத்தில் பாதிப்பு ஏற்படலாம்")

    # Cancer vs Leo planet count in D2 - local vs foreign earning
    cancer_count = sum(1 for g in d2_grahas.values() if g["rasi_index"] == CANCER)
    leo_count = sum(1 for g in d2_grahas.values() if g["rasi_index"] == LEO)
    if cancer_count > leo_count:
        lines.append(f"D2-ல் கடகத்தில் அதிக கிரகங்கள் ({cancer_count}) — வெளியூரில் தனம் சம்பாதிக்கும் சாத்தியம்")
    elif leo_count > cancer_count:
        lines.append(f"D2-ல் சிம்மத்தில் அதிக கிரகங்கள் ({leo_count}) — பிறந்த ஊரிலேயே தனம் சம்பாதிக்கும் சாத்தியம்")
    if cancer_count >= 3 and d2_lagna_idx == CANCER:
        lines.append("D2 லக்னமும் கடகமாகவும், கடகத்தில் பல கிரகங்களும் இருப்பதால் — பூர்வீக வழியில் செல்வம் வரலாம் (பெரிய முயற்சி இல்லாமல்)")
    if leo_count >= 2 and d2_lagna_idx == CANCER:
        lines.append("D1 2-ம் அதிபதி D2-ல் லக்னம் கடகமாகி, சிம்மத்தில் பல கிரகங்கள் — சுய முயற்சி/சுய சம்பாத்தியம் மூலம் தனம்")

    # Sun-Moon parivartana check within D2 positions (Sun in Cancer AND Moon in Leo)
    if "சூரியன்" in d2_grahas and "சந்திரன்" in d2_grahas:
        if d2_grahas["சூரியன்"]["rasi_index"] == CANCER and d2_grahas["சந்திரன்"]["rasi_index"] == LEO:
            lines.append("சூரியன்-சந்திரன் D2-ல் பரிவர்த்தனை பெற்றுள்ளனர் — செழிப்பான, செல்வமுடைய பொருளாதார வளர்ச்சிக்கு நல்ல அறிகுறி")

    # Mercury Hora placement (odd/male vs even/female D1 rasi)
    if "Mercury" in grahas and "புதன்" in d2_grahas:
        merc_d1_rasi = grahas["Mercury"]["rasi_index"]
        merc_d2_hora = hora_of(d2_grahas["புதன்"]["rasi_index"])
        is_male_rasi = (merc_d1_rasi % 2 == 0)
        good_combo = (is_male_rasi and merc_d2_hora == "சூரிய ஹோரா") or (not is_male_rasi and merc_d2_hora == "சந்திர ஹோரா")
        if merc_d2_hora:
            lines.append(f"புதன் D1-ல் {'ஆண்' if is_male_rasi else 'பெண்'} ராசியில், D2-ல் {merc_d2_hora}-ல் — " +
                         ("நல்ல அமைப்பு" if good_combo else "இந்த rule-படி சிறப்பான அமைப்பு இல்லை"))

    return lines


PLANET_LANGUAGE = {
    "Sun": "ஆங்கிலம்",
    "Moon": "தமிழ் வழிக் கல்வி, வட்டாரக் கல்வி, பிராந்திய மொழி",
    "Jupiter": "சமஸ்கிருதம், இந்தி",
    "Rahu": "அரபி, உருது",
    "Ketu": "சமஸ்கிருதம், இந்தி, உருது",
}

PLANET_SCHOOL_MEDIUM = {
    "Sun": "அரசு பள்ளி (Government School)",
    "Venus": "பிரைவேட் பள்ளி, டிரைவிங் ஸ்கூல்",
    "Jupiter": "Trust School, மடம் சார்ந்த பள்ளி",
    "Rahu": "முஸ்லீம் ஸ்கூல்",
    "Ketu": "கிறிஸ்தவ ஸ்கூல்",
    "Mars": "மிலிட்டரி School, சென்ட்ரல் கவர்மெண்ட் School, சைனிக் School",
    "Mercury": "Matriculation School",
}

RASI_SUBJECT_KARAKATVA = {
    0: "சர ராசி, அக்னி தத்துவம். லக்னம் 4/2-ல் உள்ளதைச் சார்ந்த படிப்பு, லக்னாதிபதி இருக்கும் இடத்தைச் சார்ந்த படிப்பு (சூரியன், செவ்வாய் காரகத்துவம்)",
    1: "ஸ்திர ராசி, பூமி தத்துவம். உணவு சார்ந்த தொழில், Nutritionist, Agriculture, அழகியல், இசை, நாடகம், Fine Arts, Fashion Designing, Beautician, Costume Designer, Animation, Building Designing, Cosmetics, Textiles",
    2: "வாயு தத்துவம், உபய ராசி. கணிதம், CA, Auditor, Accountancy, ஜோதிடம்/Astrology, White collar job, Voice over job",
    3: "சர ராசி, நீர் ராசி (சந்திரன் ஆட்சி). Medical, Nursing, உணவு சார்ந்த படிப்பு, Poultry, வேளாண் சயின்ஸ், தாய்-சேய் நலன், Nutritionist, விவசாயம், நீர் மேலாண்மை, மீன் வளர்ப்பு, Marine, கப்பல் சார்ந்த படிப்பு",
    4: "அக்னி ராசி, ஸ்திர ராசி (சூரியன் ஆட்சி). நிர்வாகம், Administration Management, அரசு சார்ந்த படிப்புகள், Forest, MBA, MCA, Medical, மருந்தியல்",
    5: "பூமி தத்துவம், உபய ராசி. கணிதம், Commerce, Auditor, Accountancy, ஜோதிடம், Journalism, Clerical job, Law (புத்தியுடன் கூடிய தர்க்கம்)",
    6: "சர ராசி, வாயு தத்துவம். Law, Business Law, BBA, Management, Fashion Designing, Gold Appraiser, Fine Arts",
    7: "நீர் தத்துவம், ஸ்திர ராசி (8-ம் மிடம்). மறைபொருள் விஞ்ஞானம், ஆராய்ச்சி, Mining, Chemistry, Pharma Medical, LAB, CID/CBI, கடற்படை, Finger Print Science, Chemical Engineering, ரசாயனம், அணுசக்தி",
    8: "அக்னி ராசி, உபய ராசி (குரு வீடு). Bank, ஆசிரியர்/பேராசிரியர், Journalism, Veterinary Doctor, பொருளாதாரம், வழக்கறிஞர், HR, அர்ச்சகர்/புரோகிதர், ஆன்மீகம், Publishing",
    9: "பூமி தத்துவம், உபய ராசி. நிலக்கரி மேலாண்மை, Environmental Mining, Science, விவசாயம், அகழ்வாராய்ச்சி படிப்பு, Pollution, Metal/Mineral சம்பந்தப்பட்ட படிப்பு",
    10: "ஸ்திர ராசி, வாயு தத்துவம். Lawyers, ஆசிரியர், அகழ்வாராய்ச்சி (மகரத்திற்கு சொன்ன அனைத்தும் பொருந்தும்)",
    11: "உபய ராசி, நீர் ராசி. ஆசிரியர், ஆன்மீகம், Finance, Medicine, மீன் வளர்ப்பு, வெளிநாட்டு கல்வி, Medical officers, Bio Technology, Micro Biology, வெளிநாடு சம்பந்தப்பட்ட படிப்புகள்",
}

PLANET_SUBJECT_KARAKATVA = {
    "Sun": "மருத்துவம், அரசியல், மேலாண்மை, நிர்வாகம், கட்டமைப்பு, உடலநலம், இயற்பியல், வானியல், வனவியல், விலங்கியல், ஆங்கிலம், Law, MBA, MCA, Political Science",
    "Moon": "மொழியியல், பெண்கள் நலன், கடல்/நர்சிங், நீர் மேலாண்மை, மருத்துவர் பணி, உணவியல், சமூகவியல், தாய்மொழி, தாவரவியல், உளவியல், வேளாண்மை, தோட்டக்கலை, பயாலஜி, Hotel Management, Tourism",
    "Mars": "தொழில்நுட்பம், இயந்திரவியல், அறுவை சிகிச்சை, Army, Physics, Political Science, Computer Hardware, Electrical, Metallurgy, வேதியியல், Weapons, பொறியியல், விளையாட்டு",
    "Mercury": "கணிதம், வர்த்தகம், பொருளாதாரக் கல்வி, Audit, Coding, ஜோதிடம், Commerce, CA, Social Science, இலக்கியம், மொழிகள், Computer Science, தொலைவுக் கல்வி",
    "Jupiter": "சட்டம், புலமை, இந்தி, Social Science, நிதிசாஸ்திரம், Journalism, வங்கி, தத்துவம், மதம், ஆன்மிகம், பொருளாதாரம், HR, B.Ed/M.Ed, ஆன்மிகக் கல்வி",
    "Venus": "Administration, Product Design, Visual Communication, Fashion Technology, Fine Arts (இயல்/இசை/நாடகம்), Textiles, Business Administration, Hotel Management, Botany, கவிதை, Software Development",
    "Saturn": "கட்டுமானத்துறை, Civil Engineering, Concrete Building Materials, Computer Hardware, Physiotherapy, Mining, அரசியல், வரலாறு, இயற்பியல், தொல்பொருள் ஆய்வு, ஆங்கிலம்",
    "Rahu": "Bio Technology, Electronics, Chemical, Computer Hardware, Law, வெளிநாட்டு மொழிகள், Computer Science, Toxicology, உளவியல், மருத்துவம், AI, Micro-related subjects, தடயவியல்",
    "Ketu": "Political Science, சமஸ்கிருதம், இந்தி, உருது, Bio Technology, Hypnotism, Nano Technology, Lab, Micro subjects, Metallurgy, Computer Hardware",
}


NATURAL_BENEFICS = {"Jupiter", "Venus", "Mercury", "Moon"}
NATURAL_MALEFICS = {"Sun", "Mars", "Saturn", "Rahu", "Ketu"}


BHAVA_EDUCATION_STAGE = {
    1: "லக்னம் - விருப்பம், கற்றல் திறன்",
    2: "LKG, UKG, Master degree",
    3: "தொலைதூரக் கல்வி",
    4: "10-ம் வகுப்பு வரை (1 முதல் 10 வரை)",
    5: "11, 12-ம் வகுப்பு, புத்தி கூர்மை",
    6: "காம்பிடிட்டிவ் எக்ஸாம் (Competitive Exam)",
    7: "முனைவர் படிப்பு M.Phil, Ph.D Research",
    8: "Real PhD",
    9: "UG (இளநிலை பட்டப்படிப்பு)",
    10: "Diploma, ITI, தொழிற்கல்வி",
    11: "Award, Scholarship, மெடல்",
    12: "டியூஷன், ஈவினிங்/நைட் காலேஜ், டுடோரியல், Pre-KG",
}
SPORTS_HOUSES = {3, 6, 10, 11}


RASI_NAME_LETTERS = {
    0: "சு, சே, சோ, லா, லீ, லூ, லே, லோ, அ",       # மேஷம்
    1: "இ, உ, ஏ, ஓ, வா, வி, வு, வே, வோ",           # ரிஷபம்
    2: "கா, கி, கு, கூ, க்க, கெ, கே, கோ",           # மிதுனம்
    3: "ஹி, ஹூ, ஹே, ஹோ, டா, டீ, டூ",                # கடகம்
    4: "மா, மீ, மூ, மே, மோ, டா, டி",                 # சிம்மம்
    5: "பா, பீ, பூ, ஷ, ண, பே, போ",                   # கன்னி
    6: "ரா, ரி, ரு, ரே, ரோ, தா",                     # துலாம்
    7: "நா, நீ, நூ, நே, நோ, யா, யு",                # விருச்சிகம்
    8: "யே, யோ, ப, பி, பு, பூ",                      # தனுசு
    9: "போ, ஜா, ஜி, கி, கோ, கு",                     # மகரம்
    10: "கூ, கே, கோ, சா, சி, சு, சே, சோ",            # கும்பம்
    11: "தி, து, தே, தோ, ச, சி, சு",                 # மீனம்
}  # ⚠️ ஒரு Instagram post screenshot-ல் இருந்து transcribe செய்யப்பட்டது -
   # சிறிய எழுத்துக்கள் தெளிவற்றதால், exact-ஆ verify பண்ணிக்கொள்ளவும்.


DEITY_SIGNIFICANCE = {
    "ஸ்கந்தன் (Skanda)": "கூர்மையான அறிவு, தர்க்க சக்தி, பொறியியல் (Engineering), இராணுவம், மருத்துவம், போட்டித் தேர்வுகளில் முதன்மை",
    "பரசுதரன் (Parashudhara)": "சட்டக் கல்வி (Law), நீதி, ஆயுதப் பயிற்சி, கடுமையான கட்டுப்பாடு, அநீதியை எதிர்க்கும் ஆராய்ச்சி அறிவு",
    "அனலன் (Anala)": "வேதியியல் (Chemistry), ஆற்றல் துறை, மாற்றம் தரும் கண்டுபிடிப்புகள், ஆராய்ச்சி, கூர்மையான கிரகிப்புத் திறன்",
    "விஸ்வகர்மா (Vishwakarma)": "கட்டிடக்கலை (Architecture), மென்பொருள் வடிவமைப்பு, இயந்திரவியல், கைவினை, உற்பத்தித் திறன்",
    "பகன் (Bhaga)": "நிதி மேலாண்மை (Finance), பொருளாதாரம், பொருள்சார் கல்வி, செல்வம் ஈட்டும் உத்திகள், நிர்வாகத் திறன்",
    "மித்திரன் (Mitra)": "மக்கள் மேலாண்மை (PR), ராஜதந்திரம், சர்வதேச உறவுகள், தொடர்பியல், சமூக அறிவியல்",
    "மாயன் (Maya)": "மாயக் கலைகள், கணினி நிரலாக்கம் (Coding/AI), கிராபிக்ஸ், அனிமேஷன், உளவியல் (Psychology)",
    "அந்தகன் (Antaka)": "தடயவியல் (Forensics), மரபியல், ரகசிய ஆய்வுகள், தத்துவார்த்த கல்வி, சுயக் கட்டுப்பாடு",
    "விருஷத்வஜன் (Vrishadhwaja)": "ஆன்மீக உயர் கல்வி, யோகா, மெய்ஞானம், வேத ஆகம அறிவு, ஆழ்ந்த தியான ஆராய்ச்சி",
    "கோவிந்தன் (Govinda)": "வணிகவியல் (Commerce), மேலாண்மை, தர்ம சாஸ்திரம், கல்வி நிறுவனங்கள் நடத்துதல்",
    "மதனன் (Madana)": "நுண்கலைகள் (Fine Arts), இசை, நடனம், கவிதை, ஒப்பனை, ஊடகம் (Media), படைப்பாற்றல்",
    "பீமன் (Bhima)": "காயகல்பம், உடற்கல்வி, விளையாட்டு, அறுவை சிகிச்சை (Surgery), பெரும் சவால்களை எதிர்கொள்ளும் மனதிடம்",
}

D24_DEITY_TABLE = [
    ("ஸ்கந்தன் (Skanda)", "பீமன் (Bhima)"),
    ("பரசுதரன் (Parashudhara)", "மதனன் (Madana)"),
    ("அனலன் (Anala)", "கோவிந்தன் (Govinda)"),
    ("விஸ்வகர்மா (Vishwakarma)", "விருஷத்வஜன் (Vrishadhwaja)"),
    ("பகன் (Bhaga)", "அந்தகன் (Antaka)"),
    ("மித்திரன் (Mitra)", "மாயன் (Maya)"),
    ("மாயன் (Maya)", "மித்திரன் (Mitra)"),
    ("அந்தகன் (Antaka)", "பகன் (Bhaga)"),
    ("விருஷத்வஜன் (Vrishadhwaja)", "விஸ்வகர்மா (Vishwakarma)"),
    ("கோவிந்தன் (Govinda)", "அனலன் (Anala)"),
    ("மதனன் (Madana)", "பரசுதரன் (Parashudhara)"),
    ("பீமன் (Bhima)", "ஸ்கந்தன் (Skanda)"),
]  # 12 unique odd/even pairs, repeating every 15° (divisions 1-12 = 0-15°, 13-24 = 15-30°)


D7_RASA_NAMES = [
    "ஹர சப்தாம்சம் (பஞ்ச கவ்யம், உப்பு)",
    "சீர் சப்தாம்சம் (பால்)",
    "தானிச சப்தாம்சம் (தயிர்)",
    "ஆஜ்யம் (நெய்)",
    "ரஸ சப்தாம்சம் (கரும்பு சாறு)",
    "மதுரஸம் (ஒயின், தேன்)",
    "சுத்த ஜலம்",
]  # 7 equal divisions of 30/7 = 4°17'08.57" each, in D1-sign order

D7_RASA_NOTES = {
    "ஹர சப்தாம்சம் (பஞ்ச கவ்யம், உப்பு)": "பிடிவாதம், முரட்டுத்தனம், கசப்பு தன்மை. குழந்தைகள் வழியில் சில சவால்கள், தாமதங்கள் அல்லது கவலைகள் ஏற்படலாம்.",
    "சீர் சப்தாம்சம் (பால்)": "பால் போன்ற தன்மை, மிதமான இனிப்பு, நல்ல குணம். குழந்தைகள் அன்பாகவும், பெற்றோருக்குப் பெருமை சேர்க்கும் நற்குணத்துடனும் திகழ்வர்.",
    "தானிச சப்தாம்சம் (தயிர்)": "நல்ல தன்மை. சுறுசுறுப்பான, அழகான மற்றும் தைரியமான குழந்தைகள் அமைவர்.",
    "ஆஜ்யம் (நெய்)": "ஆன்மிகம், மதம் மீது நம்பிக்கை, பெற்றோருக்கு பெயர்/புகழ் சேர்ப்பது. குழந்தைகள் ஆன்மீக ஈடுபாடு, நல்ல ஒழுக்கம் மற்றும் சமூகத்தில் உயர்ந்த மதிப்பு அடைவர்.",
    "ரஸ சப்தாம்சம் (கரும்பு சாறு)": "இனிமையானவர், ஆனால் கரும்பு போல முரட்டுத்தனமும் உண்டு. பெற்றோருக்கு ஆதரவாக இருப்பார்கள்.",
    "மதுரஸம் (ஒயின், தேன்)": "உல்லாச பேர்வழி. கலை, மகிழ்ச்சி மற்றும் திறமை நிறைந்த குழந்தைகள் அமைவர்.",
    "சுத்த ஜலம்": "தங்கமான குணம், யார் வம்பு/தும்புக்கும் போகாதவர். தூய்மையான எண்ணம், நேர்மை கொண்ட குழந்தைகள் அமைய வாய்ப்புண்டு.",
}


def d7_rasa_of(longitude):
    """Returns the D7 Sapta-Rasa (7 taste/essence divisions, 4°17'08.57"
    each) name for a given D1 longitude - facts only reference."""
    deg_in_sign = longitude % 30
    division = int(deg_in_sign // (30 / 7))
    division = min(division, 6)
    return D7_RASA_NAMES[division]


CHILDREN_HOUSE_BY_GENDER = {
    "male": {5: "முதல் குழந்தை (1st Child)", 7: "இரண்டாம் குழந்தை (2nd Child)", 9: "மூன்றாம் குழந்தை (3rd Child)"},
    "female": {9: "முதல் குழந்தை (1st Child)", 7: "இரண்டாம் குழந்தை (2nd Child)", 5: "மூன்றாம் குழந்தை (3rd Child)"},
}


NATURAL_ENEMIES = {
    "Sun": {"Venus", "Saturn"}, "Moon": set(), "Mars": {"Mercury"},
    "Mercury": {"Moon"}, "Jupiter": {"Mercury", "Venus"},
    "Venus": {"Sun", "Moon"}, "Saturn": {"Sun", "Moon", "Mars"},
}  # Naisargika (natural/permanent) Maitri table - classical, standard.


D27_MALE_RASI = {0, 3, 4, 6, 8, 11}   # மேஷம், கடகம், சிம்மம், துலாம், தனுசு, மீனம்
D27_FEMALE_RASI = {1, 2, 5, 7, 9, 10}  # ரிஷபம், மிதுனம், கன்னி, விருச்சிகம், மகரம், கும்பம்


def d7_fifth_lord_degree_zone_check(vargas, grahas, planet_ta_map):
    """Checks whether D7's 5th-house lord's exact degree (within its own
    D1 rasi/longitude) falls in a specific narrow zone:
    - Odd (male) rasi: 20°00'00" to 20°00'30"
    - Even (female) rasi: 09°30'00" to 10°00'00"
    Facts only (yes/no) - degree-zone placement check."""
    if "D7" not in vargas:
        return None
    d7_lagna_idx = vargas["D7"]["lagna_rasi_index"]
    fifth_rasi = (d7_lagna_idx + 4) % 12
    lord_en = RASI_LORD.get(fifth_rasi)
    if not lord_en or lord_en not in grahas:
        return None
    lord_rasi = grahas[lord_en]["rasi_index"]
    deg_in_sign = grahas[lord_en]["longitude"] % 30
    is_odd_rasi = (lord_rasi % 2 == 0)  # rasi index 0,2,4.. = Mesha,Mithuna,Simha.. (odd-numbered signs)

    if is_odd_rasi:
        in_zone = 20.0 <= deg_in_sign <= 20 + (30/3600)  # 20°00'00" to 20°00'30"
        zone_label = "ஆண் ராசி வலயம் (20°00'00\" - 20°00'30\")"
    else:
        in_zone = (9 + 30/60) <= deg_in_sign <= 10.0  # 09°30'00" to 10°00'00"
        zone_label = "பெண் ராசி வலயம் (09°30'00\" - 10°00'00\")"

    deg = int(deg_in_sign)
    minute_f = (deg_in_sign - deg) * 60
    minute = int(minute_f)
    second = round((minute_f - minute) * 60)

    return {
        "lord_ta": planet_ta_map.get(lord_en, lord_en),
        "rasi_ta": RASI_TA[lord_rasi],
        "degree_str": f"{deg}°{minute:02d}'{second:02d}\"",
        "is_odd_rasi": is_odd_rasi,
        "zone_label": zone_label,
        "in_zone": in_zone,
    }


def d7_house_lord_dignity(vargas, planet_ta_map):
    """D7 facts:
    1. Male/Female rasi classification (given table) for D7 Lagna.
    2. For every house (1-12), whether that house's lord is exalted or
       debilitated IN D7.
    3. Lagna-lord's own exaltation/debilitation status specifically."""
    if "D7" not in vargas:
        return None
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]

    lagna_gender = "ஆண் ராசி" if d7_lagna_idx in D27_MALE_RASI else "பெண் ராசி"

    house_lord_dignity = []
    for house_num in range(1, 13):
        h_rasi = (d7_lagna_idx + house_num - 1) % 12
        lord_en = RASI_LORD.get(h_rasi)
        lord_ta = planet_ta_map.get(lord_en) if lord_en else None
        lord_rasi = d7["grahas"].get(lord_ta, {}).get("rasi_index") if lord_ta else None
        if lord_rasi is None:
            continue
        is_exalted = EXALT_RASI_TABLE.get(lord_en) == lord_rasi
        is_debilitated = DEBIL_RASI_TABLE.get(lord_en) == lord_rasi
        if is_exalted or is_debilitated:
            house_lord_dignity.append({
                "house": house_num, "lord_ta": lord_ta,
                "status": "உச்சம்" if is_exalted else "நீசம்",
            })

    lagna_lord_en = RASI_LORD.get(d7_lagna_idx)
    lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
    lagna_lord_rasi = d7["grahas"].get(lagna_lord_ta, {}).get("rasi_index") if lagna_lord_ta else None
    lagna_lord_exalted = EXALT_RASI_TABLE.get(lagna_lord_en) == lagna_lord_rasi
    lagna_lord_debilitated = DEBIL_RASI_TABLE.get(lagna_lord_en) == lagna_lord_rasi

    return {
        "lagna_rasi_ta": RASI_TA[d7_lagna_idx],
        "lagna_gender": lagna_gender,
        "house_lord_dignity": house_lord_dignity,
        "lagna_lord_ta": lagna_lord_ta,
        "lagna_lord_exalted": lagna_lord_exalted,
        "lagna_lord_debilitated": lagna_lord_debilitated,
    }


def d7_manthi_position(vargas, planet_ta_map):
    """D7 (Saptamsa) - Guligan's (Manthi's) house position relative
    to D7's own Lagna. Placement fact only (which house it's in), no
    interpretation attached."""
    if "D7" not in vargas:
        return None
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]
    guligan_ta = planet_ta_map.get("Guligan", "குளிகன்")
    guligan_rasi = d7["grahas"].get(guligan_ta, {}).get("rasi_index")
    if guligan_rasi is None:
        return None
    house = (guligan_rasi - d7_lagna_idx) % 12 + 1

    # Connection check (conjunction or classical aspect) between Manthi
    # and Lagna / Lagna-lord / Jupiter - facts only, yes/no.
    lagna_lord_en = RASI_LORD.get(d7_lagna_idx)
    lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
    lagna_lord_rasi = d7["grahas"].get(lagna_lord_ta, {}).get("rasi_index") if lagna_lord_ta else None
    jupiter_ta = planet_ta_map.get("Jupiter")
    jupiter_rasi = d7["grahas"].get(jupiter_ta, {}).get("rasi_index") if jupiter_ta else None

    guligan_aspects = graha_drishti("Saturn", guligan_rasi)  # Manthi's aspect classically follows Saturn's pattern

    def connected(target_rasi):
        if target_rasi is None:
            return False
        return target_rasi == guligan_rasi or target_rasi in guligan_aspects

    connects_lagna = connected(d7_lagna_idx)
    connects_lagna_lord = connected(lagna_lord_rasi)
    connects_jupiter = connected(jupiter_rasi)

    return {
        "house": house,
        "rasi_ta": RASI_TA[guligan_rasi],
        "in_5_7_9": house in (5, 7, 9),
        "connects_lagna": connects_lagna,
        "connects_lagna_lord": connects_lagna_lord,
        "connects_jupiter": connects_jupiter,
        "any_connection": connects_lagna or connects_lagna_lord or connects_jupiter,
    }


def verify_child_chart_match(parent_chart, child_chart):
    """Checks whether a child's chart 'matches' the parent's D7 Lagna,
    per the classical rule: the child's D1 Lagna, D7 Lagna, or D1 Moon
    should fall in the 5th house from the PARENT's D7 Lagna. Facts only
    (yes/no per point checked) - not a verdict on the chart's validity."""
    parent_d7_lagna_idx = parent_chart["vargas"]["D7"]["lagna_rasi_index"]
    target_rasi = (parent_d7_lagna_idx + 4) % 12  # 5th from parent's D7 lagna

    child_d1_lagna_idx = child_chart["vargas"]["D1"]["lagna_rasi_index"]
    child_d7_lagna_idx = child_chart["vargas"]["D7"]["lagna_rasi_index"]
    child_moon_rasi_idx = child_chart["grahas"]["Moon"]["rasi_index"]

    match_d1_lagna = (child_d1_lagna_idx == target_rasi)
    match_d7_lagna = (child_d7_lagna_idx == target_rasi)
    match_moon = (child_moon_rasi_idx == target_rasi)
    any_match = match_d1_lagna or match_d7_lagna or match_moon

    return {
        "parent_d7_lagna_rasi": RASI_TA[parent_d7_lagna_idx],
        "target_rasi": RASI_TA[target_rasi],
        "child_d1_lagna_rasi": RASI_TA[child_d1_lagna_idx],
        "child_d7_lagna_rasi": RASI_TA[child_d7_lagna_idx],
        "child_moon_rasi": RASI_TA[child_moon_rasi_idx],
        "match_d1_lagna": match_d1_lagna,
        "match_d7_lagna": match_d7_lagna,
        "match_moon": match_moon,
        "any_match": any_match,
    }


def d7_bhaga_lagna(vargas, gender, planet_ta_map):
    """Bhaga Lagna: D7's own 5th house lord's D7-rasi position - the
    child is said to carry that rasi's qualities. Child-order (1st/2nd/
    3rd) label follows the gender-specific house sequence you gave:
    male = 5,7,9; female = 9,7,5."""
    if "D7" not in vargas:
        return None
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]
    fifth_rasi = (d7_lagna_idx + 4) % 12
    fifth_lord_en = RASI_LORD.get(fifth_rasi)
    fifth_lord_ta = planet_ta_map.get(fifth_lord_en) if fifth_lord_en else None
    bhaga_lagna_rasi = d7["grahas"].get(fifth_lord_ta, {}).get("rasi_index") if fifth_lord_ta else None
    if bhaga_lagna_rasi is None:
        return None
    order = [5, 7, 9] if gender == "male" else ([9, 7, 5] if gender == "female" else None)
    return {
        "fifth_lord_ta": fifth_lord_ta,
        "bhaga_lagna_rasi_ta": RASI_TA[bhaga_lagna_rasi],
        "child_order_houses": order,
    }


def d7_lord_connection_timing(vargas, grahas, full_dasa_tree, planet_ta_map):
    """Refined 'when will child be born' analysis:
    1. Static connection check (conjunction/aspect in D7) between the
       8th-lord and 12th-lord, and separately whether the 2nd-lord also
       connects with them.
    2. Timing: Mahadasa-Antardasa (and Antardasa-Pratyantardasa)
       combinations where the 8th-lord and 12th-lord BOTH appear
       (either order) = '8-12 தொடர்பு' period. Where the 2nd-lord ALSO
       appears alongside them (across Maha-Antar-Pratyantar) = '8-12-2
       தொடர்பு' period - facts only, classical timing method."""
    if "D7" not in vargas:
        return None
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]

    def lord_of_house(house_num):
        h_rasi = (d7_lagna_idx + house_num - 1) % 12
        return RASI_LORD.get(h_rasi)

    lord2_en, lord8_en, lord12_en = lord_of_house(2), lord_of_house(8), lord_of_house(12)

    def d7_rasi_of_en(p_en):
        p_ta = planet_ta_map.get(p_en)
        return d7["grahas"].get(p_ta, {}).get("rasi_index") if p_ta else None

    r8, r12, r2 = d7_rasi_of_en(lord8_en), d7_rasi_of_en(lord12_en), d7_rasi_of_en(lord2_en)

    def connected(r1, p1_en, r2_):
        if r1 is None or r2_ is None:
            return False
        return r1 == r2_ or r2_ in graha_drishti(p1_en, r1)

    connection_8_12 = connected(r8, lord8_en, r12) or connected(r12, lord12_en, r8)
    connection_2_with_8_12 = (
        connected(r2, lord2_en, r8) or connected(r8, lord8_en, r2) or
        connected(r2, lord2_en, r12) or connected(r12, lord12_en, r2)
    )

    # Timing: find Maha-Antar pairs covering {lord8, lord12}, and
    # Maha-Antar-Pratyantar triples covering {lord8, lord12, lord2}.
    periods_8_12 = []
    periods_8_12_2 = []
    target_pair = {lord8_en, lord12_en}
    target_triple = {lord8_en, lord12_en, lord2_en}
    for maha in full_dasa_tree:
        for antar in maha["antardasa"]:
            level_pair = {maha["lord_en"], antar["lord_en"]}
            if target_pair <= level_pair:
                periods_8_12.append({
                    "level": f"{maha['lord']} தசை → {antar['lord']} புக்தி",
                    "start": antar["start"], "end": antar["end"]
                })
            for praty in antar["pratyantardasa"]:
                level_triple = {maha["lord_en"], antar["lord_en"], praty["lord_en"]}
                if target_triple <= level_triple:
                    periods_8_12_2.append({
                        "level": f"{maha['lord']} தசை → {antar['lord']} புக்தி → {praty['lord']} அந்தரம்",
                        "start": praty["start"], "end": praty["end"]
                    })

    return {
        "lord2_ta": planet_ta_map.get(lord2_en), "lord8_ta": planet_ta_map.get(lord8_en),
        "lord12_ta": planet_ta_map.get(lord12_en),
        "connection_8_12": connection_8_12,
        "connection_2_with_8_12": connection_2_with_8_12,
        "periods_8_12": periods_8_12,
        "periods_8_12_2": periods_8_12_2,
    }


def d7_birth_and_conception_timing(vargas, full_dasa_tree, planet_ta_map):
    """Mahadasa/Antardasa periods whose lord either (a) occupies D7's
    2nd, 8th, or 12th house, or (b) is the LORD of D7's 8th or 12th
    house. Same computed period list is classically referenced both as
    'birth timing' (எப்போது குழந்தை பிறக்கும்) and 'Garbhadhana Kaal /
    இனசேர்கை' (conception timing) - facts only, dates are the same
    underlying data under two classical labels."""
    if "D7" not in vargas:
        return []
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]

    relevant_planets = set()
    for house_num in (2, 8, 12):
        h_rasi = (d7_lagna_idx + house_num - 1) % 12
        for p_ta, g in d7["grahas"].items():
            if g["rasi_index"] == h_rasi:
                p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
                if p_en:
                    relevant_planets.add(p_en)
    for house_num in (8, 12):
        h_rasi = (d7_lagna_idx + house_num - 1) % 12
        lord_en = RASI_LORD.get(h_rasi)
        if lord_en:
            relevant_planets.add(lord_en)

    results = []
    for maha in full_dasa_tree:
        if maha["lord_en"] in relevant_planets:
            results.append({"level": "மகா தசை", "lord": maha["lord"],
                             "start": maha["start"], "end": maha["end"]})
        for antar in maha["antardasa"]:
            if antar["lord_en"] in relevant_planets:
                results.append({"level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                                 "start": antar["start"], "end": antar["end"]})
    return results


def d7_children_count_and_rules(vargas, grahas, gender, lagna_lon, planet_ta_map):
    """Additional D7 facts (both genders):
    1. 5-7-9 override: even if Lagna/Lagna-lord are afflicted, if 5th,
       7th, 9th houses are all unafflicted, a child is still indicated
       (classically noted as coming with later difficulty).
    2. Children-count estimate: count of planets connected (conjunction
       or classical aspect) to D7 Lagna or Lagna-lord, MINUS those that
       are natural enemies of the Lagna-lord, debilitated in D7, or
       natural malefics. This is a classical estimation method, not a
       certain count.
    3. Male-chart-only: if D1 Lagna falls in the 1st Saptamsa division
       (Hara/Panchakavyam, 0-4.28° of its sign), classically 'no benefit'
       is indicated - UNLESS the D1 Lagna sign itself is Kumbam
       (Aquarius), an exception. Also notes parent-child relationship
       strain in this case."""
    if "D7" not in vargas or "D1" not in vargas:
        return None
    d7 = vargas["D7"]
    d1 = vargas["D1"]
    d7_lagna_idx = d7["lagna_rasi_index"]
    d1_lagna_idx = d1["lagna_rasi_index"]

    def is_afflicted_house(house_num):
        rasi = (d7_lagna_idx + house_num - 1) % 12
        lord_en = RASI_LORD.get(rasi)
        lord_ta = planet_ta_map.get(lord_en) if lord_en else None
        lord_rasi = d7["grahas"].get(lord_ta, {}).get("rasi_index") if lord_ta else None
        if lord_rasi is None:
            return False
        lord_house = (lord_rasi - d7_lagna_idx) % 12 + 1
        return (DEBIL_RASI_TABLE.get(lord_en) == lord_rasi) or (lord_house in (6, 8, 12))

    lagna_afflicted = is_afflicted_house(1)
    override_579 = None
    if lagna_afflicted:
        all_579_ok = not is_afflicted_house(5) and not is_afflicted_house(7) and not is_afflicted_house(9)
        if all_579_ok:
            override_579 = "லக்னம்/லக்னாதிபதி பாதிக்கப்பட்டிருந்தாலும், 5,7,9 வீடுகள் நன்றாக இருப்பதால் குழந்தை பிறக்கும் — ஆனால் பின்நாளில் தொல்லை கொடுக்கலாம் (classical rule)."

    # Karako Bhava Nasti: D7's Karaka (Jupiter) sitting in D7's own Lagna
    jupiter_ta = planet_ta_map.get("Jupiter")
    jupiter_d7_rasi = d7["grahas"].get(jupiter_ta, {}).get("rasi_index") if jupiter_ta else None
    karako_bhava_nasti_d7 = (jupiter_d7_rasi == d7_lagna_idx)

    # Classical yoga check (facts only): Saturn+Mercury+Venus mutual
    # trine (1-5-9) placement, OR conjunct in the same D7 rasi.
    sat_ta, merc_ta, ven_ta = planet_ta_map.get("Saturn"), planet_ta_map.get("Mercury"), planet_ta_map.get("Venus")
    sat_r = d7["grahas"].get(sat_ta, {}).get("rasi_index") if sat_ta else None
    merc_r = d7["grahas"].get(merc_ta, {}).get("rasi_index") if merc_ta else None
    ven_r = d7["grahas"].get(ven_ta, {}).get("rasi_index") if ven_ta else None
    trikona_offsets = {0, 4, 8}  # 1st, 5th, 9th from each other (same trikona set)

    def same_trikona(r1, r2):
        return r1 is not None and r2 is not None and ((r1 - r2) % 4 == 0)

    trine_pattern = (
        same_trikona(sat_r, merc_r) and same_trikona(merc_r, ven_r) and same_trikona(sat_r, ven_r)
    ) if None not in (sat_r, merc_r, ven_r) else False
    conjunct_pattern = (sat_r == merc_r == ven_r) if None not in (sat_r, merc_r, ven_r) else False
    sat_merc_venus_yoga = trine_pattern or conjunct_pattern

    # Children count estimate
    lagna_lord_en = RASI_LORD.get(d7_lagna_idx)
    lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
    lagna_lord_d7_rasi = d7["grahas"].get(lagna_lord_ta, {}).get("rasi_index") if lagna_lord_ta else None
    connected_planets = set()
    for p_en in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
        p_ta = planet_ta_map.get(p_en)
        p_rasi = d7["grahas"].get(p_ta, {}).get("rasi_index") if p_ta else None
        if p_rasi is None:
            continue
        if p_rasi == d7_lagna_idx or p_rasi == lagna_lord_d7_rasi:
            connected_planets.add(p_en)
        elif p_en not in ("Rahu", "Ketu") and (
            d7_lagna_idx in graha_drishti(p_en, p_rasi) or
            (lagna_lord_d7_rasi is not None and lagna_lord_d7_rasi in graha_drishti(p_en, p_rasi))
        ):
            connected_planets.add(p_en)

    excluded = []
    counted = []
    lagna_lord_enemies = NATURAL_ENEMIES.get(lagna_lord_en, set())
    for p_en in connected_planets:
        p_ta = planet_ta_map.get(p_en)
        p_rasi = d7["grahas"].get(p_ta, {}).get("rasi_index")
        is_debilitated = DEBIL_RASI_TABLE.get(p_en) == p_rasi
        is_malefic = p_en in {"Saturn", "Rahu", "Ketu", "Mars", "Sun"}
        is_enemy = p_en in lagna_lord_enemies
        if is_debilitated or is_malefic or is_enemy:
            excluded.append(planet_ta_map[p_en])
        else:
            counted.append(planet_ta_map[p_en])

    # Male-chart first-saptamsa "no benefit" rule
    male_first_saptamsa_note = None
    if gender == "male" and lagna_lon is not None:
        division = d7_rasa_of(lagna_lon)  # returns name; need index instead
        deg_in_sign = lagna_lon % 30
        division_idx = min(int(deg_in_sign // (30 / 7)), 6)
        if division_idx == 0:
            if d1_lagna_idx == 10:  # Kumbam (Aquarius)
                male_first_saptamsa_note = "லக்னம் முதல் சப்தாம்சத்தில் (பஞ்ச கவ்யம்) உள்ளது, ஆனால் D1 லக்னமே கும்பமாக இருப்பதால் இது விதிவிலக்கு — பயன் உறுதி."
            else:
                male_first_saptamsa_note = "லக்னம் முதல் சப்தாம்சத்தில் (பஞ்ச கவ்யம்) உள்ளதால் — உறுதியாக பயன் இல்லை (classical rule). குழந்தை வரலாம், ஆனால் பெற்றோர்-பிள்ளை உறவு நன்றாக இருக்காது."

    return {
        "override_579": override_579,
        "karako_bhava_nasti_d7": karako_bhava_nasti_d7,
        "sat_merc_venus_yoga": sat_merc_venus_yoga,
        "children_count_estimate": len(counted),
        "children_count_planets": counted,
        "children_count_excluded": excluded,
        "male_first_saptamsa_note": male_first_saptamsa_note,
    }


def d7_female_facts(vargas, grahas, gender, planet_ta_map, panchanga_data=None):
    """Female-chart-specific D7 facts (only computed when gender='female'):
    1. 5th house (womb signification) occupants + lord affliction status.
    2. Moon's own dignity/affliction status in D7 (classically checked
       for female charts).
    3. D7 Lagna affliction status -> desire-for-children fact.
    4. D7 Lagna-lord affliction status -> ability-to-fulfil-desire fact.
    Facts only - no claims about actual fertility/health outcomes."""
    if gender != "female" or "D7" not in vargas:
        return None
    d7 = vargas["D7"]
    d7_lagna_idx = d7["lagna_rasi_index"]

    def rasi_of(p_ta):
        return d7["grahas"].get(p_ta, {}).get("rasi_index")

    def house_of(rasi_idx):
        return (rasi_idx - d7_lagna_idx) % 12 + 1 if rasi_idx is not None else None

    # 1. 5th house facts
    fifth_rasi = (d7_lagna_idx + 4) % 12
    fifth_lord_en = RASI_LORD.get(fifth_rasi)
    fifth_lord_ta = planet_ta_map.get(fifth_lord_en) if fifth_lord_en else None
    fifth_occupants = [p_ta for p_ta, g in d7["grahas"].items() if g["rasi_index"] == fifth_rasi]
    fifth_lord_house = house_of(rasi_of(fifth_lord_ta)) if fifth_lord_ta else None
    fifth_lord_afflicted = (
        DEBIL_RASI_TABLE.get(fifth_lord_en) == rasi_of(fifth_lord_ta) if fifth_lord_ta else False
    ) or (fifth_lord_house in (6, 8, 12) if fifth_lord_house else False)

    # 1b. If 5th house is good (unafflicted), also check the 9th house
    # (per your rule: "5 நன்றாக இருந்தால் 9 போகணும்")
    ninth_house_check = None
    if not fifth_lord_afflicted:
        ninth_rasi = (d7_lagna_idx + 8) % 12
        ninth_lord_en = RASI_LORD.get(ninth_rasi)
        ninth_lord_ta = planet_ta_map.get(ninth_lord_en) if ninth_lord_en else None
        ninth_occupants = [p_ta for p_ta, g in d7["grahas"].items() if g["rasi_index"] == ninth_rasi]
        ninth_lord_house = house_of(rasi_of(ninth_lord_ta)) if ninth_lord_ta else None
        ninth_lord_afflicted = (
            DEBIL_RASI_TABLE.get(ninth_lord_en) == rasi_of(ninth_lord_ta) if ninth_lord_ta else False
        ) or (ninth_lord_house in (6, 8, 12) if ninth_lord_house else False)
        ninth_house_check = {
            "ninth_house_rasi_ta": RASI_TA[ninth_rasi],
            "ninth_lord_ta": ninth_lord_ta,
            "ninth_occupants_ta": ninth_occupants,
            "ninth_lord_afflicted": ninth_lord_afflicted,
        }

    # 2. Moon's status in D7
    moon_rasi_d7 = rasi_of("சந்திரன்")
    moon_house_d7 = house_of(moon_rasi_d7)
    moon_debilitated = (DEBIL_RASI_TABLE.get("Moon") == moon_rasi_d7)
    moon_exalted_or_own = (
        EXALT_RASI_TABLE.get("Moon") == moon_rasi_d7 or
        moon_rasi_d7 in RASI_LORD_REV_MAIN.get("Moon", [])
    )
    moon_afflicted = moon_debilitated or (moon_house_d7 in (6, 8, 12) if moon_house_d7 else False)
    moon_paksha = panchanga_data.get("tithi", {}).get("paksha") if panchanga_data else None

    # 3. D7 Lagna affliction (desire)
    lagna_lord_en = RASI_LORD.get(d7_lagna_idx)
    lagna_afflicted = False
    lagna_occupants = [p_ta for p_ta, g in d7["grahas"].items() if g["rasi_index"] == d7_lagna_idx]
    for p_ta in lagna_occupants:
        p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
        if p_en in {"Saturn", "Rahu", "Ketu", "Mars", "Sun"}:
            lagna_afflicted = True

    # 4. D7 Lagna-lord affliction (ability to fulfil desire)
    lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
    lagna_lord_rasi = rasi_of(lagna_lord_ta) if lagna_lord_ta else None
    lagna_lord_house = house_of(lagna_lord_rasi)
    lagna_lord_afflicted = (
        (DEBIL_RASI_TABLE.get(lagna_lord_en) == lagna_lord_rasi) or
        (lagna_lord_house in (6, 8, 12) if lagna_lord_house else False)
    )

    if not lagna_afflicted and not lagna_lord_afflicted:
        desire_summary = "D7 லக்னம் நல்ல நிலையில், லக்னாதிபதியும் நல்ல நிலையில் — குழந்தை பெற விருப்பமும் அதை நிறைவேற்றும் வழியும் இருக்கும்."
    elif lagna_afflicted:
        desire_summary = "D7 லக்னம் பாதிக்கப்பட்டுள்ளதால் — குழந்தை பெறுவதற்கான விருப்பமே குறைவாக இருக்கலாம்."
    else:
        desire_summary = "D7 லக்னம் நல்ல நிலையில் இருந்தும் லக்னாதிபதி பாதிக்கப்பட்டுள்ளதால் — விருப்பம் இருந்தாலும் அதை நிறைவேற்ற வழி இருக்காமல் போகலாம்."

    return {
        "fifth_house_rasi_ta": RASI_TA[fifth_rasi],
        "fifth_lord_ta": fifth_lord_ta,
        "fifth_occupants_ta": fifth_occupants,
        "fifth_lord_afflicted": fifth_lord_afflicted,
        "ninth_house_check": ninth_house_check,
        "moon_rasi_ta": RASI_TA[moon_rasi_d7] if moon_rasi_d7 is not None else None,
        "moon_afflicted": moon_afflicted,
        "moon_paksha": moon_paksha,
        "moon_exalted_or_own": moon_exalted_or_own,
        "lagna_afflicted": lagna_afflicted,
        "lagna_lord_ta": lagna_lord_ta,
        "lagna_lord_afflicted": lagna_lord_afflicted,
        "desire_summary": desire_summary,
    }


def d7_house_lord_rasa(vargas, grahas, planet_ta_map, lagna_lon=None):
    """For D7's own 1,3,5,7,9,11 house lords (using D7's own Lagna as
    house 1 reference), returns which Sapta-Rasa each lord's D1
    longitude falls into - facts only. Also includes the Lagna's own
    rasa (using the D1 lagna's own degree)."""
    if "D7" not in vargas:
        return {"lagna_rasa": None, "house_lords": []}
    d7_lagna_idx = vargas["D7"]["lagna_rasi_index"]

    lagna_rasa = None
    if lagna_lon is not None:
        rasa = d7_rasa_of(lagna_lon)
        lagna_rasa = {"rasa": rasa, "note": D7_RASA_NOTES.get(rasa)}

    results = []
    for house_num in [1, 3, 5, 7, 9, 11]:
        h_rasi = (d7_lagna_idx + house_num - 1) % 12
        lord_en = RASI_LORD.get(h_rasi)
        if not lord_en or lord_en not in grahas:
            continue
        rasa = d7_rasa_of(grahas[lord_en]["longitude"])
        lord_ta = planet_ta_map[lord_en]
        lord_d7_rasi = vargas["D7"]["grahas"].get(lord_ta, {}).get("rasi_index")
        is_exalted = EXALT_RASI_TABLE.get(lord_en) == lord_d7_rasi
        is_debilitated = DEBIL_RASI_TABLE.get(lord_en) == lord_d7_rasi
        results.append({
            "house": house_num,
            "lord_ta": lord_ta,
            "rasa": rasa,
            "note": D7_RASA_NOTES.get(rasa),
            "dignity": "உச்சம்" if is_exalted else ("நீசம்" if is_debilitated else "நடுநிலை"),
            "is_lagna_lord": (house_num == 1),
        })
    return {"lagna_rasa": lagna_rasa, "house_lords": results}


def d7_rasa_and_children_report(grahas, gender):
    """1. Sapta-Rasa (7-taste) division for each classical planet, based
    on their D1 longitude (facts only).
    2. Children-signification house mapping for D7, which houses differ
    by gender per the classical rule you gave."""
    rasa_facts = []
    for p_en in ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]:
        if p_en not in grahas:
            continue
        rasa = d7_rasa_of(grahas[p_en]["longitude"])
        rasa_facts.append({
            "planet_ta": grahas[p_en]["name_ta"],
            "rasa": rasa,
            "note": D7_RASA_NOTES.get(rasa),
        })

    children_houses = None
    if gender in ("male", "female"):
        children_houses = CHILDREN_HOUSE_BY_GENDER[gender]

    return {"rasa_facts": rasa_facts, "children_houses": children_houses, "gender": gender}


def d24_deity_of(longitude):
    """Returns the D24 deity name for a given absolute sidereal longitude,
    using the classical 24-port table (1.25° divisions, odd/even sign)."""
    rasi = int(longitude // 30)
    deg_in_sign = longitude % 30
    division = int(deg_in_sign // 1.25)  # 0-23
    pair_idx = division % 12
    is_odd_sign = (rasi % 2 == 0)  # rasi idx 0,2,4.. = odd-numbered signs (Aries=1st)
    odd_deity, even_deity = D24_DEITY_TABLE[pair_idx]
    return odd_deity if is_odd_sign else even_deity


def full_life_dasa_deities(full_dasa_tree, grahas, planet_ta_map):
    """For EVERY Mahadasa->Antardasa period across the full life (from
    birth), computes which D24 deity/port that period's lord occupies
    (via their D1 longitude) and the deity's associated field/palan."""
    results = []
    for maha in full_dasa_tree:
        if maha["lord_en"] in grahas:
            deity = d24_deity_of(grahas[maha["lord_en"]]["longitude"])
            results.append({
                "level": "மகா தசை", "lord": maha["lord"],
                "start": maha["start"], "end": maha["end"],
                "deity": deity, "palan": DEITY_SIGNIFICANCE.get(deity)
            })
        for antar in maha["antardasa"]:
            if antar["lord_en"] in grahas:
                deity = d24_deity_of(grahas[antar["lord_en"]]["longitude"])
                results.append({
                    "level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                    "start": antar["start"], "end": antar["end"],
                    "deity": deity, "palan": DEITY_SIGNIFICANCE.get(deity)
                })
    return results


def dasa_chain_deities(grahas, dasa_data, planet_ta_map):
    """For the current running Maha/Antar/Pratyantar/Sookshma/Prana dasa
    lords, returns which D24 deity/port each lord's D1 longitude falls
    into - facts only, per your table."""
    levels = [
        ("மகா தசை", dasa_data.get("current_maha_lord_en")),
        ("அந்தர தசை", dasa_data.get("current_antar_lord_en")),
        ("பிரத்யந்தர தசை", dasa_data.get("current_pratyantar_lord_en")),
        ("சூட்சும தசை", dasa_data.get("current_sookshma_lord_en")),
        ("பிராண தசை", dasa_data.get("current_prana_lord_en")),
    ]
    results = []
    for level_label, lord_en in levels:
        if not lord_en or lord_en not in grahas:
            continue
        deity = d24_deity_of(grahas[lord_en]["longitude"])
        results.append({
            "level": level_label,
            "lord_ta": planet_ta_map.get(lord_en, lord_en),
            "deity": deity,
        })
    return results


def moon_rasi_name_letters(grahas):
    """Returns the classical Rasi-based name-starting-letters for the
    person's Janma Rasi (Moon's rasi). Facts-only reference, flagged
    for verification since source data came from a screenshot."""
    moon_rasi = grahas.get("Moon", {}).get("rasi_index")
    if moon_rasi is None:
        return None
    return {
        "rasi_ta": RASI_TA[moon_rasi],
        "letters": RASI_NAME_LETTERS.get(moon_rasi),
    }


def varga_knowledge_and_competition(vargas, planet_ta_map, panchanga_data):
    """Two cross-varga checks (applied to EVERY D-chart, not just D24):
    1. If Moon occupies the 6th house of a varga, that varga's subject-
       knowledge comes easily, with competitive skill and competition wins.
    2. Competitive-skill facts based on WHO occupies the 6th house:
       Jupiter/Mercury/Venus/waxing-Moon in 6th -> no competitive skill;
       natural malefic (Sun/Mars/Saturn) in 6th -> wins competition."""
    is_waxing_moon = panchanga_data.get("tithi", {}).get("paksha") == "சுக்ல பக்ஷம்"
    NO_COMPETITIVE_SKILL_PLANETS = {"Jupiter", "Mercury", "Venus"}
    WINS_COMPETITION_PLANETS = {"Sun", "Mars", "Saturn"}

    results = []
    for varga_code, vdata in vargas.items():
        lagna_idx = vdata["lagna_rasi_index"]
        sixth_rasi = (lagna_idx + 5) % 12
        occupants_ta = [p_ta for p_ta, g in vdata["grahas"].items() if g["rasi_index"] == sixth_rasi]
        if not occupants_ta:
            continue
        occupants_en = []
        for p_ta in occupants_ta:
            p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
            if p_en:
                occupants_en.append(p_en)

        moon_in_6th = "Moon" in occupants_en
        no_competitive_skill = any(
            p == "Moon" and is_waxing_moon or p in NO_COMPETITIVE_SKILL_PLANETS
            for p in occupants_en
        )
        wins_competition = any(p in WINS_COMPETITION_PLANETS for p in occupants_en)

        if moon_in_6th or no_competitive_skill or wins_competition:
            results.append({
                "varga": varga_code, "varga_name_ta": VARGA_NAMES_TA.get(varga_code, varga_code),
                "sixth_occupants_ta": occupants_ta,
                "easy_knowledge": moon_in_6th,
                "no_competitive_skill": no_competitive_skill,
                "wins_competition": wins_competition,
            })
    return results


def d24_teacher_school_facts(vargas, planet_ta_map):
    """Three D24 facts:
    1. Chandra+Sani+Sevvai combination (same D24 rasi as Moon) -> economics
       education not suited; notes Mars can still work via 5th/9th yoga.
    2. Favourite-teacher subject: for Lagna, 4th house, and each of
       Sun/Mercury/Moon/Jupiter-or-Ketu/Rahu, the 9th house/sign FROM that
       point indicates the subject of the liked teacher.
    3. Preferred school type, from whichever of the classical school-karaka
       planets (Sun/Venus/Jupiter/Rahu/Ketu/Mars) is strongest in D24."""
    if "D24" not in vargas:
        return {}
    d24 = vargas["D24"]
    d24_lagna_idx = d24["lagna_rasi_index"]

    def rasi_of(p_ta):
        return d24["grahas"].get(p_ta, {}).get("rasi_index")

    moon_rasi = rasi_of("சந்திரன்")
    saturn_rasi = rasi_of("சனி")
    mars_rasi = rasi_of("செவ்வாய்")
    moon_sani_sevvai_combo = (moon_rasi is not None and moon_rasi == saturn_rasi == mars_rasi)

    # 2. Favourite teacher subject (9th from various reference points)
    TEACHER_SUBJECT_BY_SOURCE = {
        "Lagna": "எப்போதும் பிடிக்கும் ஆசிரியர்",
        "4th": "1 முதல் 10-ம் வகுப்பு வரை பிடிக்கும் ஆசிரியர்",
        "Sun": "ஆங்கில ஆசிரியர்",
        "Mercury": "ஜோதிடம்/கணிதம் ஆசிரியர்",
        "Moon": "தமிழ்/தாய்மொழி ஆசிரியர்",
        "Jupiter_or_Ketu": "இந்தி/உருது ஆசிரியர்",
        "Rahu": "அரபி/உருது ஆசிரியர்",
    }
    teacher_facts = []
    ref_rasis = {
        "Lagna": d24_lagna_idx,
        "4th": (d24_lagna_idx + 3) % 12,
        "Sun": rasi_of("சூரியன்"),
        "Mercury": rasi_of("புதன்"),
        "Moon": rasi_of("சந்திரன்"),
        "Jupiter_or_Ketu": rasi_of("வியாழன்"),
        "Rahu": rasi_of("ராகு"),
    }
    for source, ref_rasi in ref_rasis.items():
        if ref_rasi is None:
            continue
        ninth_rasi = (ref_rasi + 8) % 12
        occupants = [p_ta for p_ta, g in d24["grahas"].items() if g["rasi_index"] == ninth_rasi]
        teacher_facts.append({
            "source": source, "label": TEACHER_SUBJECT_BY_SOURCE[source],
            "ninth_rasi_ta": RASI_TA[ninth_rasi], "occupants_ta": occupants,
            "name_letters": RASI_NAME_LETTERS.get(ninth_rasi),
        })

    # 3. Preferred school type - strongest classical school-karaka planet
    SCHOOL_BY_PLANET = {
        "Sun": "Government School",
        "Venus": "Private School, Driving School",
        "Jupiter": "Trust School, மடம் சார்ந்த பள்ளி",
        "Rahu": "Muslim School",
        "Ketu": "Christian School",
        "Mars": "Military School, Central Government School, Sainik School",
    }
    school_planets = ["Sun", "Venus", "Jupiter", "Rahu", "Ketu", "Mars"]
    best_school_planet, best_score = None, -1
    for p_en in school_planets:
        p_ta = planet_ta_map.get(p_en)
        p_rasi = rasi_of(p_ta) if p_ta else None
        if p_rasi is None:
            continue
        if EXALT_RASI_TABLE.get(p_en) == p_rasi:
            score = 3
        elif p_rasi in RASI_LORD_REV_MAIN.get(p_en, []):
            score = 2
        elif DEBIL_RASI_TABLE.get(p_en) == p_rasi:
            score = 0
        else:
            score = 1
        if score > best_score:
            best_score, best_school_planet = score, p_en
    preferred_school = None
    sun_ta, venus_ta = planet_ta_map.get("Sun"), planet_ta_map.get("Venus")
    if best_school_planet == "Sun" and rasi_of(sun_ta) == rasi_of(venus_ta):
        preferred_school = {"planet_ta": "சூரியன்+சுக்கிரன்", "school": "AIDED School"}
    elif best_school_planet:
        preferred_school = {
            "planet_ta": planet_ta_map[best_school_planet],
            "school": SCHOOL_BY_PLANET[best_school_planet]
        }

    return {
        "moon_sani_sevvai_combo": moon_sani_sevvai_combo,
        "teacher_facts": teacher_facts,
        "preferred_school": preferred_school,
    }


def d24_special_dasa_periods(vargas, full_dasa_tree, planet_ta_map, hora_chakras=None):
    """Six D24-specific dasa-bhukti checks (each returns a list of
    {"level","lord","start","end","note"} facts):
    1. competitive_exam: 3rd/6th house connection + strength (green=strong/win, red=weak)
    2. award_scholarship: 11th house strength (green if strong)
    3. debt_period: dasa lord connects with 6th house (from any of 1,2,3,4,5,7,9,10,12)
    4. first_rank: 6th house strongest AND 4th/11th also good
    5. hostel_period: dasa lord connects with 2nd/12th house
    6. prestigious_study: D24 Lagna/Lagna-lord's D2(Hora) placement -
       Sun Hora -> MBBS/Vedic Astrology; Moon Hora -> Numerology/Gemology
    """
    if "D24" not in vargas:
        return {}
    d24 = vargas["D24"]
    d24_lagna_idx = d24["lagna_rasi_index"]

    def house_rasi(h):
        return (d24_lagna_idx + h - 1) % 12

    def lord_of(h):
        return RASI_LORD.get(house_rasi(h))

    def strength_of(h):
        lord_en = lord_of(h)
        lord_ta = planet_ta_map.get(lord_en) if lord_en else None
        lord_rasi = d24["grahas"].get(lord_ta, {}).get("rasi_index") if lord_ta else None
        if lord_rasi is None:
            return None
        hfl = (lord_rasi - d24_lagna_idx) % 12 + 1
        if DEBIL_RASI_TABLE.get(lord_en) == lord_rasi or hfl in (6, 8, 12):
            return "weak"
        if EXALT_RASI_TABLE.get(lord_en) == lord_rasi or hfl in (1, 4, 5, 9, 10):
            return "strong"
        return "neutral"

    def occupants_and_lord_en(h):
        r = house_rasi(h)
        occ_ta = [p_ta for p_ta, g in d24["grahas"].items() if g["rasi_index"] == r]
        occ_en = {next((k for k, v in planet_ta_map.items() if v == p_ta), None) for p_ta in occ_ta}
        occ_en.discard(None)
        lord_en = lord_of(h)
        if lord_en:
            occ_en.add(lord_en)
        return occ_en

    third_sixth_planets = occupants_and_lord_en(3) | occupants_and_lord_en(6)
    third_strength, sixth_strength = strength_of(3), strength_of(6)
    eleventh_strength = strength_of(11)
    fourth_strength, eleventh_strength2 = strength_of(4), strength_of(11)

    six_contact_houses = [1, 2, 3, 4, 5, 7, 9, 10, 12]
    six_house_planets = occupants_and_lord_en(6)
    debt_related_planets = set()
    for h in six_contact_houses:
        if occupants_and_lord_en(h) & six_house_planets:
            debt_related_planets.update(occupants_and_lord_en(h))

    second_twelfth_planets = occupants_and_lord_en(2) | occupants_and_lord_en(12)

    def build_periods(planet_set, note_positive, note_negative=None, color_by_strength=None):
        results = []
        for maha in full_dasa_tree:
            if maha["lord_en"] in planet_set:
                note = note_positive
                if color_by_strength:
                    s = color_by_strength.get(maha["lord_en"])
                    note = note_positive if s != "weak" else (note_negative or note_positive)
                results.append({"level": "மகா தசை", "lord": maha["lord"],
                                 "start": maha["start"], "end": maha["end"], "note": note})
            for antar in maha["antardasa"]:
                if antar["lord_en"] in planet_set:
                    note = note_positive
                    if color_by_strength:
                        s = color_by_strength.get(antar["lord_en"])
                        note = note_positive if s != "weak" else (note_negative or note_positive)
                    results.append({"level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                                     "start": antar["start"], "end": antar["end"], "note": note})
        return results

    # 1. Competitive exam - green if 3/6 strong, red if weak
    strength_map_36 = {}
    for p_en in third_sixth_planets:
        s = third_strength if p_en == lord_of(3) else (sixth_strength if p_en == lord_of(6) else "neutral")
        strength_map_36[p_en] = s
    competitive_exam = []
    for item in build_periods(third_sixth_planets, "POSITIVE", "NEGATIVE", strength_map_36):
        item["color"] = "green" if item["note"] == "POSITIVE" else "red"
        item["note"] = "போட்டி தேர்வில் வெற்றி" if item["color"] == "green" else "போட்டி தேர்வில் பலவீனம்"
        competitive_exam.append(item)

    # 2. Award/Scholarship - 11th house strong
    award_scholarship = []
    if eleventh_strength == "strong":
        for item in build_periods(occupants_and_lord_en(11), "பலமாக உள்ளது, அவார்ட்"):
            item["color"] = "green"
            award_scholarship.append(item)

    # 3. Debt period - dasa lord connects with 6th house
    debt_period = []
    for item in build_periods(debt_related_planets, "6 தொடர்பு - கடன்"):
        item["color"] = "red" if sixth_strength != "weak" else "orange"  # strong 6th = fight/dispute per your note
        item["note"] = "6 தொடர்பு கடன்" + (" (6 பலமாக உள்ளது - சண்டை/சச்சரவு)" if sixth_strength != "weak" else "")
        debt_period.append(item)

    # 4. First rank - 6th strongest AND 4th/11th also good
    first_rank_indicated = (sixth_strength == "strong" and fourth_strength != "weak" and eleventh_strength2 != "weak")

    # 5. Hostel period
    hostel_period = build_periods(second_twelfth_planets, "ஹாஸ்டலில் தங்கி படிக்கும் காலம்")

    # 6. Prestigious study - D24 Lagna/Lagna-lord's D2 Hora placement
    prestigious_study = []
    if hora_chakras and "பராசர ஹோரா சக்கரம்" in hora_chakras:
        parasara_hora = hora_chakras["பராசர ஹோரா சக்கரம்"]
        lagna_lord_en = lord_of(1)
        lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
        lagna_hora_rasi = parasara_hora["lagna_rasi_index"]
        lord_hora_rasi = parasara_hora["grahas"].get(lagna_lord_ta, {}).get("rasi_index") if lagna_lord_ta else None
        SUN_HORA, MOON_HORA = 4, 3  # Simmam, Kadagam
        in_sun_hora = (lagna_hora_rasi == SUN_HORA) or (lord_hora_rasi == SUN_HORA)
        in_moon_hora = (lagna_hora_rasi == MOON_HORA) or (lord_hora_rasi == MOON_HORA)
        if in_sun_hora:
            prestigious_study.append("சூரிய ஹோரா: பிரபல படிப்பு (MBBS, வேத ஜோதிடம்)")
        if in_moon_hora:
            prestigious_study.append("சந்திர ஹோரா: செகண்டரி படிப்பு (நியூமராலஜி, ஜெம்மாலஜி)")

    return {
        "competitive_exam": competitive_exam,
        "award_scholarship": award_scholarship,
        "debt_period": debt_period,
        "first_rank_indicated": first_rank_indicated,
        "hostel_period": hostel_period,
        "prestigious_study": prestigious_study,
    }


def bhava_education_affliction_dasa(vargas, varga_markers_data, full_dasa_tree, planet_ta_map):
    """For each of D24's 12 houses (mapped to an education stage per your
    table), checks whether the house-lord or occupants (identified by
    their D24 house position) carry a D1-level Grahanam/Graha Yuddha/
    Combustion affliction (the real, degree-based D1 computation - not
    a D24-repositioned version), OR show 'மறைவு' (the house-lord sitting
    3rd/6th/8th/12th from the D24 Lagna). For afflicted houses, lists
    the Mahadasa/Antardasa periods of the relevant planet - facts only,
    for the astrologer to interpret against real events."""
    if "D24" not in vargas:
        return []
    d24 = vargas["D24"]
    d24_lagna_idx = d24["lagna_rasi_index"]
    d1_marks = varga_markers_data.get("D1", {}) if varga_markers_data else {}

    results = []
    for house_num, stage_label in BHAVA_EDUCATION_STAGE.items():
        house_rasi = (d24_lagna_idx + house_num - 1) % 12
        house_lord_en = RASI_LORD.get(house_rasi)
        occupants_ta = [p_ta for p_ta, g in d24["grahas"].items() if g["rasi_index"] == house_rasi]
        occupants_en = [next((k for k, v in planet_ta_map.items() if v == p_ta), None) for p_ta in occupants_ta]
        occupants_en = [p for p in occupants_en if p]

        affliction_reasons = []
        affliction_planets_en = set()

        # D1-level Grahanam/Yuddha/Combustion on this D24 house's lord/occupants
        for p_en in ([house_lord_en] if house_lord_en else []) + occupants_en:
            marks = d1_marks.get(p_en, "")
            tags = []
            if "கீ" in marks: tags.append("கிரகணம்")
            if "யு" in marks: tags.append("கிரகயுத்தம்")
            if "அஸ்" in marks: tags.append("அஸ்தங்கம்")
            if tags:
                affliction_reasons.append(f"{planet_ta_map.get(p_en, p_en)}: {', '.join(tags)} (D1)")
                affliction_planets_en.add(p_en)

        # மறைவு: house-lord sitting 3/6/8/12 from D24 Lagna
        if house_lord_en:
            lord_ta = planet_ta_map[house_lord_en]
            lord_rasi = d24["grahas"].get(lord_ta, {}).get("rasi_index")
            if lord_rasi is not None:
                lord_house_from_lagna = (lord_rasi - d24_lagna_idx) % 12 + 1
                if lord_house_from_lagna in (3, 6, 8, 12):
                    affliction_reasons.append(f"{lord_ta} (வீட்டதிபதி) {lord_house_from_lagna}-ம் வீட்டில் - மறைவு")
                    affliction_planets_en.add(house_lord_en)

        if not affliction_reasons:
            continue

        # Dasa/Bhukti periods of the afflicted planet(s)
        periods = []
        for maha in full_dasa_tree:
            if maha["lord_en"] in affliction_planets_en:
                periods.append({
                    "level": "மகா தசை", "lord": maha["lord"],
                    "start": maha["start"], "end": maha["end"]
                })
            for antar in maha["antardasa"]:
                if antar["lord_en"] in affliction_planets_en:
                    periods.append({
                        "level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                        "start": antar["start"], "end": antar["end"]
                    })

        results.append({
            "house": house_num,
            "stage": stage_label,
            "is_sports_related": house_num in SPORTS_HOUSES,
            "affliction_reasons": affliction_reasons,
            "periods": periods,
        })
    return results


def dasa_subject_interest(full_dasa_tree, planet_ta_map, panchanga_data, vargas):
    """For each Maha/Antar dasa period, lists the subject/career fields
    the running lord's karakatva (PLANET_SUBJECT_KARAKATVA) suggests -
    i.e. what subject they'd naturally gravitate to during that period.
    Also reports an overall 'always liked' subject based on the
    Atmakaraka's karakatva (the strongest personal-inclination karaka).
    Per the stated D24 8th-house rule: any planet occupying D24's 8th
    house, or being its lord, has its dasa/bhukti periods flagged as
    opportunities to study astrology/research/occult subjects."""
    ak_entry = next((k for k in panchanga_data["karakas"] if k["karaka_ta"] == "ஆத்மகாரகன்"), None)
    ak_en = ak_entry["planet_en"] if ak_entry else None
    always_liked = None
    if ak_en and ak_en in PLANET_SUBJECT_KARAKATVA:
        always_liked = {
            "planet_ta": planet_ta_map[ak_en],
            "subjects": PLANET_SUBJECT_KARAKATVA[ak_en]
        }

    # D24 8th-house connected planets (occupants + lord) - astrology/research rule
    astrology_planets_en = set()
    if "D24" in vargas:
        d24 = vargas["D24"]
        eighth_rasi = (d24["lagna_rasi_index"] + 7) % 12
        for p_ta, g in d24["grahas"].items():
            if g["rasi_index"] == eighth_rasi:
                p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
                if p_en:
                    astrology_planets_en.add(p_en)
        eighth_lord_en = RASI_LORD.get(eighth_rasi)
        if eighth_lord_en:
            astrology_planets_en.add(eighth_lord_en)

    results = []
    for maha in full_dasa_tree:
        if maha["lord_en"] in PLANET_SUBJECT_KARAKATVA:
            results.append({
                "level": "மகா தசை", "lord": maha["lord"],
                "start": maha["start"], "end": maha["end"],
                "subjects": PLANET_SUBJECT_KARAKATVA[maha["lord_en"]],
                "astrology_research_opportunity": maha["lord_en"] in astrology_planets_en,
            })
        for antar in maha["antardasa"]:
            if antar["lord_en"] in PLANET_SUBJECT_KARAKATVA:
                results.append({
                    "level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                    "start": antar["start"], "end": antar["end"],
                    "subjects": PLANET_SUBJECT_KARAKATVA[antar["lord_en"]],
                    "astrology_research_opportunity": antar["lord_en"] in astrology_planets_en,
                })
    return {"always_liked": always_liked, "periods": results}


AGE_EDUCATION_STAGE_TABLE = [
    (3, 4, "Pre-KG"), (4, 5, "LKG"), (5, 6, "UKG"),
    (6, 7, "1-ம் வகுப்பு"), (7, 8, "2-ம் வகுப்பு"), (8, 9, "3-ம் வகுப்பு"),
    (9, 10, "4-ம் வகுப்பு"), (10, 11, "5-ம் வகுப்பு"), (11, 12, "6-ம் வகுப்பு"),
    (12, 13, "7-ம் வகுப்பு"), (13, 14, "8-ம் வகுப்பு"), (14, 15, "9-ம் வகுப்பு"),
    (15, 16, "10-ம் வகுப்பு (SSLC)"), (16, 17, "11-ம் வகுப்பு (+1)"), (17, 18, "12-ம் வகுப்பு (+2)"),
    (18, 21, "UG (பட்டப்படிப்பு)"), (21, 23, "PG (முதுகலைப் படிப்பு)"),
    (23, 24, "M.Phil"), (24, 29, "Ph.D"),
]


def dasa_age_education_stage(full_dasa_tree, birth_date_str, varga_markers_data=None,
                              vargas=None, mks_list=None, planet_ta_map=None,
                              only_afflicted=False, grahas=None, vargottama_list=None):
    """For each Mahadasa/Antardasa period, computes the person's age
    range during that period (from birth_date) and matches it to the
    standard school/degree stage table (Pre-KG through Ph.D) - showing
    which class/stage overlaps that dasa-bhukti. If only_afflicted=True,
    keeps only periods whose lord shows at least one classical affliction:
    Grahanam/Graha Yuddha/Combustion (D1), 'மறைவு' (D24 lord in 3/6/8/12
    from D24 Lagna), MKS, or Karako Bhava (lord is Mercury AND Mercury
    sits in D24 Lagna). Also flags a mitigation note when the afflicted
    lord is Vargottama (D1=D9 rasi) AND has a benefic conjunction or
    classical aspect on it (per the stated 'reduces the problem' rule)."""
    if not birth_date_str:
        return []
    try:
        by, bm, bd = map(int, birth_date_str.split("-"))
        birth_dt = datetime(by, bm, bd)
    except Exception:
        return []

    def parse_dmY(s):
        d, m, y = map(int, s.split("-"))
        return datetime(y, m, d)

    def age_at(dt):
        years = dt.year - birth_dt.year - ((dt.month, dt.day) < (birth_dt.month, birth_dt.day))
        return years

    def stages_for_range(age_start, age_end):
        return [label for lo, hi, label in AGE_EDUCATION_STAGE_TABLE
                if age_start < hi and age_end > lo]

    # Pre-compute affliction lookups
    d1_marks = (varga_markers_data or {}).get("D1", {})
    mks_planets = {item["planet"] for item in (mks_list or [])}
    d24 = (vargas or {}).get("D24")
    maraivu_planets_en = set()
    karako_bhava_planet_en = None
    if d24 and planet_ta_map:
        d24_lagna_idx = d24["lagna_rasi_index"]
        for house_num in range(1, 13):
            house_rasi = (d24_lagna_idx + house_num - 1) % 12
            lord_en = RASI_LORD.get(house_rasi)
            if not lord_en:
                continue
            lord_ta = planet_ta_map.get(lord_en)
            lord_rasi = d24["grahas"].get(lord_ta, {}).get("rasi_index") if lord_ta else None
            if lord_rasi is not None:
                lord_house_from_lagna = (lord_rasi - d24_lagna_idx) % 12 + 1
                if lord_house_from_lagna in (3, 6, 8, 12):
                    maraivu_planets_en.add(lord_en)
        mercury_ta = planet_ta_map.get("Mercury")
        mercury_rasi = d24["grahas"].get(mercury_ta, {}).get("rasi_index") if mercury_ta else None
        if mercury_rasi == d24_lagna_idx:
            karako_bhava_planet_en = "Mercury"

    def affliction_tags(lord_en):
        tags = []
        marks = d1_marks.get(lord_en, "")
        if "கீ" in marks: tags.append("கிரகணம்")
        if "யு" in marks: tags.append("கிரகயுத்தம்")
        if "அஸ்" in marks: tags.append("அஸ்தங்கம்")
        if lord_en in maraivu_planets_en: tags.append("மறைவு")
        if lord_en in mks_planets: tags.append("MKS")
        if lord_en == karako_bhava_planet_en: tags.append("காரகோ பாவம்")
        return tags

    # D1=D24 same-rasi check (this feature's own "vargottamam-like" rule,
    # specific to education context - not the classical D1=D9 vargottama)
    d1_eq_d24_ta_set = set()
    if d24 and planet_ta_map:
        classical_9 = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu"]
        for p_en in classical_9:
            p_ta = planet_ta_map.get(p_en)
            d1_r = grahas.get(p_en, {}).get("rasi_index") if grahas else None
            d24_r = d24["grahas"].get(p_ta, {}).get("rasi_index") if p_ta else None
            if d1_r is not None and d1_r == d24_r:
                d1_eq_d24_ta_set.add(p_ta)
    vargottama_ta_set = d1_eq_d24_ta_set

    def mitigation_note(lord_en):
        if not grahas or not planet_ta_map or lord_en not in grahas:
            return None
        notes = []
        lord_rasi = grahas[lord_en]["rasi_index"]
        lord_ta = planet_ta_map.get(lord_en)

        # (a) Vargottama + benefic conjunction/aspect
        if lord_ta in vargottama_ta_set:
            benefic_contacts = []
            for other_en, g in grahas.items():
                if other_en == lord_en or other_en not in NATURAL_BENEFICS:
                    continue
                if g["rasi_index"] == lord_rasi or lord_rasi in graha_drishti(other_en, g["rasi_index"]):
                    benefic_contacts.append(planet_ta_map[other_en])
            if benefic_contacts:
                notes.append(f"{lord_ta} D1=D24 ஒரே ராசி + சுப கிரக தொடர்பு ({', '.join(benefic_contacts)})")

        # (b) Parivartana with a strong planet (natural benefic or exalted) -
        # only counts as a mitigation if the lord ITSELF is free of MKS,
        # மறைவு (3/6/8/12), and malefic conjunction.
        rasi_lord_en = RASI_LORD.get(lord_rasi)
        if rasi_lord_en and rasi_lord_en != lord_en:
            partner_ta = planet_ta_map.get(rasi_lord_en)
            partner_rasi = grahas.get(rasi_lord_en, {}).get("rasi_index")
            partner_own_rasis = RASI_LORD_REV_MAIN.get(lord_en, [])
            if partner_rasi is not None and partner_rasi in partner_own_rasis:
                # mutual sign-exchange confirmed
                is_strong = (rasi_lord_en in NATURAL_BENEFICS) or (EXALT_RASI_TABLE.get(rasi_lord_en) == partner_rasi)
                lord_has_mks = lord_en in mks_planets
                lord_has_maraivu = lord_en in maraivu_planets_en
                malefic_conjunct = any(
                    other_en in NATURAL_MALEFICS and other_en != lord_en and g["rasi_index"] == lord_rasi
                    for other_en, g in grahas.items()
                )
                if is_strong and not lord_has_mks and not lord_has_maraivu and not malefic_conjunct:
                    notes.append(f"பரிவர்த்தனை ({partner_ta} - நல்ல பலமானவர், MKS/மறைவு/அசுப சேர்க்கை இல்லை)")

        if notes:
            return f"{' + '.join(notes)} - இந்த காலத்தில் பிரச்சனை குறையும்."
        return None

    results = []
    for maha in full_dasa_tree:
        p_start, p_end = parse_dmY(maha["start"]), parse_dmY(maha["end"])
        age_s, age_e = age_at(p_start), age_at(p_end)
        stages = stages_for_range(age_s, age_e)
        if stages:
            tags = affliction_tags(maha["lord_en"])
            if not only_afflicted or tags:
                results.append({
                    "level": "மகா தசை", "lord": maha["lord"],
                    "start": maha["start"], "end": maha["end"],
                    "age_range": f"{age_s}-{age_e} வயது", "stages": stages,
                    "affliction_tags": tags,
                    "mitigation": mitigation_note(maha["lord_en"])
                })
        for antar in maha["antardasa"]:
            a_start, a_end = parse_dmY(antar["start"]), parse_dmY(antar["end"])
            age_s2, age_e2 = age_at(a_start), age_at(a_end)
            stages2 = stages_for_range(age_s2, age_e2)
            if stages2:
                tags2 = affliction_tags(antar["lord_en"])
                if not only_afflicted or tags2:
                    results.append({
                        "level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                        "start": antar["start"], "end": antar["end"],
                        "age_range": f"{age_s2}-{age_e2} வயது", "stages": stages2,
                        "affliction_tags": tags2,
                        "mitigation": mitigation_note(antar["lord_en"])
                    })
    return results


def _filter_periods_by_education_age(periods, birth_date_str, max_age=25):
    """Keeps only periods that overlap with age 0-max_age from birth
    (the typical formal-education age window), dropping irrelevant very-
    old or far-future periods from a full 120-year dasa list."""
    if not birth_date_str:
        return periods
    try:
        by, bm, bd = map(int, birth_date_str.split("-"))
        birth_dt = datetime(by, bm, bd)
    except Exception:
        return periods
    cutoff_dt = birth_dt.replace(year=birth_dt.year + max_age)

    def parse_dmY(s):
        d, m, y = map(int, s.split("-"))
        return datetime(y, m, d)

    filtered = []
    for p in periods:
        try:
            p_start = parse_dmY(p["start"])
            p_end = parse_dmY(p["end"])
        except Exception:
            filtered.append(p)
            continue
        if p_end >= birth_dt and p_start <= cutoff_dt:
            filtered.append(p)
    return filtered


def education_dasa_periods(full_dasa_tree, vargas, grahas, planet_ta_map, mks_list):
    """Lists Mahadasa->Antardasa periods (with date ranges) whose lord has
    a connection to D24's 4th, 5th, or 9th house (classical education
    houses) - either by occupying that house in D24, or by being that
    house's lord. Also flags, per your stated rule, whether that lord is
    (a) 'மறைவு' (hidden - 3/6/8/12 from the parent dasa lord's natal
    rasi) and (b) placed in its own MKS house - both classical affliction
    indicators. Facts only - not a claim about a specific verified event."""
    if "D24" not in vargas:
        return []
    d24 = vargas["D24"]
    d24_lagna_idx = d24["lagna_rasi_index"]
    mks_planets = {item["planet"] for item in mks_list}

    education_houses = {4: "4-ம் (பள்ளிச் சூழல்)", 5: "5-ம் (உயர்கல்வி/IQ)", 9: "9-ம் (இளநிலைக் கல்வி)"}
    house_rasi = {h: (d24_lagna_idx + h - 1) % 12 for h in education_houses}
    house_lord_en = {h: RASI_LORD.get(r) for h, r in house_rasi.items()}

    def connection_reason(planet_en):
        ta = planet_ta_map.get(planet_en)
        if not ta:
            return None
        p_rasi = d24["grahas"].get(ta, {}).get("rasi_index")
        reasons = []
        for h, label in education_houses.items():
            if p_rasi is not None and p_rasi == house_rasi[h]:
                reasons.append(f"D24 {label} வீட்டில் அமர்ந்துள்ளார்")
            if house_lord_en.get(h) == planet_en:
                reasons.append(f"D24 {label} வீட்டின் அதிபதி")
        return " · ".join(reasons) if reasons else None

    results = []
    for maha in full_dasa_tree:
        maha_reason = connection_reason(maha["lord_en"])
        if maha_reason:
            results.append({
                "level": "மகா தசை", "lord": maha["lord"],
                "start": maha["start"], "end": maha["end"],
                "reason": maha_reason,
                "is_mks": maha["lord_en"] in mks_planets,
                "concealed_by_parent": None,  # Mahadasa has no parent lord
            })
        for antar in maha["antardasa"]:
            antar_reason = connection_reason(antar["lord_en"])
            if antar_reason:
                conceal = concealment_text_for(grahas, maha["lord_en"], antar["lord_en"])
                results.append({
                    "level": f"புக்தி ({maha['lord']} தசையில்)", "lord": antar["lord"],
                    "start": antar["start"], "end": antar["end"],
                    "reason": antar_reason,
                    "is_mks": antar["lord_en"] in mks_planets,
                    "concealed_by_parent": bool(conceal),
                })
    return results


def d24_narrative_palan(vargas, planet_ta_map, varga_markers_data=None):
    """Builds a flowing D24 'palan' narrative (as prose sentences, with a
    'bold' flag on any sentence describing a 3/6/8/12 relationship) using:
    1. D24 Lagna's house-distance from D1 Lagna.
    2. Occupant(s) of D24 Lagna and whether they are natural benefics/malefics.
    3. D24 Lagna-lord's house (within D24) from D24 Lagna.
    4. D24 Lagna/Lagna-lord's conjunction/aspect with benefics/malefics
       and the resulting general effect.
    Returns a list of {"text": str, "bold": bool} sentences."""
    d1 = vargas["D1"]
    d24 = vargas["D24"]
    d1_lagna_idx = d1["lagna_rasi_index"]
    d24_lagna_idx = d24["lagna_rasi_index"]
    sentences = []

    # 1. D24 lagna's house-distance from D1 lagna
    house_from_d1 = (d24_lagna_idx - d1_lagna_idx) % 12 + 1
    is_crit = house_from_d1 in (3, 6, 8, 12)
    sentences.append({
        "text": f"D24 லக்னம், D1 லக்னத்திலிருந்து {house_from_d1}-ம் வீட்டில் அமைந்துள்ளது" +
                (" — இது 3/6/8/12 என்பதால் கல்வியில் சவால்கள் இருக்கலாம்." if is_crit else "."),
        "bold": is_crit
    })

    # 2. D24 lagna occupants + benefic/malefic
    lagna_occupants = [p_ta for p_ta, g in d24["grahas"].items() if g["rasi_index"] == d24_lagna_idx]
    if lagna_occupants:
        occ_texts = []
        for p_ta in lagna_occupants:
            p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
            nature = "சுப கிரகம்" if p_en in NATURAL_BENEFICS else ("அசுப கிரகம்" if p_en in NATURAL_MALEFICS else "")
            occ_texts.append(f"{p_ta} ({nature})" if nature else p_ta)
        sentences.append({
            "text": f"D24 லக்னத்தில் {', '.join(occ_texts)} அமர்ந்துள்ளனர்.",
            "bold": False
        })
    else:
        sentences.append({"text": "D24 லக்னத்தில் எந்த கிரகமும் இல்லை.", "bold": False})

    # 3. D24 lagna-lord's house within D24 (from D24 lagna)
    lagna_lord_en = RASI_LORD.get(d24_lagna_idx)
    lagna_lord_ta = planet_ta_map.get(lagna_lord_en) if lagna_lord_en else None
    lord_house = None
    if lagna_lord_ta:
        lord_rasi = d24["grahas"].get(lagna_lord_ta, {}).get("rasi_index")
        if lord_rasi is not None:
            lord_house = (lord_rasi - d24_lagna_idx) % 12 + 1
            is_crit2 = lord_house in (3, 6, 8, 12)
            sentences.append({
                "text": f"D24 லக்னாதிபதி {lagna_lord_ta}, D24-ல் {lord_house}-ம் வீட்டில் உள்ளார்" +
                        (" — இது 3/6/8/12 என்பதால் கல்வி பாதிக்கப்படலாம்." if is_crit2 else "."),
                "bold": is_crit2
            })

    # 4. Lagna/lagna-lord's conjunction with benefics/malefics -> resulting effect
    contact_planets = set()
    for p_ta, g in d24["grahas"].items():
        if g["rasi_index"] == d24_lagna_idx and p_ta not in lagna_occupants:
            continue
    # conjunction check for lagna itself (already have lagna_occupants) plus lagna lord's rasi
    if lagna_lord_ta and lord_house is not None:
        lord_rasi = d24["grahas"][lagna_lord_ta]["rasi_index"]
        lord_conjuncts = [p_ta for p_ta, g in d24["grahas"].items()
                           if g["rasi_index"] == lord_rasi and p_ta != lagna_lord_ta]
        for p_ta in lord_conjuncts:
            p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
            if p_en:
                contact_planets.add(p_en)
    for p_ta in lagna_occupants:
        p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
        if p_en:
            contact_planets.add(p_en)

    benefic_contacts = [planet_ta_map[p] for p in contact_planets if p in NATURAL_BENEFICS]
    malefic_contacts = [planet_ta_map[p] for p in contact_planets if p in NATURAL_MALEFICS]
    if benefic_contacts:
        sentences.append({
            "text": f"லக்னம்/லக்னாதிபதிக்கு சுப கிரக தொடர்பு ({', '.join(benefic_contacts)}) இருப்பதால், கல்வியில் நல்ல ஆதரவு கிடைக்கும்.",
            "bold": False
        })
    if malefic_contacts:
        sentences.append({
            "text": f"லக்னம்/லக்னாதிபதிக்கு அசுப கிரக தொடர்பு ({', '.join(malefic_contacts)}) இருப்பதால், கல்வியில் தடைகள்/சவால்கள் இருக்கலாம்.",
            "bold": True
        })

    # 5. Karako Bhava: Mercury alone (education karaka) sitting in D24 Lagna
    if "புதன்" in lagna_occupants:
        sentences.append({
            "text": "புதன் D24 லக்னத்திலேயே அமர்ந்துள்ளார் — காரகோ பாவம் (கல்வி காரகனே லக்னத்தில் இருப்பது).",
            "bold": True
        })

    # 6. D1-level affliction (Grahanam/Yuddha/Combustion, computed from D1)
    # on planets, grouped by their D24 house position - shows every planet
    # sharing that D24 house.
    d1_marks_for_rule6 = varga_markers_data.get("D1", {}) if varga_markers_data else {}
    afflicted_house_rasis = set()
    for p_en, marks in d1_marks_for_rule6.items():
        if "கீ" in marks or "யு" in marks or "அஸ்" in marks:
            ta = planet_ta_map.get(p_en)
            r = d24["grahas"].get(ta, {}).get("rasi_index") if ta else None
            if r is not None:
                afflicted_house_rasis.add(r)
    if afflicted_house_rasis:
        house_lines = []
        for r in afflicted_house_rasis:
            occs = [p_ta for p_ta, g in d24["grahas"].items() if g["rasi_index"] == r]
            house_lines.append(f"{RASI_TA[r]} ராசி வீட்டில் ({', '.join(occs)})")
        sentences.append({
            "text": f"D1-ல் பாதிக்கப்பட்ட கிரகங்கள், D24-ல் இந்த வீடுகளில் உள்ளனர்: {'; '.join(house_lines)}.",
            "bold": True
        })

    # 7. D1-level affliction (combustion/grahanam/yuddha, computed from D1
    # itself) whose planet's D1 rasi coincides with D24's own Lagna rasi.
    d1_marks = varga_markers_data.get("D1", {}) if varga_markers_data else {}
    d1_afflicted_matching_d24_lagna = []
    for p_en, marks in d1_marks.items():
        if "கீ" in marks or "யு" in marks or "அஸ்" in marks:
            ta = planet_ta_map.get(p_en)
            r = d1["grahas"].get(ta, {}).get("rasi_index") if ta else None
            if r == d24_lagna_idx:
                tags = []
                if "கீ" in marks: tags.append("கிரகணம்")
                if "யு" in marks: tags.append("கிரகயுத்தம்")
                if "அஸ்" in marks: tags.append("அஸ்தங்கம்")
                d1_afflicted_matching_d24_lagna.append(f"{ta} ({', '.join(tags)})")
    if d1_afflicted_matching_d24_lagna:
        sentences.append({
            "text": f"D24 லக்னம் அமைந்துள்ள ராசியில், D1-ல் {', '.join(d1_afflicted_matching_d24_lagna)} பாதிக்கப்பட்டுள்ளதால், D24 லக்னமும் பலவீனமடைகிறது.",
            "bold": True
        })

    # 8. Dual (உபய) rasi rule: Lagna or Lagna-lord in Gemini/Virgo/Sagittarius/Pisces
    DUAL_RASIS = {2, 5, 8, 11}
    lagna_lord_rasi = d24["grahas"].get(lagna_lord_ta, {}).get("rasi_index") if lagna_lord_ta else None
    if d24_lagna_idx in DUAL_RASIS or (lagna_lord_rasi is not None and lagna_lord_rasi in DUAL_RASIS):
        sentences.append({
            "text": "லக்னம்/லக்னாதிபதி உபய ராசியில் இருப்பதால், சரியான நேரத்தில் சரியான முடிவை எடுப்பவராக இருப்பார்.",
            "bold": False
        })

    return sentences


def d24_education_facts(vargas_d24, panchanga_data, grahas, planet_ta_map, lagna_lon=None):
    """Objective, verdict-free facts for D24 (Chaturvimsamsa) education
    analysis: Matru Karaka's relationship to the 5th house/lord, 4th/2nd/
    12th house occupants, and static per-planet 12th-house notes.
    Presents raw placements only - no pass/fail judgment or lagna
    rectification suggestion."""
    d24_lagna_idx = vargas_d24["lagna_rasi_index"]
    d24_grahas = vargas_d24["grahas"]  # keyed by Tamil name -> {"rasi", "rasi_index"}

    # Atmakaraka (from Jaimini karakas already computed)
    ak_entry = next((k for k in panchanga_data["karakas"] if k["karaka_ta"] == "ஆத்மகாரகன்"), None)
    ak_en = ak_entry["planet_en"] if ak_entry else None
    ak_ta = ak_entry["planet_ta"] if ak_entry else None
    ak_d24_rasi = d24_grahas.get(ak_ta, {}).get("rasi_index") if ak_ta else None
    ak_in_lagna = (ak_d24_rasi == d24_lagna_idx) if ak_d24_rasi is not None else False

    # D24 Karakatva palan: compare Mercury (learning/grasping) vs Jupiter
    # (teaching/retention) dignity in D24, and state which ability is
    # stronger for this person.
    def _dignity_score(p_en, p_rasi):
        if p_rasi is None:
            return None
        if EXALT_RASI_TABLE.get(p_en) == p_rasi: return 3
        if p_rasi in RASI_LORD_REV_MAIN.get(p_en, []): return 2
        if DEBIL_RASI_TABLE.get(p_en) == p_rasi: return 0
        return 1

    mercury_rasi_for_karaka = d24_grahas.get("புதன்", {}).get("rasi_index")
    jupiter_rasi_for_karaka = d24_grahas.get("வியாழன்", {}).get("rasi_index")
    mercury_score = _dignity_score("Mercury", mercury_rasi_for_karaka)
    jupiter_score = _dignity_score("Jupiter", jupiter_rasi_for_karaka)

    d24_karaka_palan = None
    if mercury_score is not None and jupiter_score is not None:
        if mercury_score > jupiter_score:
            d24_karaka_palan = "புதன் D24-ல் குருவை விட பலம் பெற்றிருப்பதால், கற்கும்/கொள்ளும் திறன் (Learning/Grasping ability) அதிகமாக இருக்கும்."
        elif jupiter_score > mercury_score:
            d24_karaka_palan = "குரு D24-ல் புதனை விட பலம் பெற்றிருப்பதால், விளக்கிச் சொல்லும்/திருப்பியளிக்கும் திறன் (Teaching/Retention ability) அதிகமாக இருக்கும் — ஆசிரியத் திறமையும் இருக்கும்."
        else:
            d24_karaka_palan = "புதனும் குருவும் D24-ல் ஒரே அளவு பலம் பெற்றுள்ளதால், கற்கும் திறனும் விளக்கும் திறனும் சமமாக இருக்கும்."

    D24_KARAKA_NOTES = {
        "புதன்": "கற்கும் கொள்ளும் அறிவு நுட்பம் (Learning/Grasping ability)",
        "வியாழன்": "விளக்கிச் சொல்லும் அறிவு நுட்பம், திருப்பியளிக்கும் தன்மை, ஆசிரியத் திறமை (Teaching/Retention ability)",
    }
    MERCURY_MODALITY_LEARNING_STYLE = {
        "chara": "புதன் சர ராசியில் — வேகமாக படிப்பார், மேலோட்டமாக படிப்பார், கவனக்குறைவு இருக்கும்.",
        "sthira": "புதன் ஸ்திர ராசியில் — நிதானமாக, ஆழமாக, முழு கவனத்தோடு படிப்பார். படித்ததை நீண்டகாலமாக மனதில் பதிய வைப்பார்.",
        "dwiswabhava": "புதன் உபய ராசியில் — கவனம் ஒரு நிலையாக இருக்காது (போகும்-வரும்), உள்வாங்கியும் வாங்காமலும் படிப்பார்.",
    }
    mercury_d24_rasi = d24_grahas.get("புதன்", {}).get("rasi_index")
    mercury_learning_style = None
    if mercury_d24_rasi is not None:
        if mercury_d24_rasi in CHARA_RASI:
            mercury_learning_style = MERCURY_MODALITY_LEARNING_STYLE["chara"]
        elif mercury_d24_rasi in STHIRA_RASI:
            mercury_learning_style = MERCURY_MODALITY_LEARNING_STYLE["sthira"]
        elif mercury_d24_rasi in DWISWABHAVA_RASI:
            mercury_learning_style = MERCURY_MODALITY_LEARNING_STYLE["dwiswabhava"]

    # Sense-organ learning preference: among Mars/Saturn/Jupiter/Mercury/
    # Venus, whichever has the STRONGEST dignity in D24 (exalted > own
    # sign > neutral > debilitated) indicates the preferred learning sense.
    SENSE_ORGAN_NOTES = {
        "Mars": "கண்ணால் பார்த்து படிப்பார் (பார்வை வழி கற்றல்)",
        "Saturn": "தொடு உணர்வு மூலம் படிப்பார் (Touch வழி கற்றல்)",
        "Jupiter": "காதால் கேட்டு படிப்பார் (செவி வழி கற்றல்)",
        "Mercury": "புத்தக வாசனையை முகர்ந்து கொண்டே படிப்பார் — புது புத்தகம்/நோட்டு என்றால் விரும்பி படிப்பார் (Smell வழி கற்றல்)",
        "Venus": "வாயில் எதையாவது சுவைத்துக்கொண்டு, அல்லது விரலால் எச்சிலைத் தொட்டு பக்கத்தை திருப்பி திருப்பி படிப்பார் (Taste வழி கற்றல்)",
    }
    sense_organ_planets = ["Mars", "Saturn", "Jupiter", "Mercury", "Venus"]
    scores = {}
    exalt_lord_conjunct = {}
    for p_en in sense_organ_planets:
        p_ta = planet_ta_map.get(p_en)
        p_rasi = d24_grahas.get(p_ta, {}).get("rasi_index") if p_ta else None
        if p_rasi is None:
            continue
        if EXALT_RASI_TABLE.get(p_en) == p_rasi:
            base_score = 3
        elif p_rasi in RASI_LORD_REV_MAIN.get(p_en, []):
            base_score = 2
        elif DEBIL_RASI_TABLE.get(p_en) == p_rasi:
            base_score = 0
        else:
            base_score = 1
        # Bonus: conjunct with the lord of THIS planet's own exaltation
        # sign (e.g. Mars exalts in Capricorn, ruled by Saturn - Mars
        # conjunct Saturn gets this strengthening bonus).
        exalt_rasi_of_p = EXALT_RASI_TABLE.get(p_en)
        exalt_lord_en = RASI_LORD.get(exalt_rasi_of_p) if exalt_rasi_of_p is not None else None
        has_exalt_lord_conjunction = False
        if exalt_lord_en and exalt_lord_en != p_en:
            exalt_lord_ta = planet_ta_map.get(exalt_lord_en)
            exalt_lord_rasi = d24_grahas.get(exalt_lord_ta, {}).get("rasi_index") if exalt_lord_ta else None
            has_exalt_lord_conjunction = (exalt_lord_rasi == p_rasi)
        exalt_lord_conjunct[p_en] = has_exalt_lord_conjunction
        scores[p_en] = base_score + (1 if has_exalt_lord_conjunction else 0)
    sense_organ_learning = None
    if scores:
        max_score = max(scores.values())
        tied_planets = [p for p, s in scores.items() if s == max_score]
        if len(tied_planets) > 1:
            # Genuine tie (e.g. everyone neutral) - no single planet is
            # meaningfully "strongest", so don't claim one is.
            sense_organ_learning = {
                "planet_ta": ", ".join(planet_ta_map[p] for p in tied_planets),
                "note": f"இந்த கிரகங்கள் அனைத்தும் சம பலத்தில் (dignity score {max_score}) உள்ளதால், ஒரே ஒரு தனிப் புலன் மேலோங்கவில்லை.",
                "tied": True,
            }
        else:
            best_planet_en = tied_planets[0]
            sense_organ_learning = {
                "planet_ta": planet_ta_map[best_planet_en],
                "note": SENSE_ORGAN_NOTES[best_planet_en],
                "tied": False,
            }

    # Karako Bhavo Nasti: both Mercury AND Atmakaraka in D24 Lagna
    mercury_d24_rasi = d24_grahas.get("புதன்", {}).get("rasi_index")
    mercury_in_lagna = (mercury_d24_rasi == d24_lagna_idx)
    karako_bhavo_nasti = mercury_in_lagna and ak_in_lagna

    # Foreign-education rasis: Cancer(3), Scorpio(7), Capricorn(9), Pisces(11)
    FOREIGN_EDU_RASIS = {3, 7, 9, 11}
    d24_lagna_lord_en = RASI_LORD.get(d24_lagna_idx)
    d24_lagna_lord_ta = planet_ta_map.get(d24_lagna_lord_en) if d24_lagna_lord_en else None
    d24_lagna_lord_rasi = d24_grahas.get(d24_lagna_lord_ta, {}).get("rasi_index") if d24_lagna_lord_ta else None
    foreign_education_indicated = (
        d24_lagna_idx in FOREIGN_EDU_RASIS or
        (d24_lagna_lord_rasi is not None and d24_lagna_lord_rasi in FOREIGN_EDU_RASIS)
    )

    # "Kamarajar rule": Lagna/Lagna-lord afflicted (debilitated/in 6-8-12
    # from D24 lagna) while 4th/5th houses are strong -> formal education
    # difficulty, even though the person can still be highly capable/
    # successful through other means (classic real-world example: Kamarajar).
    def _house_lord_strength(house_num):
        h_rasi = (d24_lagna_idx + house_num - 1) % 12
        lord_en = RASI_LORD.get(h_rasi)
        lord_ta = planet_ta_map.get(lord_en) if lord_en else None
        lord_rasi = d24_grahas.get(lord_ta, {}).get("rasi_index") if lord_ta else None
        if lord_rasi is None:
            return None
        house_from_lagna = (lord_rasi - d24_lagna_idx) % 12 + 1
        if DEBIL_RASI_TABLE.get(lord_en) == lord_rasi or house_from_lagna in (6, 8, 12):
            return "weak"
        if EXALT_RASI_TABLE.get(lord_en) == lord_rasi or house_from_lagna in (1, 4, 5, 9, 10):
            return "strong"
        return "neutral"

    lagna_lord_strength = _house_lord_strength(1)
    fourth_strength = _house_lord_strength(4)
    fifth_strength = _house_lord_strength(5)
    lagna_afflicted = (
        lagna_lord_strength == "weak" or
        DEBIL_RASI_TABLE.get(d24_lagna_lord_en) == d24_lagna_lord_rasi
    )
    kamarajar_pattern = lagna_afflicted and (fourth_strength == "strong" or fifth_strength == "strong")

    # D24 Lagna/Lagna-lord's own Deity (24-port) and its field of excellence
    lagna_deity_field = None
    if lagna_lon is not None:
        lagna_deity = d24_deity_of(lagna_lon)
        lagna_lord_deity = None
        if d24_lagna_lord_en and d24_lagna_lord_en in grahas:
            lagna_lord_deity = d24_deity_of(grahas[d24_lagna_lord_en]["longitude"])
        lagna_deity_field = {
            "lagna_deity": lagna_deity,
            "lagna_deity_field": DEITY_SIGNIFICANCE.get(lagna_deity),
            "lagna_lord_deity": lagna_lord_deity,
            "lagna_lord_deity_field": DEITY_SIGNIFICANCE.get(lagna_lord_deity) if lagna_lord_deity else None,
        }

    # D24 3/6/8/12 house strength + associated fields (per your list)
    HOUSE_FIELD_NOTES = {
        3: "எழுத்து, தைரியம், பேசும் தைரியம், Communication, தமிழ்",
        6: "வங்கி சார்ந்த பணி, வக்கீல், ஜட்ஜ், மருத்துவம், காவல் துறை சார்ந்த படிப்பு",
        8: "ரிசர்ச், மறைபொருள் விஞ்ஞானம், இன்சூரன்ஸ், தொல்லியல்/அகழ்வாராய்ச்சி, ஜோதிடம், மாந்திரீகம், Spy, Cyber Power",
        12: "வெளிநாடு, வெளிநாட்டு மொழி, இலக்கியம், கலாச்சாரம், பண்பாடு, தியானம், யோகா",
    }
    HOUSE_PALAN_TEMPLATES = {
        "strong": "{fields} சார்ந்த திறமை/வெற்றி வாய்ப்பு அதிகம்.",
        "weak": "{fields} சார்ந்த துறைகளில் தேவையான பலம் இல்லை — சிரமங்கள் இருக்கலாம்.",
        "neutral": "{fields} சார்ந்த துறைகளில் மிதமான வாய்ப்பு — சூழ்நிலைக்கு ஏற்ப மாறும்.",
    }
    house_strength_fields = []
    for house_num, field_note in HOUSE_FIELD_NOTES.items():
        strength = _house_lord_strength(house_num)
        if strength is None:
            continue
        house_strength_fields.append({
            "house": house_num,
            "strength": "பலம்" if strength == "strong" else ("பலவீனம்" if strength == "weak" else "நடுநிலை"),
            "fields": field_note,
            "positive": strength != "weak",
            "palan": HOUSE_PALAN_TEMPLATES[strength].format(fields=field_note),
        })

    # D24 planet-combination indications (same-rasi conjunctions in D24)
    D24_COMBO_MEANINGS = [
        (("சூரியன்", "புதன்"), "ஜோதிடம் மீது ஆர்வம்"),
        (("சந்திரன்", "புதன்"), "ஆடிட், CA, அக்கவுண்டன்சி, காமர்ஸ், பொருளாதாரம்"),
        (("சூரியன்", "சுக்கிரன்"), "கவர்ச்சி, நடிப்பு, வேடம் சார்ந்த ஆர்வம்"),
        (("சூரியன்", "செவ்வாய்"), "IAS/IPS/அறுவை சிகிச்சை சார்ந்த ஆர்வம்"),
    ]
    combo_facts = []
    for (p1_ta, p2_ta), meaning in D24_COMBO_MEANINGS:
        r1 = d24_grahas.get(p1_ta, {}).get("rasi_index")
        r2 = d24_grahas.get(p2_ta, {}).get("rasi_index")
        if r1 is not None and r1 == r2:
            combo_facts.append({"planets": f"{p1_ta}+{p2_ta}", "meaning": meaning})

    # Father-side vs mother-side knowledge: Simha(4) through Makaram(9) =
    # father's side; Kumbam(10) through Mithunam(2) = mother's side.
    # Counted by which "half" the majority of D24 grahas fall into.
    FATHER_SIDE_RASIS = {4, 5, 6, 7, 8, 9}   # Simha..Makaram
    MOTHER_SIDE_RASIS = {10, 11, 0, 1, 2, 3}  # Kumbam..Mithunam
    father_count = sum(1 for g in d24_grahas.values() if g["rasi_index"] in FATHER_SIDE_RASIS)
    mother_count = sum(1 for g in d24_grahas.values() if g["rasi_index"] in MOTHER_SIDE_RASIS)
    knowledge_side = None
    if father_count > mother_count:
        knowledge_side = "அப்பா வழி அறிவு (சிம்மம்-மகரம் கிரகங்கள் அதிகம்)"
    elif mother_count > father_count:
        knowledge_side = "அம்மா வழி அறிவு (கும்பம்-மிதுனம் கிரகங்கள் அதிகம்)"

    # Matru Karaka (from Jaimini karakas already computed)
    mk_entry = next((k for k in panchanga_data["karakas"] if k["karaka_ta"] == "மாதுரு காரகன்"), None)
    mk_en = mk_entry["planet_en"] if mk_entry else None
    mk_ta = mk_entry["planet_ta"] if mk_entry else None
    mk_d24_rasi = d24_grahas.get(mk_ta, {}).get("rasi_index") if mk_ta else None

    house_rasi = {h: (d24_lagna_idx + h - 1) % 12 for h in range(1, 13)}

    def occupants_of(house_num):
        r = house_rasi[house_num]
        return [p for p, g in d24_grahas.items() if g["rasi_index"] == r]

    fifth_rasi = house_rasi[5]
    fifth_lord_en = RASI_LORD[fifth_rasi]
    fifth_lord_ta = planet_ta_map[fifth_lord_en]
    fifth_lord_d24_rasi = d24_grahas.get(fifth_lord_ta, {}).get("rasi_index")

    mk_aspects_5th = False
    mk_conjunct_5th_lord = False
    if mk_en and mk_d24_rasi is not None:
        mk_aspects_5th = fifth_rasi in graha_drishti(mk_en, mk_d24_rasi)
        mk_conjunct_5th_lord = (mk_d24_rasi == fifth_lord_d24_rasi)

    fourth_occupants = occupants_of(4)
    twelfth_occupants = occupants_of(12)
    second_occupants = occupants_of(2)

    twelfth_notes = []
    for p_ta in twelfth_occupants:
        p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
        if p_en and p_en in D24_TWELFTH_HOUSE_NOTES:
            twelfth_notes.append({"planet_ta": p_ta, "note": D24_TWELFTH_HOUSE_NOTES[p_en]})

    # Subject/career-field suggestions from planetary karakatva (Sun..Ketu
    # significations table), based on: D24 5th house occupants, D24 5th
    # lord, and D24 lagna lord - these are the planets most tied to
    # education/aptitude per classical usage.
    d24_lagna_lord_en = RASI_LORD.get(d24_lagna_idx)
    subject_source_planets = set()
    for p_ta in occupants_of(5):
        p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
        if p_en:
            subject_source_planets.add(p_en)
    if fifth_lord_en:
        subject_source_planets.add(fifth_lord_en)
    if d24_lagna_lord_en:
        subject_source_planets.add(d24_lagna_lord_en)

    subject_suggestions = []
    for p_en in subject_source_planets:
        if p_en in PLANET_SUBJECT_KARAKATVA:
            subject_suggestions.append({
                "planet_ta": planet_ta_map[p_en],
                "subjects": PLANET_SUBJECT_KARAKATVA[p_en]
            })

    rasi_subject_suggestions = []
    for label, rasi_idx in [("D24 லக்னம்", d24_lagna_idx), ("D24 5-ம் வீடு", fifth_rasi)]:
        if rasi_idx in RASI_SUBJECT_KARAKATVA:
            rasi_subject_suggestions.append({
                "label": label, "rasi_ta": RASI_TA[rasi_idx],
                "subjects": RASI_SUBJECT_KARAKATVA[rasi_idx]
            })

    # 3/6/8/12 rule: any planet in D24's 3rd, 6th, 8th, or 12th house
    # indicates its language/school medium does NOT suit the person -
    # no dasa-bhukti needed, just the placement.
    not_suited_language = []
    not_suited_school = []
    for house_num in (3, 6, 8, 12):
        for p_ta in occupants_of(house_num):
            p_en = next((k for k, v in planet_ta_map.items() if v == p_ta), None)
            if not p_en:
                continue
            if p_en in PLANET_LANGUAGE:
                not_suited_language.append({
                    "planet_ta": p_ta, "house": house_num,
                    "language": PLANET_LANGUAGE[p_en]
                })
            if p_en in PLANET_SCHOOL_MEDIUM:
                not_suited_school.append({
                    "planet_ta": p_ta, "house": house_num,
                    "school": PLANET_SCHOOL_MEDIUM[p_en]
                })

    return {
        "matru_karaka_ta": mk_ta,
        "matru_karaka_d24_rasi": RASI_TA[mk_d24_rasi] if mk_d24_rasi is not None else None,
        "fifth_house_rasi": RASI_TA[fifth_rasi],
        "fifth_lord_ta": fifth_lord_ta,
        "fifth_house_occupants_ta": occupants_of(5),
        "mk_aspects_fifth_house": mk_aspects_5th,
        "mk_conjunct_fifth_lord": mk_conjunct_5th_lord,
        "fourth_house_occupants_ta": fourth_occupants,
        "fourth_has_mars": "செவ்வாய்" in fourth_occupants,
        "fourth_has_mercury": "புதன்" in fourth_occupants,
        "second_house_occupants_ta": second_occupants,
        "twelfth_house_occupants_ta": twelfth_occupants,
        "twelfth_house_notes": twelfth_notes,
        "subject_suggestions": subject_suggestions,
        "rasi_subject_suggestions": rasi_subject_suggestions,
        "not_suited_language": not_suited_language,
        "not_suited_school": not_suited_school,
        "atmakaraka_ta": ak_ta,
        "atmakaraka_in_d24_lagna": ak_in_lagna,
        "karako_bhavo_nasti": karako_bhavo_nasti,
        "foreign_education_indicated": foreign_education_indicated,
        "d24_combo_facts": combo_facts,
        "knowledge_side": knowledge_side,
        "d24_karaka_notes": D24_KARAKA_NOTES,
        "d24_karaka_palan": d24_karaka_palan,
        "mercury_learning_style": mercury_learning_style,
        "sense_organ_learning": sense_organ_learning,
        "kamarajar_pattern": kamarajar_pattern,
        "house_strength_fields": house_strength_fields,
        "lagna_deity_field": lagna_deity_field,
    }


def calculate_yogas(grahas):
    return {
        "parivartana": find_parivartana(grahas),
        "graha_sechkai": find_conjunctions(grahas),
        "mutual_7th_aspect": find_mutual_aspect_7th(grahas),
        "six_eight_twelve": find_6_8_12_relation(grahas),
    }


if __name__ == "__main__":
    import json
    # Test with the example from earlier conversation
    chart = calculate_chart(
        birth_date="1979-10-05",
        birth_time="10:10",
        tz_offset=5.5,
        lat=8.4959,
        lon=78.1289,
        place_name="Tiruchendur"
    )
    print(json.dumps(chart, indent=2, ensure_ascii=False, default=str))
